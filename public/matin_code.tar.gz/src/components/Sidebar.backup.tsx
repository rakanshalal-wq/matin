'use client';
import { useState, useEffect } from 'react';
import { usePathname } from 'next/navigation';
import Link from 'next/link';

export default function Sidebar({ isOpen, onClose, screenSize = 'desktop' }: { isOpen: boolean; onClose: () => void; screenSize?: 'mobile' | 'tablet' | 'desktop' }) {
  const pathname = usePathname();
  const [openSections, setOpenSections] = useState<string[]>([]);
  const [userRole, setUserRole] = useState('');
  const [userPackage, setUserPackage] = useState('basic');

  const isMobile = screenSize === 'mobile';
  const isTablet = screenSize === 'tablet';
  const isOverlay = isMobile || isTablet;

  useEffect(() => {
    try {
      const u = JSON.parse(localStorage.getItem('matin_user') || '{}');
      setUserRole(u.role || '');
      setUserPackage(u.package || 'basic');
    } catch {}
  }, []);

  const allSections = [
    { title: 'الرئيسية', roles: ['super_admin','owner','admin','teacher','parent','student'], items: [
      { id: 'home', label: 'لوحة التحكم', icon: '🏠', href: '/dashboard' },
      { id: 'users', label: 'إدارة المستخدمين', icon: '👥', href: '/dashboard/users', roles: ['super_admin'] },
      { id: 'staff', label: 'إدارة الطاقم', icon: '👨‍🏫', href: '/dashboard/staff', roles: ['super_admin','owner','admin'] },
    ]},
    { title: 'إدارة المؤسسات', roles: ['super_admin','owner'], items: [
      { id: 'schools', label: 'المدارس', icon: '🏫', href: '/dashboard/schools' },
      { id: 'colleges', label: 'الكليات والأقسام', icon: '🎓', href: '/dashboard/colleges' },
      { id: 'admission', label: 'القبول والتسجيل', icon: '📋', href: '/dashboard/admission' },
      { id: 'subscriptions', label: 'الباقات والاشتراكات', icon: '💎', href: '/dashboard/subscriptions', roles: ['super_admin'] },
      { id: 'school-invoices', label: 'فواتير المدارس', icon: '🧾', href: '/dashboard/school-invoices', roles: ['super_admin'] },
    ]},
    { title: 'إدارة الأشخاص', roles: ['super_admin','owner','admin'], items: [
      { id: 'join-requests', label: 'طلبات الانضمام', icon: '📋', href: '/dashboard/join-requests', roles: ['super_admin','owner','admin'] },
      { id: 'students', label: 'الطلاب', icon: '👨‍🎓', href: '/dashboard/students' },
      { id: 'teachers', label: 'المعلمين', icon: '👩‍🏫', href: '/dashboard/teachers' },
      { id: 'teacher-assignments', label: 'تعيين المعلمين', icon: '📚', href: '/dashboard/teacher-assignments', roles: ['super_admin','owner','admin'] },
      { id: 'employees', label: 'الموظفين', icon: '👔', href: '/dashboard/employees' },
      { id: 'parents', label: 'أولياء الأمور', icon: '👨‍👩‍👧', href: '/dashboard/parents' },
      { id: 'trainers', label: 'المدربين', icon: '🏋', href: '/dashboard/trainers' },
      { id: 'visitors', label: 'الزوار', icon: '🚶', href: '/dashboard/visitors' },
      { id: 'leads', label: 'العملاء المحتملين', icon: '🎯', href: '/dashboard/leads', roles: ['super_admin','owner'] },
      { id: 'partners', label: 'الشركاء', icon: '🤝', href: '/dashboard/partners', roles: ['super_admin','owner'] },
    ]},
    { title: 'الهيكل الأكاديمي', roles: ['super_admin','owner','admin','teacher'], items: [
      { id: 'classes', label: 'الفصول', icon: '🏛', href: '/dashboard/classes' },
      { id: 'subjects', label: 'المواد', icon: '📊', href: '/dashboard/subjects' },
      { id: 'curriculum', label: 'المناهج', icon: '📖', href: '/dashboard/curriculum' },
      { id: 'credit-hours', label: 'الساعات المعتمدة', icon: '⏰', href: '/dashboard/credit-hours', packages: ['advanced','enterprise'] },
      { id: 'courses', label: 'الدورات', icon: '🎯', href: '/dashboard/courses' },
    ]},
    { title: 'الجداول والتنظيم', roles: ['super_admin','owner','admin','teacher'], items: [
      { id: 'schedules', label: 'الجداول', icon: '📅', href: '/dashboard/schedules' },
      { id: 'calendar', label: 'التقويم', icon: '📆', href: '/dashboard/calendar' },
      { id: 'meetings', label: 'الاجتماعات', icon: '🤝', href: '/dashboard/meetings' },
      { id: 'tasks', label: 'المهام', icon: '✅', href: '/dashboard/tasks' },
      { id: 'appointments', label: 'المواعيد', icon: '📋', href: '/dashboard/appointments' },
    ]},
    { title: 'الحضور والسلوك', roles: ['super_admin','owner','admin','teacher'], items: [
      { id: 'attendance', label: 'الحضور', icon: '✋', href: '/dashboard/attendance' },
      { id: 'behavior', label: 'السلوك والمواظبة', icon: '📊', href: '/dashboard/behavior' },
      { id: 'counseling', label: 'الإرشاد النفسي', icon: '🧠', href: '/dashboard/counseling' },
      { id: 'special-needs', label: 'ذوي الاحتياجات', icon: '♿', href: '/dashboard/special-needs' },
    ]},
    { title: 'الاختبارات والتقييم', roles: ['super_admin','owner','admin','teacher'], items: [
      { id: 'exams', label: 'الاختبارات', icon: '📝', href: '/dashboard/exams' },
      { id: 'question-bank', label: 'بنك الأسئلة', icon: '❓', href: '/dashboard/question-bank' },
      { id: 'question-analytics', label: 'تحليل جودة الأسئلة', icon: '🧠', href: '/dashboard/question-analytics' },
      { id: 'homework', label: 'الواجبات', icon: '📒', href: '/dashboard/homework' },
      { id: 'grades', label: 'الدرجات', icon: '📊', href: '/dashboard/grades' },
      { id: 'certificates', label: 'الشهادات', icon: '🏆', href: '/dashboard/certificates' },
      { id: 'exam-schedule', label: 'جدول الاختبارات', icon: '📅', href: '/dashboard/exam-schedule' },
      { id: 'exam-rooms', label: 'القاعات', icon: '🏛', href: '/dashboard/exam-rooms' },
      { id: 'supervisors', label: 'المراقبين', icon: '👁', href: '/dashboard/supervisors' },
      { id: 'grading-committees', label: 'لجان التصحيح', icon: '✅', href: '/dashboard/grading-committees' },
      { id: 'grade-appeals', label: 'الاعتراض على الدرجات', icon: '⚖️', href: '/dashboard/grade-appeals', roles: ['super_admin','owner','admin'] },
      { id: 'exam-proctoring', label: 'مراقبة الاختبارات', icon: '🎥', href: '/dashboard/exam-proctoring', roles: ['super_admin','owner','admin'], packages: ['enterprise'] },
    ]},
    { title: 'النقل المدرسي', roles: ['super_admin','owner','admin'], items: [
      { id: 'transport', label: 'النقل', icon: '🚌', href: '/dashboard/transport' },
      { id: 'student-tracking', label: 'تتبع الطلاب GPS', icon: '📍', href: '/dashboard/student-tracking' },
      { id: 'bus-maintenance', label: 'صيانة الباصات', icon: '🔧', href: '/dashboard/bus-maintenance' },
      { id: 'fuel', label: 'الوقود', icon: '⛽', href: '/dashboard/fuel' },
      { id: 'driver-licenses', label: 'رخص السائقين', icon: '🪪', href: '/dashboard/driver-licenses' },
      { id: 'drivers', label: 'السائقين والمشرفين', icon: '👨‍✈️', href: '/dashboard/drivers' },
    ]},
    { title: 'الخدمات', roles: ['super_admin','owner','admin'], items: [
      { id: 'cafeteria', label: 'الكافتيريا', icon: '🍽', href: '/dashboard/cafeteria' },
      { id: 'library', label: 'المكتبة', icon: '📚', href: '/dashboard/library' },
      { id: 'activities', label: 'الأنشطة', icon: '🎭', href: '/dashboard/activities' },
      { id: 'gifted', label: 'الموهوبين', icon: '🌟', href: '/dashboard/gifted' },
    ]},
    { title: 'الصحة', roles: ['super_admin','owner','admin'], items: [
      { id: 'health', label: 'الصحة', icon: '🏥', href: '/dashboard/health' },
      { id: 'clinic', label: 'العيادة', icon: '🩺', href: '/dashboard/clinic' },
      { id: 'emergencies', label: 'الحالات الطارئة', icon: '🚨', href: '/dashboard/emergencies' },
      { id: 'insurance', label: 'التأمين الصحي', icon: '🛡', href: '/dashboard/insurance' },
      { id: 'vaccinations', label: 'التطعيمات', icon: '💉', href: '/dashboard/vaccinations' },
    ]},
    { title: 'التعليم الإلكتروني', roles: ['super_admin','owner','admin','teacher'], items: [
      { id: 'elearning', label: 'التعليم الإلكتروني', icon: '💻', href: '/dashboard/elearning' },
      { id: 'lectures', label: 'المحاضرات', icon: '🎤', href: '/dashboard/lectures' },
      { id: 'live-stream', label: 'البث المباشر', icon: '📡', href: '/dashboard/live-stream', packages: ['advanced','enterprise'] },
      { id: 'recordings', label: 'التسجيلات', icon: '🎬', href: '/dashboard/recordings', packages: ['advanced','enterprise'] },
    ]},
    { title: 'المالية', roles: ['super_admin','owner','admin'], items: [
      { id: 'finance', label: 'المالية', icon: '💰', href: '/dashboard/finance' },
      { id: 'salaries', label: 'الرواتب', icon: '💵', href: '/dashboard/salaries' },
      { id: 'scholarships', label: 'المنح والخصومات', icon: '🎁', href: '/dashboard/scholarships' },
      { id: 'coupons', label: 'كوبونات الخصم', icon: '🏷', href: '/dashboard/coupons' },
      { id: 'commissions', label: 'العمولات', icon: '📊', href: '/dashboard/commissions', roles: ['super_admin'] },
      { id: 'store', label: 'المتجر', icon: '🛒', href: '/dashboard/store' },
    ]},
    { title: 'التواصل', roles: ['super_admin','owner','admin','teacher','parent'], items: [
      { id: 'messages', label: 'الرسائل', icon: '✉️', href: '/dashboard/messages' },
      { id: 'notifications', label: 'الإشعارات', icon: '🔔', href: '/dashboard/notifications' },
      { id: 'chat', label: 'الدردشة', icon: '💬', href: '/dashboard/chat' },
      { id: 'forums', label: 'مجموعات النقاش', icon: '🗣', href: '/dashboard/forums' },
      { id: 'community', label: 'المجتمع', icon: '🌐', href: '/dashboard/community' },
      { id: 'inbox', label: 'البريد الداخلي', icon: '📧', href: '/dashboard/inbox' },
      { id: 'complaints', label: 'الشكاوى والاقتراحات', icon: '📢', href: '/dashboard/complaints' },
      { id: 'surveys', label: 'الاستبيانات', icon: '📊', href: '/dashboard/surveys' },
      { id: 'parents-council', label: 'مجلس الآباء', icon: '👨‍👩‍👧‍👦', href: '/dashboard/parents-council' },
      { id: 'circulars', label: 'التعاميم', icon: '📄', href: '/dashboard/circulars' },
    ]},
    { title: 'المحتوى', roles: ['super_admin','owner','admin'], items: [
      { id: 'ads', label: 'الإعلانات', icon: '📢', href: '/dashboard/ads', roles: ['super_admin'] },
      { id: 'news', label: 'الأخبار', icon: '📰', href: '/dashboard/news' },
      { id: 'gallery', label: 'معرض الصور', icon: '🖼', href: '/dashboard/gallery' },
      { id: 'videos', label: 'الفيديوهات', icon: '🎥', href: '/dashboard/videos' },
      { id: 'page-design', label: 'تنسيق الصفحات', icon: '🎨', href: '/dashboard/page-design', roles: ['super_admin'] },
    ]},
    { title: 'المرافق', roles: ['super_admin','owner','admin'], packages: ['advanced','enterprise'], items: [
      { id: 'facilities', label: 'المباني والمرافق', icon: '🏢', href: '/dashboard/facilities' },
      { id: 'inventory', label: 'المستودعات', icon: '📦', href: '/dashboard/inventory' },
      { id: 'security', label: 'الأمن والسلامة', icon: '🔒', href: '/dashboard/security' },
      { id: 'contracts', label: 'العقود والوثائق', icon: '📑', href: '/dashboard/contracts' },
    ]},
    { title: 'التقارير', roles: ['super_admin','owner','admin'], items: [
      { id: 'reports', label: 'التقارير', icon: '📈', href: '/dashboard/reports' },
      { id: 'super-admin', label: 'لوحة مالك المنصة', icon: '👑', href: '/dashboard/super-admin', roles: ['super_admin'] },
      { id: 'platform-analytics', label: 'إحصاءات المنصة', icon: '📊', href: '/dashboard/platform-analytics', roles: ['super_admin'] },
      { id: 'activity-log', label: 'سجل العمليات', icon: '📋', href: '/dashboard/activity-log', roles: ['super_admin'] },
    ]},
    { title: 'أدوات ذكية', roles: ['super_admin','owner','admin','teacher'], items: [
      { id: 'ai-chat', label: 'المساعد الذكي', icon: '🤖', href: '/dashboard/ai-chat' },
      { id: 'export', label: 'تصدير البيانات', icon: '📤', href: '/dashboard/export' },
      { id: 'delegates', label: 'المفوضين', icon: '🔐', href: '/dashboard/delegates', roles: ['super_admin','owner'] },
      { id: 'announcements', label: 'الإعلانات', icon: '📣', href: '/dashboard/announcements' },
    ]},
    { title: 'الإعدادات والنظام', roles: ['super_admin','owner','admin'], items: [
      { id: 'settings', label: 'الإعدادات', icon: '⚙️', href: '/dashboard/settings' },
      { id: 'permissions', label: 'الصلاحيات', icon: '🔑', href: '/dashboard/permissions', roles: ['super_admin','owner'] },
      { id: 'emergency-keys', label: 'مفاتيح الطوارئ', icon: '🗝️', href: '/dashboard/emergency-keys', roles: ['super_admin','owner'] },
      { id: 'integrations', label: 'التكاملات', icon: '🔗', href: '/dashboard/integrations', roles: ['super_admin'] },
      { id: 'support', label: 'الدعم الفني', icon: '🎧', href: '/dashboard/support' },
      { id: 'knowledge-base', label: 'قاعدة المعرفة', icon: '📖', href: '/dashboard/knowledge-base' },
      { id: 'training', label: 'التدريب', icon: '🎓', href: '/dashboard/training' },
      { id: 'backup', label: 'النسخ الاحتياطي', icon: '💾', href: '/dashboard/backup', roles: ['super_admin'] },
    ]},
    { title: 'التطبيقات', roles: ['super_admin'], items: [
      { id: 'apps', label: 'إدارة التطبيقات', icon: '📱', href: '/dashboard/apps' },
      { id: 'push-notifications', label: 'إشعارات الجوال', icon: '🔔', href: '/dashboard/push-notifications' },
    ]},
    { title: 'المطورين', roles: ['super_admin'], items: [
      { id: 'api', label: 'API للمطورين', icon: '🔌', href: '/dashboard/api' },
      { id: 'webhooks', label: 'Webhooks', icon: '🔗', href: '/dashboard/webhooks' },
      { id: 'error-logs', label: 'سجل الأخطاء', icon: '🐛', href: '/dashboard/error-logs' },
    ]},
  ];

  const filteredSections = allSections
    .filter(section => {
      if (!userRole) return true;
      if (userRole === 'super_admin') return true;
      return section.roles.includes(userRole) && (!section.packages || section.packages.includes(userPackage));
    })
    .map(section => ({
      ...section,
      items: section.items.filter(item => {
        if (!userRole || userRole === 'super_admin') return true;
        if ((item as any).roles && !(item as any).roles.includes(userRole)) return false;
        if ((item as any).packages && !(item as any).packages.includes(userPackage)) return false;
        return true;
      })
    }))
    .filter(section => section.items.length > 0);

  const toggleSection = (title: string) => {
    setOpenSections(prev => prev.includes(title) ? prev.filter(s => s !== title) : [...prev, title]);
  };

  const roleLabels: any = {
    super_admin: '👑 مالك المنصة',
    owner: '🏫 مالك مدرسة',
    admin: '🔧 مدير',
    teacher: '👨‍🏫 معلم',
    parent: '👨‍👧 ولي أمر',
    student: '🎓 طالب'
  };

  const sidebarWidth = isMobile ? '85vw' : isTablet ? 280 : 260;

  return (
    <>
      {isOverlay && isOpen && (
        <div onClick={onClose} style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.6)', zIndex: 998 }} />
      )}
      <aside style={{
        width: sidebarWidth,
        height: '100vh',
        background: '#0A1628',
        borderLeft: '1px solid rgba(255,255,255,0.06)',
        position: isOverlay ? 'fixed' : 'sticky',
        top: 0,
        right: isOverlay ? (isOpen ? 0 : '-100%') : 0,
        zIndex: 999,
        transition: 'right 0.3s ease',
        display: 'flex',
        flexDirection: 'column',
        overflowY: 'auto',
      }}>
        {/* Logo */}
        <div style={{ padding: '20px 16px', borderBottom: '1px solid rgba(255,255,255,0.06)', textAlign: 'center' }}>
          <Link href="/dashboard" style={{ textDecoration: 'none' }}>
            <div style={{ fontSize: 28, fontWeight: 900, background: 'linear-gradient(135deg, #C9A227 0%, #D4B03D 100%)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>متين</div>
          </Link>
          {userRole && (
            <div style={{ marginTop: 8, background: 'rgba(201,162,39,0.1)', borderRadius: 8, padding: '4px 12px', display: 'inline-block' }}>
              <span style={{ color: '#C9A227', fontSize: 11, fontWeight: 600 }}>{roleLabels[userRole] || userRole}</span>
            </div>
          )}
        </div>

        {/* Menu */}
        <div style={{ flex: 1, padding: '12px 8px', overflowY: 'auto' }}>
          {filteredSections.map((section) => (
            <div key={section.title} style={{ marginBottom: 4 }}>
              <button
                onClick={() => toggleSection(section.title)}
                style={{ width: '100%', display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 12px', background: 'none', border: 'none', cursor: 'pointer', borderRadius: 8 }}
              >
                <span style={{ color: 'rgba(255,255,255,0.4)', fontSize: 12, fontWeight: 700 }}>{section.title}</span>
                <span style={{ color: 'rgba(255,255,255,0.3)', fontSize: 10, transition: 'transform 0.2s', transform: openSections.includes(section.title) ? 'rotate(90deg)' : 'rotate(0deg)' }}>◀</span>
              </button>
              {openSections.includes(section.title) && (
                <div>
                  {section.items.map((item) => {
                    const isActive = pathname === item.href;
                    return (
                      <Link key={item.id} href={item.href} onClick={() => isOverlay && onClose()} style={{ textDecoration: 'none' }}>
                        <div style={{
                          display: 'flex', alignItems: 'center', gap: 10, padding: '9px 12px 9px 36px', borderRadius: 8, margin: '1px 0',
                          background: isActive ? 'rgba(201,162,39,0.12)' : 'transparent',
                          borderRight: isActive ? '3px solid #C9A227' : '3px solid transparent',
                        }}>
                          <span style={{ fontSize: 16 }}>{item.icon}</span>
                          <span style={{ color: isActive ? '#C9A227' : 'rgba(255,255,255,0.65)', fontSize: 13, fontWeight: isActive ? 700 : 500 }}>{item.label}</span>
                        </div>
                      </Link>
                    );
                  })}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Footer */}
        <div style={{ padding: '12px 16px', borderTop: '1px solid rgba(255,255,255,0.06)', textAlign: 'center' }}>
          <button
            onClick={() => {
              localStorage.removeItem('matin_user');
              localStorage.removeItem('matin_token');
              fetch('/api/auth/logout', { method: 'POST' }).then(() => window.location.href = '/login');
            }}
            style={{ width: '100%', background: 'rgba(239,68,68,0.08)', color: '#EF4444', border: '1px solid rgba(239,68,68,0.15)', borderRadius: 10, padding: '10px', cursor: 'pointer', fontSize: 13, fontWeight: 600 }}
          >
            🚪 تسجيل الخروج
          </button>
          <div style={{ marginTop: 8, color: 'rgba(255,255,255,0.2)', fontSize: 11 }}>مطوّر بواسطة متين</div>
        </div>
      </aside>
    </>
  );
}
