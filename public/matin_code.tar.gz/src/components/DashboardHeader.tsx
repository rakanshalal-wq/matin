'use client';
import { useState, useEffect, useCallback } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

interface Notification {
  id: number;
  title: string;
  content?: string;
  type: string;
  is_read: boolean;
  created_at: string;
}

export default function DashboardHeader({ onMenuClick, showMenuButton = true }: { onMenuClick: () => void; showMenuButton?: boolean }) {
  const [user, setUser] = useState<any>(null);
  const [showDropdown, setShowDropdown] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const [isTablet, setIsTablet] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loadingNotif, setLoadingNotif] = useState(false);
  const router = useRouter();

  useEffect(() => {
    const userData = localStorage.getItem('matin_user');
    if (userData) { setUser(JSON.parse(userData)); }
  }, []);

  useEffect(() => {
    const checkScreen = () => {
      const w = window.innerWidth;
      setIsMobile(w < 768);
      setIsTablet(w >= 768 && w < 1024);
    };
    checkScreen();
    window.addEventListener('resize', checkScreen);
    return () => window.removeEventListener('resize', checkScreen);
  }, []);

  const fetchNotifications = useCallback(async () => {
    const token = localStorage.getItem('matin_token');
    if (!token) return;
    setLoadingNotif(true);
    try {
      const res = await fetch('/api/notifications?limit=10', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setNotifications(Array.isArray(data) ? data : (data.notifications || []));
      }
    } catch (e) {
      console.error('فشل جلب الإشعارات', e);
    } finally {
      setLoadingNotif(false);
    }
  }, []);

  useEffect(() => {
    fetchNotifications();
    // تحديث كل دقيقة
    const interval = setInterval(fetchNotifications, 60000);
    return () => clearInterval(interval);
  }, [fetchNotifications]);

  const markAllRead = async () => {
    const token = localStorage.getItem('matin_token');
    if (!token) return;
    try {
      await fetch('/api/notifications/mark-read', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ all: true })
      });
      setNotifications(prev => prev.map(n => ({ ...n, is_read: true })));
    } catch (e) {
      // تحديث محلي فقط إن فشل الـ API
      setNotifications(prev => prev.map(n => ({ ...n, is_read: true })));
    }
  };

  const formatTime = (dateStr: string) => {
    try {
      const date = new Date(dateStr);
      const now = new Date();
      const diff = Math.floor((now.getTime() - date.getTime()) / 1000);
      if (diff < 60) return 'الآن';
      if (diff < 3600) return `منذ ${Math.floor(diff / 60)} دقيقة`;
      if (diff < 86400) return `منذ ${Math.floor(diff / 3600)} ساعة`;
      return `منذ ${Math.floor(diff / 86400)} يوم`;
    } catch { return ''; }
  };

  const handleLogout = async () => {
    localStorage.removeItem('matin_user'); localStorage.removeItem('matin_token'); await fetch('/api/auth/logout', { method: 'POST' });
    router.push('/login');
  };

  const roleLabels: any = { super_admin: '👑 مالك المنصة', owner: '🏫 مالك مدارس', admin: '🔧 مدير', teacher: '👨‍🏫 معلم', parent: '👨‍👧 ولي أمر', student: '🎓 طالب' };
  const roleColors: any = { super_admin: '#C9A227', owner: '#8B5CF6', admin: '#3B82F6', teacher: '#10B981', parent: '#F59E0B', student: '#EC4899' };
  const unreadCount = notifications.filter(n => !n.is_read).length;

  return (
    <header style={{
      background: 'rgba(13, 27, 42, 0.98)',
      backdropFilter: 'blur(10px)',
      borderBottom: '1px solid rgba(201, 162, 39, 0.2)',
      padding: isMobile ? '10px 12px' : isTablet ? '10px 16px' : '12px 24px',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      position: 'sticky', top: 0, zIndex: 30, gap: 8,
    }}>
      {/* يسار - زر القائمة + لوجو */}
      <div style={{ display: 'flex', alignItems: 'center', gap: isMobile ? 8 : 12, minWidth: 0 }}>
        {showMenuButton && (
          <button onClick={onMenuClick} style={{
            background: 'linear-gradient(135deg, #C9A227 0%, #D4B03D 100%)',
            border: 'none', color: '#0D1B2A', borderRadius: 10,
            width: isMobile ? 36 : 40, height: isMobile ? 36 : 40,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            cursor: 'pointer', fontSize: isMobile ? 16 : 18, flexShrink: 0,
          }}>☰</button>
        )}
        <Link href="/dashboard" style={{ display: 'flex', alignItems: 'center', gap: 8, textDecoration: 'none', minWidth: 0 }}>
          <div style={{ width: isMobile ? 30 : 36, height: isMobile ? 30 : 36, borderRadius: 10, background: 'linear-gradient(135deg, #C9A227 0%, #D4B03D 100%)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: isMobile ? 16 : 20, flexShrink: 0 }}>🎓</div>
          {!isMobile && <span style={{ color: '#C9A227', fontWeight: 800, fontSize: isTablet ? 16 : 20, letterSpacing: 1 }}>متين</span>}
        </Link>
      </div>
      {/* يمين - الإشعارات + الحساب */}
      <div style={{ display: 'flex', alignItems: 'center', gap: isMobile ? 6 : 12 }}>
        {/* الإشعارات */}
        <div style={{ position: 'relative' }}>
          <button onClick={() => { setShowNotifications(!showNotifications); setShowDropdown(false); if (!showNotifications) fetchNotifications(); }} style={{
            background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)',
            borderRadius: 10, width: 40, height: 40, display: 'flex', alignItems: 'center', justifyContent: 'center',
            cursor: 'pointer', fontSize: 18, position: 'relative', color: 'white'
          }}>
            🔔
            {unreadCount > 0 && (
              <span style={{ position: 'absolute', top: -2, right: -2, width: 18, height: 18, borderRadius: '50%', background: '#EF4444', color: 'white', fontSize: 10, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                {unreadCount > 9 ? '9+' : unreadCount}
              </span>
            )}
          </button>
          {showNotifications && (
            <div style={{ position: 'absolute', left: 0, top: 48, width: 320, background: '#0D1B2A', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 14, overflow: 'hidden', boxShadow: '0 20px 60px rgba(0,0,0,0.5)', zIndex: 100 }}>
              <div style={{ padding: '14px 16px', borderBottom: '1px solid rgba(255,255,255,0.08)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ color: 'white', fontWeight: 700, fontSize: 15 }}>🔔 الإشعارات</span>
                {unreadCount > 0 && (
                  <span onClick={markAllRead} style={{ color: '#C9A227', fontSize: 12, cursor: 'pointer' }}>تحديد الكل كمقروء</span>
                )}
              </div>
              {loadingNotif ? (
                <div style={{ padding: '20px', textAlign: 'center', color: 'rgba(255,255,255,0.4)', fontSize: 13 }}>جاري التحميل...</div>
              ) : notifications.length === 0 ? (
                <div style={{ padding: '20px', textAlign: 'center', color: 'rgba(255,255,255,0.4)', fontSize: 13 }}>لا توجد إشعارات</div>
              ) : (
                notifications.map(n => (
                  <div key={n.id} style={{ padding: '12px 16px', borderBottom: '1px solid rgba(255,255,255,0.05)', background: !n.is_read ? 'rgba(201,162,39,0.04)' : 'transparent' }}>
                    <div style={{ color: 'white', fontSize: 13, fontWeight: !n.is_read ? 700 : 500 }}>{n.title}</div>
                    {n.content && <div style={{ color: 'rgba(255,255,255,0.5)', fontSize: 12, marginTop: 2 }}>{n.content}</div>}
                    <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: 11, marginTop: 4 }}>{formatTime(n.created_at)}</div>
                  </div>
                ))
              )}
              <div style={{ padding: '10px 16px', borderTop: '1px solid rgba(255,255,255,0.08)', textAlign: 'center' }}>
                <Link href="/dashboard/notifications" style={{ color: '#C9A227', fontSize: 12, textDecoration: 'none' }} onClick={() => setShowNotifications(false)}>عرض كل الإشعارات</Link>
              </div>
            </div>
          )}
        </div>
        {/* الحساب */}
        <div style={{ position: 'relative' }}>
          <button onClick={() => { setShowDropdown(!showDropdown); setShowNotifications(false); }} style={{
            background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)',
            borderRadius: 10, padding: '6px 12px', display: 'flex', alignItems: 'center', gap: 8,
            cursor: 'pointer', color: 'white'
          }}>
            <div style={{ width: 32, height: 32, borderRadius: 8, background: 'rgba(201,162,39,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16 }}>
              {user?.avatar || '👤'}
            </div>
            {!isMobile && (
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontSize: 13, fontWeight: 600 }}>{user?.name || 'المستخدم'}</div>
                <div style={{ fontSize: 10, color: roleColors[user?.role] || '#6B7280', fontWeight: 600 }}>{roleLabels[user?.role] || ''}</div>
              </div>
            )}
          </button>
          {showDropdown && (
            <div style={{ position: 'absolute', left: 0, top: 52, width: 220, background: '#0D1B2A', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 14, overflow: 'hidden', boxShadow: '0 20px 60px rgba(0,0,0,0.5)', zIndex: 100 }}>
              <div style={{ padding: '16px', borderBottom: '1px solid rgba(255,255,255,0.08)', textAlign: 'center' }}>
                <div style={{ width: 48, height: 48, borderRadius: 12, background: 'rgba(201,162,39,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 28, margin: '0 auto 8px' }}>{user?.avatar || '👤'}</div>
                <div style={{ color: 'white', fontWeight: 700, fontSize: 14 }}>{user?.name}</div>
                <span style={{ background: `rgba(201,162,39,0.15)`, color: roleColors[user?.role] || '#6B7280', padding: '2px 10px', borderRadius: 6, fontSize: 11, fontWeight: 600, display: 'inline-block', marginTop: 6 }}>
                  {roleLabels[user?.role] || ''}
                </span>
              </div>
              <button onClick={() => { router.push('/dashboard/settings'); setShowDropdown(false); }} style={{ width: '100%', background: 'none', border: 'none', padding: '12px 16px', color: 'rgba(255,255,255,0.7)', fontSize: 13, cursor: 'pointer', textAlign: 'right', display: 'flex', alignItems: 'center', gap: 8 }}>⚙️ الإعدادات</button>
              <button onClick={handleLogout} style={{ width: '100%', background: 'none', border: 'none', padding: '12px 16px', color: '#EF4444', fontSize: 13, cursor: 'pointer', textAlign: 'right', display: 'flex', alignItems: 'center', gap: 8, borderTop: '1px solid rgba(255,255,255,0.06)' }}>🚪 تسجيل الخروج</button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
