'use client';
import { useState, useEffect } from 'react';
import { usePathname } from 'next/navigation';
import Link from 'next/link';

export default function Sidebar({ isOpen, onClose, screenSize = 'desktop', userRole: userRoleProp }: {
  isOpen: boolean;
  onClose: () => void;
  screenSize?: 'mobile' | 'tablet' | 'desktop';
  userRole?: string; // ✅ استقبال الدور من layout مباشرة (من السيرفر)
}) {
  const pathname = usePathname();
  // ✅ الدور يأتي من السيرفر عبر layout، مش من localStorage
  const [userRole, setUserRole] = useState(userRoleProp || '');
  const [openSections, setOpenSections] = useState<string[]>([]);

  const isMobile = screenSize === 'mobile';
  const isTablet = screenSize === 'tablet';
  const isOverlay = isMobile || isTablet;
  const sidebarWidth = isMobile ? '85vw' : isTablet ? 280 : 260;

  // ✅ تحديث الدور لما يتغير من layout
  useEffect(() => {
    if (userRoleProp) {
      setUserRole(userRoleProp);
    } else {
      // fallback من localStorage فقط لو ما وصل prop
      try {
        const u = JSON.parse(localStorage.getItem('matin_user') || '{}');
        setUserRole(u.role || '');
      } catch {}
    }
  }, [userRoleProp]);

  // ✅ افتح الـ section النشطة تلقائياً عند التنقل
  useEffect(() => {
    const menu = getMenu();
    for (const section of menu) {
      if (section.items.some(item => pathname === item.href || pathname.startsWith(item.href + '/'))) {
        setOpenSections(prev => prev.includes(section.title) ? prev : [...prev, section.title]);
      }
    }
  }, [pathname, userRole]);

  const toggleSection = (title: string) => {
    setOpenSections(prev =>
      prev.includes(title) ? prev.filter(s => s !== title) : [...prev, title]
    );
  };

  const logout = () => {
    localStorage.removeItem('matin_user');
    localStorage.removeItem('matin_token');
    fetch('/api/auth/logout', { method: 'POST' }).then(() => {
      window.location.href = '/login';
    });
  };

  // ══════════════════════════════════════════
  // قائمة مالك المنصة — مستقلة كلياً
  // ══════════════════════════════════════════
  const superAdminMenu = [
    {
      title: 'الرئيسية',
      items: [
        { label: 'لوحة التحكم', icon: '👑', href: '/dashboard' },
        { label: 'إحصاءات المنصة', icon: '📊', href: '/dashboard/platform-analytics' },
      ],
    },
    {
      title: 'إدارة المؤسسات',
      items: [
        { label: 'المدارس والمؤسسات', icon: '🏫', href: '/dashboard/schools' },
        { label: 'إضافة مؤسسة', icon: '➕', href: '/dashboard/schools/add' },
        { label: 'الاشتراكات والباقات', icon: '💎', href: '/dashboard/subscriptions' },
        { label: 'فواتير المؤسسات', icon: '🧾', href: '/dashboard/school-invoices' },
        { label: 'كوبونات الخصم', icon: '🏷', href: '/dashboard/coupons' },
      ],
    },
    {
      title: 'الصفحة الرئيسية',
      items: [
        { label: 'الأخبار', icon: '📰', href: '/dashboard/news' },
        { label: 'الإعلانات', icon: '📢', href: '/dashboard/ads' },
        { label: 'معرض الصور', icon: '🖼', href: '/dashboard/gallery' },
        { label: 'الفيديوهات', icon: '🎥', href: '/dashboard/videos' },
        { label: 'تنسيق الصفحات', icon: '🎨', href: '/dashboard/page-design' },
      ],
    },
    {
      title: 'المحتوى المركزي',
      items: [
        { label: 'المتجر المركزي', icon: '🛒', href: '/dashboard/store' },
        { label: 'المكتبة الرقمية', icon: '📚', href: '/dashboard/library' },
      ],
    },
    {
      title: 'المالية',
      items: [
        { label: 'التقارير المالية', icon: '💰', href: '/dashboard/finance' },
        { label: 'العمولات', icon: '📈', href: '/dashboard/commissions' },
      ],
    },
    {
      title: 'التواصل',
      items: [
        { label: 'إشعارات الجوال', icon: '🔔', href: '/dashboard/push-notifications' },
        { label: 'الدعم الفني', icon: '🎧', href: '/dashboard/support' },
      ],
    },
    {
      title: 'إدارة النظام',
      items: [
        { label: 'إدارة المستخدمين', icon: '👥', href: '/dashboard/users' },
        { label: 'التكاملات', icon: '🔗', href: '/dashboard/integrations' },
        { label: 'الصلاحيات', icon: '🔑', href: '/dashboard/permissions' },
        { label: 'إعدادات المنصة', icon: '⚙️', href: '/dashboard/settings' },
        { label: 'مفاتيح الطوارئ', icon: '🗝️', href: '/dashboard/emergency-keys' },
      ],
    },
    {
      title: 'السجلات والمطورين',
      items: [
        { label: 'سجل العمليات', icon: '📋', href: '/dashboard/activity-log' },
        { label: 'سجل الأخطاء', icon: '🐛', href: '/dashboard/error-logs' },
        { label: 'النسخ الاحتياطي', icon: '💾', href: '/dashboard/backup' },
        { label: 'API للمطورين', icon: '🔌', href: '/dashboard/api' },
        { label: 'Webhooks', icon: '🔗', href: '/dashboard/webhooks' },
      ],
    },
  ];

  // ══════════════════════════════════════════
  // قائمة مالك المدرسة
  // ══════════════════════════════════════════
  const ownerMenu = [
    {
      title: 'الرئيسية',
      items: [
        { label: 'لوحة التحكم', icon: '🏠', href: '/dashboard' },
      ],
    },
    {
      title: 'المؤسسة',
      items: [
        { label: 'مدارسي', icon: '🏫', href: '/dashboard/schools' },
        { label: 'طلبات الانضمام', icon: '📋', href: '/dashboard/admission' },
        { label: 'الباقة والاشتراك', icon: '💎', href: '/dashboard/subscriptions' },
      ],
    },
    {
      title: 'الأشخاص',
      items: [
        { label: 'الطلاب', icon: '👨‍🎓', href: '/dashboard/students' },
        { label: 'المعلمين', icon: '👩‍🏫', href: '/dashboard/teachers' },
        { label: 'الموظفين', icon: '👔', href: '/dashboard/employees' },
        { label: 'أولياء الأمور', icon: '👨‍👩‍👧', href: '/dashboard/parents' },
      ],
    },
    {
      title: 'الأكاديمي',
      items: [
        { label: 'الفصول', icon: '🏛', href: '/dashboard/classes' },
        { label: 'المواد', icon: '📊', href: '/dashboard/subjects' },
        { label: 'الجداول', icon: '📅', href: '/dashboard/schedules' },
        { label: 'الحضور', icon: '✋', href: '/dashboard/attendance' },
      ],
    },
    {
      title: 'الاختبارات',
      items: [
        { label: 'الاختبارات', icon: '📝', href: '/dashboard/exams' },
        { label: 'بنك الأسئلة', icon: '❓', href: '/dashboard/question-bank' },
        { label: 'الدرجات', icon: '📊', href: '/dashboard/grades' },
      ],
    },
    {
      title: 'المالية',
      items: [
        { label: 'المالية', icon: '💰', href: '/dashboard/finance' },
        { label: 'الرواتب', icon: '💵', href: '/dashboard/salaries' },
        { label: 'المنح والخصومات', icon: '🎁', href: '/dashboard/scholarships' },
      ],
    },
    {
      title: 'التواصل',
      items: [
        { label: 'الرسائل', icon: '✉️', href: '/dashboard/messages' },
        { label: 'الإشعارات', icon: '🔔', href: '/dashboard/notifications' },
        { label: 'الشكاوى', icon: '📢', href: '/dashboard/complaints' },
      ],
    },
    {
      title: 'الإعدادات',
      items: [
        { label: 'إعدادات المدرسة', icon: '⚙️', href: '/dashboard/settings' },
        { label: 'الصلاحيات', icon: '🔑', href: '/dashboard/permissions' },
        { label: 'التقارير', icon: '📈', href: '/dashboard/reports' },
        { label: 'المساعد الذكي', icon: '🤖', href: '/dashboard/ai-assistant' },
      ],
    },
  ];

  // ══════════════════════════════════════════
  // قائمة المعلم
  // ══════════════════════════════════════════
  const teacherMenu = [
    {
      title: 'الرئيسية',
      items: [{ label: 'لوحة التحكم', icon: '🏠', href: '/dashboard' }],
    },
    {
      title: 'الفصول والطلاب',
      items: [
        { label: 'فصولي', icon: '🏛', href: '/dashboard/classes' },
        { label: 'الحضور', icon: '✋', href: '/dashboard/attendance' },
        { label: 'الدرجات', icon: '📊', href: '/dashboard/grades' },
        { label: 'السلوك', icon: '📋', href: '/dashboard/behavior' },
      ],
    },
    {
      title: 'التدريس',
      items: [
        { label: 'الاختبارات', icon: '📝', href: '/dashboard/exams' },
        { label: 'بنك الأسئلة', icon: '❓', href: '/dashboard/question-bank' },
        { label: 'الواجبات', icon: '📒', href: '/dashboard/homework' },
        { label: 'المحاضرات', icon: '🎤', href: '/dashboard/lectures' },
        { label: 'الجدول', icon: '📅', href: '/dashboard/schedules' },
      ],
    },
    {
      title: 'التواصل',
      items: [
        { label: 'الرسائل', icon: '✉️', href: '/dashboard/messages' },
        { label: 'المساعد الذكي', icon: '🤖', href: '/dashboard/ai-assistant' },
      ],
    },
  ];

  // ══════════════════════════════════════════
  // قائمة الطالب
  // ══════════════════════════════════════════
  const studentMenu = [
    {
      title: 'الرئيسية',
      items: [{ label: 'لوحة التحكم', icon: '🏠', href: '/dashboard' }],
    },
    {
      title: 'دراستي',
      items: [
        { label: 'جدولي', icon: '📅', href: '/dashboard/schedules' },
        { label: 'درجاتي', icon: '📊', href: '/dashboard/grades' },
        { label: 'واجباتي', icon: '📒', href: '/dashboard/homework' },
        { label: 'اختباراتي', icon: '📝', href: '/dashboard/exams' },
        { label: 'محاضراتي', icon: '🎤', href: '/dashboard/lectures' },
        { label: 'حضوري', icon: '✋', href: '/dashboard/attendance' },
      ],
    },
    {
      title: 'التواصل',
      items: [
        { label: 'الرسائل', icon: '✉️', href: '/dashboard/messages' },
      ],
    },
  ];

  // ══════════════════════════════════════════
  // قائمة ولي الأمر
  // ══════════════════════════════════════════
  const parentMenu = [
    {
      title: 'الرئيسية',
      items: [{ label: 'لوحة التحكم', icon: '🏠', href: '/dashboard' }],
    },
    {
      title: 'أبنائي',
      items: [
        { label: 'متابعة الأبناء', icon: '👨‍👧', href: '/dashboard/parent' },
        { label: 'الحضور', icon: '✋', href: '/dashboard/attendance' },
        { label: 'الدرجات', icon: '📊', href: '/dashboard/grades' },
        { label: 'تتبع الباص', icon: '📍', href: '/dashboard/student-tracking' },
      ],
    },
    {
      title: 'التواصل',
      items: [
        { label: 'الرسائل', icon: '✉️', href: '/dashboard/messages' },
        { label: 'مجلس الآباء', icon: '👨‍👩‍👧‍👦', href: '/dashboard/parents-council' },
        { label: 'المدفوعات', icon: '💰', href: '/dashboard/finance' },
      ],
    },
  ];

  const getMenu = () => {
    switch (userRole) {
      case 'super_admin': return superAdminMenu;
      case 'owner':
      case 'admin': return ownerMenu;
      case 'teacher': return teacherMenu;
      case 'student': return studentMenu;
      case 'parent': return parentMenu;
      default: return [];
    }
  };

  const roleLabel: any = {
    super_admin: '👑 مالك المنصة',
    owner: '🏫 مالك مدرسة',
    admin: '🔧 مدير',
    teacher: '👨‍🏫 معلم',
    parent: '👨‍👧 ولي أمر',
    student: '🎓 طالب',
  };

  const menu = getMenu();

  return (
    <>
      {isOverlay && isOpen && (
        <div onClick={onClose} style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.6)', zIndex: 998 }} />
      )}
      <aside style={{
        width: sidebarWidth,
        height: '100vh',
        background: '#0A1628',
        borderLeft: '1px solid rgba(255,255,255,0.06)',
        position: isOverlay ? 'fixed' : 'sticky',
        top: 0,
        right: isOverlay ? (isOpen ? 0 : '-100%') : 0,
        zIndex: 999,
        transition: 'right 0.3s ease',
        display: 'flex',
        flexDirection: 'column',
        overflowY: 'auto',
      }}>

        {/* Logo */}
        <div style={{ padding: '20px 16px', borderBottom: '1px solid rgba(255,255,255,0.06)', textAlign: 'center' }}>
          <Link href="/dashboard" style={{ textDecoration: 'none' }}>
            <div style={{
              fontSize: 28, fontWeight: 900,
              background: 'linear-gradient(135deg, #C9A227 0%, #D4B03D 100%)',
              WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
            }}>متين</div>
          </Link>
          {userRole && (
            <div style={{ marginTop: 8, background: 'rgba(201,162,39,0.1)', borderRadius: 8, padding: '4px 12px', display: 'inline-block' }}>
              <span style={{ color: '#C9A227', fontSize: 11, fontWeight: 600 }}>
                {roleLabel[userRole] || userRole}
              </span>
            </div>
          )}
        </div>

        {/* Menu */}
        <div style={{ flex: 1, padding: '12px 8px', overflowY: 'auto' }}>
          {menu.map((section) => (
            <div key={section.title} style={{ marginBottom: 4 }}>
              <button
                onClick={() => toggleSection(section.title)}
                style={{
                  width: '100%', display: 'flex', justifyContent: 'space-between',
                  alignItems: 'center', padding: '10px 12px',
                  background: 'none', border: 'none', cursor: 'pointer', borderRadius: 8,
                }}
              >
                <span style={{ color: 'rgba(255,255,255,0.4)', fontSize: 12, fontWeight: 700 }}>
                  {section.title}
                </span>
                <span style={{
                  color: 'rgba(255,255,255,0.3)', fontSize: 10,
                  transition: 'transform 0.2s',
                  transform: openSections.includes(section.title) ? 'rotate(90deg)' : 'rotate(0deg)',
                }}>◀</span>
              </button>

              {openSections.includes(section.title) && (
                <div>
                  {section.items.map((item) => {
                    const isActive = pathname === item.href;
                    return (
                      <Link
                        key={item.href}
                        href={item.href}
                        onClick={() => isOverlay && onClose()}
                        style={{ textDecoration: 'none' }}
                      >
                        <div style={{
                          display: 'flex', alignItems: 'center', gap: 10,
                          padding: '9px 12px 9px 36px', borderRadius: 8, margin: '1px 0',
                          background: isActive ? 'rgba(201,162,39,0.12)' : 'transparent',
                          borderRight: isActive ? '3px solid #C9A227' : '3px solid transparent',
                          transition: 'background 0.15s',
                        }}
                          onMouseEnter={e => { if (!isActive) (e.currentTarget as HTMLDivElement).style.background = 'rgba(255,255,255,0.04)'; }}
                          onMouseLeave={e => { if (!isActive) (e.currentTarget as HTMLDivElement).style.background = 'transparent'; }}
                        >
                          <span style={{ fontSize: 16 }}>{item.icon}</span>
                          <span style={{
                            color: isActive ? '#C9A227' : 'rgba(255,255,255,0.65)',
                            fontSize: 13,
                            fontWeight: isActive ? 700 : 500,
                          }}>{item.label}</span>
                        </div>
                      </Link>
                    );
                  })}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Footer */}
        <div style={{ padding: '12px 16px', borderTop: '1px solid rgba(255,255,255,0.06)', textAlign: 'center' }}>
          <button
            onClick={logout}
            style={{
              width: '100%', background: 'rgba(239,68,68,0.08)', color: '#EF4444',
              border: '1px solid rgba(239,68,68,0.15)', borderRadius: 10,
              padding: '10px', cursor: 'pointer', fontSize: 13, fontWeight: 600,
            }}
          >
            🚪 تسجيل الخروج
          </button>
          <div style={{ marginTop: 8, color: 'rgba(255,255,255,0.2)', fontSize: 11 }}>مطوّر بواسطة متين</div>
        </div>
      </aside>
    </>
  );
}
