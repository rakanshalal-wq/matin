import Link from 'next/link';

// ============================================
// 🎨 إعدادات قابلة للتغيير من الداشبورد
// ============================================
const siteConfig = {
  // الخلفية الرئيسية (لون أو صورة)
  mainBackground: 'linear-gradient(135deg, #0D1B2A 0%, #1B263B 50%, #243B53 100%)',
  // mainBackground: 'url(/images/background.jpg)',
  
  // الألوان
  primaryColor: '#C9A227',
  secondaryColor: '#D4B03D',
  darkColor: '#0D1B2A',
  
  // الشعار
  logoText: 'متين',
  logoIcon: 'م',
  
  // معلومات التواصل
  email: 'rakanshalal@gmail.com',
  phone: '0551355514',
  website: 'matin.ink',
  location: 'المملكة العربية السعودية',
};

// ============================================
// 🖼️ الإعلانات (قابلة للتغيير من الداشبورد)
// ============================================
const advertisements = [
  { id: 1, image: null, title: 'إعلان 1', link: '#', bgColor: 'rgba(201, 162, 39, 0.2)' },
  { id: 2, image: null, title: 'إعلان 2', link: '#', bgColor: 'rgba(59, 130, 246, 0.2)' },
  { id: 3, image: null, title: 'إعلان 3', link: '#', bgColor: 'rgba(16, 185, 129, 0.2)' },
];

// ============================================
// 🏛️ الشركاء (قابلة للتغيير من الداشبورد) - بدون أسماء
// ============================================
const partners = [
  { id: 1, logo: null, icon: '🏛️' },
  { id: 2, logo: null, icon: '🎓' },
  { id: 3, logo: null, icon: '📚' },
  { id: 4, logo: null, icon: '🏫' },
  { id: 5, logo: null, icon: '⭐' },
  { id: 6, logo: null, icon: '🌟' },
];

// ============================================
// 🚌 الميزات المتقدمة (قابلة للتغيير من الداشبورد)
// ============================================
const advancedFeatures = [
  { id: 1, icon: '🚌', title: 'النقل المدرسي', desc: 'تتبع GPS مباشر وإشعارات فورية', link: '/transport', image: null },
  { id: 2, icon: '🏥', title: 'الصحة المدرسية', desc: 'ملفات صحية وتطعيمات', link: '/health', image: null },
  { id: 3, icon: '🍽️', title: 'الكافتيريا', desc: 'قوائم وطلبات ودفع إلكتروني', link: '/cafeteria', image: null },
  { id: 4, icon: '🎭', title: 'الأنشطة', desc: 'نوادي ومسابقات وفعاليات', link: '/activities', image: null },
  { id: 5, icon: '📚', title: 'المكتبة', desc: 'استعارة إلكترونية وكتالوج رقمي', link: '/library', image: null },
  { id: 6, icon: '💻', title: 'التعليم الإلكتروني', desc: 'فصول افتراضية ومحتوى تفاعلي', link: '/elearning', image: null },
  { id: 7, icon: '💰', title: 'الإدارة المالية', desc: 'فواتير ودفع وتقارير مالية', link: '/finance', image: null },
  { id: 8, icon: '⏰', title: 'الحضور والغياب', desc: 'تسجيل ذكي وإشعارات فورية', link: '/attendance', image: null },
  { id: 9, icon: '📝', title: 'الاختبارات', desc: 'تصحيح تلقائي وبنك أسئلة', link: '/exams', image: null },
  { id: 10, icon: '📅', title: 'الجداول', desc: 'توزيع ذكي بدون تعارضات', link: '/schedule', image: null },
];

export default function Home() {
  return (
    <>
      <link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet" />
      
      <div style={{ background: siteConfig.mainBackground, minHeight: '100vh', fontFamily: "'IBM Plex Sans Arabic', sans-serif" }} dir="rtl">
        
        {/* ===== NAVBAR ===== */}
        <nav style={{ position: 'sticky', top: 0, background: 'rgba(13, 27, 42, 0.95)', backdropFilter: 'blur(10px)', borderBottom: '1px solid rgba(201, 162, 39, 0.2)', zIndex: 1000, padding: '16px 0' }}>
          <div style={{ maxWidth: 1400, margin: '0 auto', padding: '0 24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <Link href="/" style={{ textDecoration: 'none', display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{ width: 52, height: 52, background: `linear-gradient(135deg, ${siteConfig.primaryColor} 0%, ${siteConfig.secondaryColor} 100%)`, borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 26, fontWeight: 800, color: siteConfig.darkColor }}>{siteConfig.logoIcon}</div>
              <span style={{ fontSize: 32, fontWeight: 900, color: siteConfig.primaryColor }}>{siteConfig.logoText}</span>
            </Link>
            <div style={{ display: 'flex', gap: 28, alignItems: 'center' }}>
              <Link href="/store" style={{ color: 'white', textDecoration: 'none', fontSize: 16, fontWeight: 500 }}>المتجر</Link>
              <Link href="/pricing" style={{ color: 'white', textDecoration: 'none', fontSize: 16, fontWeight: 500 }}>الأسعار</Link>
              <Link href="/about" style={{ color: 'white', textDecoration: 'none', fontSize: 16, fontWeight: 500 }}>عن متين</Link>
              <Link href="/contact" style={{ color: 'white', textDecoration: 'none', fontSize: 16, fontWeight: 500 }}>تواصل معنا</Link>
              <Link href="/login" style={{ padding: '12px 28px', background: `linear-gradient(135deg, ${siteConfig.primaryColor} 0%, ${siteConfig.secondaryColor} 100%)`, borderRadius: 10, color: siteConfig.darkColor, textDecoration: 'none', fontSize: 16, fontWeight: 700 }}>تسجيل الدخول</Link>
            </div>
          </div>
        </nav>

        {/* ===== HERO ===== */}
        <section style={{ padding: '100px 24px', textAlign: 'center' }}>
          <div style={{ maxWidth: 1200, margin: '0 auto' }}>
            <div style={{ display: 'inline-block', background: 'rgba(201, 162, 39, 0.1)', border: '1px solid rgba(201, 162, 39, 0.3)', borderRadius: 50, padding: '10px 28px', marginBottom: 28 }}>
              <span style={{ color: siteConfig.primaryColor, fontSize: 16, fontWeight: 600 }}>🚀 منصة تعليمية سعودية 100%</span>
            </div>
            <h1 style={{ fontSize: 72, fontWeight: 900, color: 'white', marginBottom: 28, lineHeight: 1.2 }}>
              نظام إدارة المدارس <span style={{ color: siteConfig.primaryColor }}>الأكثر تكاملاً</span>
            </h1>
            <p style={{ fontSize: 24, color: 'rgba(255, 255, 255, 0.8)', marginBottom: 48, maxWidth: 800, margin: '0 auto 48px' }}>
              حل شامل وذكي لإدارة المؤسسات التعليمية بالذكاء الاصطناعي متكامل مع الأنظمة الحكومية السعودية
            </p>
            <div style={{ display: 'flex', gap: 20, justifyContent: 'center', flexWrap: 'wrap', marginBottom: 48 }}>
              <Link href="/register" style={{ padding: '20px 56px', background: `linear-gradient(135deg, ${siteConfig.primaryColor} 0%, ${siteConfig.secondaryColor} 100%)`, borderRadius: 14, color: siteConfig.darkColor, textDecoration: 'none', fontSize: 22, fontWeight: 800, boxShadow: '0 8px 32px rgba(201, 162, 39, 0.4)' }}>🚀 ابدأ مجاناً</Link>
              <Link href="#video" style={{ padding: '20px 56px', background: 'rgba(255, 255, 255, 0.1)', border: '2px solid rgba(255, 255, 255, 0.3)', borderRadius: 14, color: 'white', textDecoration: 'none', fontSize: 22, fontWeight: 700 }}>▶️ شاهد الفيديو</Link>
            </div>
            <div style={{ display: 'flex', gap: 40, justifyContent: 'center', flexWrap: 'wrap' }}>
              <span style={{ color: 'rgba(255, 255, 255, 0.7)', fontSize: 16 }}>✓ بدون بطاقة ائتمانية</span>
              <span style={{ color: 'rgba(255, 255, 255, 0.7)', fontSize: 16 }}>✓ تجربة مجانية 14 يوم</span>
              <span style={{ color: 'rgba(255, 255, 255, 0.7)', fontSize: 16 }}>✓ دعم فني 24/7</span>
            </div>
          </div>
        </section>

        {/* ===== ADVERTISEMENTS - قسم الإعلانات الكبير ===== */}
        <section style={{ padding: '60px 24px', background: 'rgba(0, 0, 0, 0.3)' }}>
          <div style={{ maxWidth: 1400, margin: '0 auto' }}>
            <h2 style={{ fontSize: 36, fontWeight: 800, color: 'white', textAlign: 'center', marginBottom: 40 }}>
              <span style={{ color: siteConfig.primaryColor }}>إعلانات</span> مميزة
            </h2>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(400px, 1fr))', gap: 24 }}>
              {advertisements.map((ad) => (
                <a key={ad.id} href={ad.link} style={{ textDecoration: 'none' }}>
                  <div style={{ 
                    background: ad.image ? `url(${ad.image}) center/cover` : ad.bgColor, 
                    borderRadius: 20, 
                    height: 220,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    border: '2px solid rgba(255, 255, 255, 0.1)',
                    transition: 'transform 0.3s, box-shadow 0.3s',
                    cursor: 'pointer'
                  }}>
                    {!ad.image && (
                      <div style={{ textAlign: 'center' }}>
                        <div style={{ fontSize: 48, marginBottom: 12 }}>📢</div>
                        <div style={{ fontSize: 24, fontWeight: 700, color: 'white' }}>{ad.title}</div>
                        <div style={{ fontSize: 14, color: 'rgba(255,255,255,0.6)', marginTop: 8 }}>مساحة إعلانية</div>
                      </div>
                    )}
                  </div>
                </a>
              ))}
            </div>
          </div>
        </section>

        {/* ===== VIDEO ===== */}
        <section id="video" style={{ padding: '80px 24px', background: 'rgba(201, 162, 39, 0.03)' }}>
          <div style={{ maxWidth: 1100, margin: '0 auto', textAlign: 'center' }}>
            <h2 style={{ fontSize: 48, fontWeight: 900, color: 'white', marginBottom: 24 }}>شاهد <span style={{ color: siteConfig.primaryColor }}>متين</span> في دقيقتين</h2>
            <div style={{ background: 'rgba(0, 0, 0, 0.4)', borderRadius: 28, aspectRatio: '16/9', display: 'flex', alignItems: 'center', justifyContent: 'center', border: '3px solid rgba(201, 162, 39, 0.3)' }}>
              <div style={{ textAlign: 'center' }}>
                <div style={{ width: 100, height: 100, background: `linear-gradient(135deg, ${siteConfig.primaryColor} 0%, ${siteConfig.secondaryColor} 100%)`, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 40, margin: '0 auto 20px', cursor: 'pointer', boxShadow: '0 8px 32px rgba(201, 162, 39, 0.4)' }}>▶️</div>
                <p style={{ color: 'rgba(255, 255, 255, 0.6)', fontSize: 16 }}>الفيديو التعريفي - قريباً</p>
              </div>
            </div>
          </div>
        </section>

        {/* ===== FEATURES - المميزات الأساسية ===== */}
        <section style={{ padding: '100px 24px' }}>
          <div style={{ maxWidth: 1400, margin: '0 auto' }}>
            <h2 style={{ fontSize: 52, fontWeight: 900, color: 'white', textAlign: 'center', marginBottom: 60 }}>كل ما تحتاجه في <span style={{ color: siteConfig.primaryColor }}>منصة واحدة</span></h2>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: 28 }}>
              {[
                { icon: '📱', title: 'إدارة شاملة', desc: 'طلاب، معلمين، جداول، مالية - كل شيء في مكان واحد' },
                { icon: '☁️', title: 'سحابي 100%', desc: 'الوصول من أي مكان وأي جهاز بأمان تام' },
                { icon: '🔒', title: 'آمن ومشفر', desc: 'حماية متقدمة لبياناتك مع نسخ احتياطي يومي' },
                { icon: '🤖', title: 'ذكاء اصطناعي', desc: 'تحليلات ذكية وتقارير تنبؤية متقدمة' },
                { icon: '💬', title: 'تواصل فعّال', desc: 'إشعارات لحظية عبر الواتساب والإيميل والـ SMS' },
                { icon: '🔗', title: 'تكامل حكومي', desc: 'متصل بنور وأبشر وقوى وفارس والنفاذ الوطني' }
              ].map((f, i) => (
                <div key={i} style={{ background: 'rgba(255, 255, 255, 0.03)', border: '1px solid rgba(255, 255, 255, 0.08)', borderRadius: 24, padding: 40 }}>
                  <div style={{ fontSize: 64, marginBottom: 20 }}>{f.icon}</div>
                  <h3 style={{ fontSize: 24, fontWeight: 800, color: 'white', marginBottom: 12 }}>{f.title}</h3>
                  <p style={{ fontSize: 17, color: 'rgba(255, 255, 255, 0.7)', lineHeight: 1.7 }}>{f.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ===== ADVANCED FEATURES - الميزات المتقدمة (مربعات كبيرة) ===== */}
        <section style={{ padding: '100px 24px', background: 'rgba(201, 162, 39, 0.03)' }}>
          <div style={{ maxWidth: 1400, margin: '0 auto' }}>
            <h2 style={{ fontSize: 52, fontWeight: 900, color: 'white', textAlign: 'center', marginBottom: 20 }}>ميزات <span style={{ color: siteConfig.primaryColor }}>متقدمة</span></h2>
            <p style={{ fontSize: 20, color: 'rgba(255, 255, 255, 0.7)', textAlign: 'center', marginBottom: 60 }}>+30 ميزة - اضغط على أي ميزة لمعرفة المزيد</p>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: 24 }}>
              {advancedFeatures.map((f) => (
                <Link key={f.id} href={f.link} style={{ textDecoration: 'none' }}>
                  <div style={{ 
                    background: f.image ? `url(${f.image}) center/cover` : 'rgba(255, 255, 255, 0.05)', 
                    border: '2px solid rgba(255, 255, 255, 0.1)', 
                    borderRadius: 24, 
                    padding: 40, 
                    textAlign: 'center',
                    minHeight: 220,
                    display: 'flex',
                    flexDirection: 'column',
                    justifyContent: 'center',
                    transition: 'transform 0.3s, border-color 0.3s',
                    cursor: 'pointer'
                  }}>
                    <div style={{ fontSize: 72, marginBottom: 16 }}>{f.icon}</div>
                    <h3 style={{ fontSize: 22, fontWeight: 800, color: 'white', marginBottom: 8 }}>{f.title}</h3>
                    <p style={{ fontSize: 15, color: 'rgba(255, 255, 255, 0.6)', marginBottom: 12 }}>{f.desc}</p>
                    <div style={{ fontSize: 14, color: siteConfig.primaryColor, fontWeight: 600 }}>اعرف المزيد ←</div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>

        {/* ===== SOCIAL MEDIA SECTION - التواصل الاجتماعي ===== */}
        <section style={{ padding: '100px 24px', background: 'linear-gradient(135deg, rgba(59, 130, 246, 0.1) 0%, rgba(139, 92, 246, 0.1) 100%)' }}>
          <div style={{ maxWidth: 1200, margin: '0 auto' }}>
            <div style={{ textAlign: 'center', marginBottom: 60 }}>
              <div style={{ fontSize: 80, marginBottom: 24 }}>💬</div>
              <h2 style={{ fontSize: 52, fontWeight: 900, color: 'white', marginBottom: 20 }}>
                منصة <span style={{ color: siteConfig.primaryColor }}>التواصل الاجتماعي</span>
              </h2>
              <p style={{ fontSize: 20, color: 'rgba(255, 255, 255, 0.7)', maxWidth: 700, margin: '0 auto' }}>
                تواصل مع المعلمين والطلاب وأولياء الأمور في مكان واحد - شارك، ناقش، وتفاعل!
              </p>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: 24, marginBottom: 48 }}>
              {[
                { icon: '📝', title: 'نشر المحتوى', desc: 'شارك الأخبار والإعلانات والتحديثات' },
                { icon: '💭', title: 'التعليقات', desc: 'تفاعل مع المنشورات وأضف رأيك' },
                { icon: '👍', title: 'الإعجابات', desc: 'عبّر عن تقديرك للمحتوى المميز' },
                { icon: '🔔', title: 'الإشعارات', desc: 'تلقى تنبيهات فورية للتفاعلات الجديدة' }
              ].map((f, i) => (
                <div key={i} style={{ background: 'rgba(255, 255, 255, 0.05)', border: '1px solid rgba(255, 255, 255, 0.1)', borderRadius: 20, padding: 32, textAlign: 'center' }}>
                  <div style={{ fontSize: 48, marginBottom: 16 }}>{f.icon}</div>
                  <h3 style={{ fontSize: 20, fontWeight: 700, color: 'white', marginBottom: 8 }}>{f.title}</h3>
                  <p style={{ fontSize: 15, color: 'rgba(255, 255, 255, 0.6)' }}>{f.desc}</p>
                </div>
              ))}
            </div>
            <div style={{ textAlign: 'center' }}>
              <Link href="/community" style={{ 
                display: 'inline-flex', 
                alignItems: 'center', 
                gap: 12, 
                padding: '20px 48px', 
                background: `linear-gradient(135deg, ${siteConfig.primaryColor} 0%, ${siteConfig.secondaryColor} 100%)`, 
                borderRadius: 14, 
                color: siteConfig.darkColor, 
                textDecoration: 'none', 
                fontSize: 20, 
                fontWeight: 800,
                boxShadow: '0 8px 32px rgba(201, 162, 39, 0.4)'
              }}>
                💬 ادخل منصة التواصل
              </Link>
            </div>
          </div>
        </section>

        {/* ===== GOVERNMENT INTEGRATIONS ===== */}
        <section style={{ padding: '100px 24px' }}>
          <div style={{ maxWidth: 1400, margin: '0 auto' }}>
            <h2 style={{ fontSize: 52, fontWeight: 900, color: 'white', textAlign: 'center', marginBottom: 60 }}>متصل بـ <span style={{ color: siteConfig.primaryColor }}>الأنظمة الحكومية</span></h2>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 24 }}>
              {[
                { icon: '🏛️', name: 'نظام نور', desc: 'وزارة التعليم' },
                { icon: '🆔', name: 'أبشر', desc: 'وزارة الداخلية' },
                { icon: '💼', name: 'قوى', desc: 'الموارد البشرية' },
                { icon: '🌍', name: 'مقيم', desc: 'الجوازات' },
                { icon: '🎖️', name: 'فارس', desc: 'الخدمة المدنية' },
                { icon: '🔐', name: 'النفاذ الوطني', desc: 'الهوية الرقمية' }
              ].map((g, i) => (
                <div key={i} style={{ background: 'rgba(255, 255, 255, 0.03)', border: '1px solid rgba(255, 255, 255, 0.08)', borderRadius: 20, padding: 32, textAlign: 'center' }}>
                  <div style={{ fontSize: 56, marginBottom: 12 }}>{g.icon}</div>
                  <div style={{ fontSize: 18, fontWeight: 700, color: 'white', marginBottom: 4 }}>{g.name}</div>
                  <div style={{ fontSize: 13, color: 'rgba(255, 255, 255, 0.5)' }}>{g.desc}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ===== STORE PREVIEW ===== */}
        <section style={{ padding: '100px 24px', background: 'rgba(201, 162, 39, 0.03)' }}>
          <div style={{ maxWidth: 1400, margin: '0 auto' }}>
            <h2 style={{ fontSize: 52, fontWeight: 900, color: 'white', textAlign: 'center', marginBottom: 60 }}>متجر <span style={{ color: siteConfig.primaryColor }}>متين</span></h2>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: 28 }}>
              {[
                { icon: '🎒', name: 'حقائب مدرسية', price: '149 ر.س' },
                { icon: '📓', name: 'دفاتر وكراسات', price: '29 ر.س' },
                { icon: '✏️', name: 'أدوات مكتبية', price: '59 ر.س' },
                { icon: '🖥️', name: 'أجهزة تعليمية', price: '899 ر.س' }
              ].map((p, i) => (
                <div key={i} style={{ background: 'rgba(255, 255, 255, 0.03)', border: '1px solid rgba(255, 255, 255, 0.08)', borderRadius: 24, padding: 40, textAlign: 'center' }}>
                  <div style={{ fontSize: 80, marginBottom: 20 }}>{p.icon}</div>
                  <h3 style={{ fontSize: 20, fontWeight: 700, color: 'white', marginBottom: 12 }}>{p.name}</h3>
                  <div style={{ fontSize: 28, fontWeight: 900, color: siteConfig.primaryColor }}>{p.price}</div>
                </div>
              ))}
            </div>
            <div style={{ textAlign: 'center', marginTop: 48 }}>
              <Link href="/store" style={{ padding: '18px 40px', background: 'transparent', border: `3px solid ${siteConfig.primaryColor}`, borderRadius: 14, color: siteConfig.primaryColor, textDecoration: 'none', fontSize: 18, fontWeight: 700 }}>🛒 تصفح المتجر الكامل</Link>
            </div>
          </div>
        </section>

        {/* ===== COMPARISON ===== */}
        <section style={{ padding: '100px 24px' }}>
          <div style={{ maxWidth: 1000, margin: '0 auto' }}>
            <h2 style={{ fontSize: 52, fontWeight: 900, color: 'white', textAlign: 'center', marginBottom: 60 }}>متين vs <span style={{ color: siteConfig.primaryColor }}>المنافسين</span></h2>
            <div style={{ background: 'rgba(255, 255, 255, 0.03)', borderRadius: 28, overflow: 'hidden', border: '1px solid rgba(255, 255, 255, 0.08)' }}>
              <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr', background: 'rgba(201, 162, 39, 0.1)', padding: 20 }}>
                <div style={{ color: 'white', fontWeight: 700, fontSize: 18 }}>الميزة</div>
                <div style={{ color: siteConfig.primaryColor, fontWeight: 800, textAlign: 'center', fontSize: 18 }}>متين ⭐</div>
                <div style={{ color: 'rgba(255,255,255,0.5)', textAlign: 'center', fontSize: 18 }}>المنافسون</div>
              </div>
              {[
                { f: 'نظام متكامل (الكل في واحد)', m: '✅', o: '❌' },
                { f: 'تكامل حكومي كامل', m: '✅', o: '❌' },
                { f: 'مصمم للسعودية 100%', m: '✅', o: '❌' },
                { f: 'ذكاء اصطناعي متقدم', m: '✅', o: '⚠️' },
                { f: 'دعم فني 24/7 بالعربي', m: '✅', o: '❌' },
                { f: 'تجربة مجانية 14 يوم', m: '✅', o: '❌' }
              ].map((r, i) => (
                <div key={i} style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr', padding: 20, borderTop: '1px solid rgba(255,255,255,0.05)' }}>
                  <div style={{ color: 'rgba(255,255,255,0.8)', fontSize: 16 }}>{r.f}</div>
                  <div style={{ textAlign: 'center', fontSize: 24 }}>{r.m}</div>
                  <div style={{ textAlign: 'center', fontSize: 24 }}>{r.o}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ===== TESTIMONIALS ===== */}
        <section style={{ padding: '100px 24px', background: 'rgba(201, 162, 39, 0.03)' }}>
          <div style={{ maxWidth: 1400, margin: '0 auto' }}>
            <h2 style={{ fontSize: 52, fontWeight: 900, color: 'white', textAlign: 'center', marginBottom: 60 }}>ماذا يقول <span style={{ color: siteConfig.primaryColor }}>عملاؤنا</span></h2>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(350px, 1fr))', gap: 28 }}>
              {[
                { name: 'د. محمد العتيبي', role: 'مدير مدارس أهلية', text: 'متين غيّر طريقة إدارتنا للمدرسة بالكامل. وفرنا أكثر من 60% من الوقت والجهد!' },
                { name: 'أ. فاطمة الشهري', role: 'مديرة معهد تعليمي', text: 'أفضل نظام جربناه على الإطلاق! سهل الاستخدام والدعم الفني ممتاز ومتجاوب.' },
                { name: 'أحمد السالم', role: 'ولي أمر', text: 'متابعة أبنائي أصبحت أسهل بكثير. أشكر فريق متين على هذا الإنجاز الرائع!' }
              ].map((t, i) => (
                <div key={i} style={{ background: 'rgba(255, 255, 255, 0.03)', border: '1px solid rgba(255, 255, 255, 0.08)', borderRadius: 24, padding: 40 }}>
                  <div style={{ color: siteConfig.primaryColor, fontSize: 24, marginBottom: 20 }}>★★★★★</div>
                  <p style={{ fontSize: 18, color: 'rgba(255, 255, 255, 0.8)', marginBottom: 28, lineHeight: 1.8 }}>"{t.text}"</p>
                  <div style={{ fontSize: 18, fontWeight: 700, color: 'white' }}>{t.name}</div>
                  <div style={{ fontSize: 14, color: 'rgba(255, 255, 255, 0.5)' }}>{t.role}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ===== PRICING ===== */}
        <section style={{ padding: '100px 24px' }}>
          <div style={{ maxWidth: 1400, margin: '0 auto' }}>
            <h2 style={{ fontSize: 52, fontWeight: 900, color: 'white', textAlign: 'center', marginBottom: 60 }}>اختر <span style={{ color: siteConfig.primaryColor }}>خطتك</span></h2>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: 28 }}>
              {[
                { name: 'أساسي', price: 'مجاني', period: 'للأبد', features: ['100 طالب', '5 معلمين', 'دعم بالإيميل', 'المميزات الأساسية'], popular: false },
                { name: 'متقدم', price: '299', period: 'ر.س/شهر', features: ['500 طالب', '20 معلم', 'دعم فوري 24/7', 'جميع المميزات', 'تقارير متقدمة', 'تكامل حكومي'], popular: true },
                { name: 'مؤسسي', price: '599', period: 'ر.س/شهر', features: ['غير محدود', 'دعم VIP', 'تخصيص كامل', 'مدير حساب مخصص', 'تدريب شامل'], popular: false }
              ].map((p, i) => (
                <div key={i} style={{ background: p.popular ? 'rgba(201, 162, 39, 0.1)' : 'rgba(255, 255, 255, 0.03)', border: p.popular ? `3px solid ${siteConfig.primaryColor}` : '1px solid rgba(255, 255, 255, 0.08)', borderRadius: 28, padding: 40, position: 'relative', transform: p.popular ? 'scale(1.02)' : 'none' }}>
                  {p.popular && <div style={{ position: 'absolute', top: -16, left: '50%', transform: 'translateX(-50%)', background: siteConfig.primaryColor, color: siteConfig.darkColor, padding: '8px 24px', borderRadius: 30, fontSize: 14, fontWeight: 800 }}>⭐ الأكثر شعبية</div>}
                  <h3 style={{ fontSize: 28, fontWeight: 800, color: 'white', marginBottom: 12 }}>{p.name}</h3>
                  <div style={{ marginBottom: 28 }}>
                    <span style={{ fontSize: 48, fontWeight: 900, color: siteConfig.primaryColor }}>{p.price}</span>
                    <span style={{ fontSize: 16, color: 'rgba(255, 255, 255, 0.5)', marginRight: 8 }}>{p.period}</span>
                  </div>
                  <ul style={{ listStyle: 'none', padding: 0, marginBottom: 32 }}>
                    {p.features.map((f, j) => (
                      <li key={j} style={{ fontSize: 16, color: 'rgba(255, 255, 255, 0.7)', marginBottom: 12, display: 'flex', alignItems: 'center', gap: 10 }}>
                        <span style={{ color: siteConfig.primaryColor }}>✓</span> {f}
                      </li>
                    ))}
                  </ul>
                  <Link href="/register" style={{ display: 'block', textAlign: 'center', padding: '16px 32px', background: p.popular ? siteConfig.primaryColor : 'transparent', border: p.popular ? 'none' : `2px solid ${siteConfig.primaryColor}`, borderRadius: 12, color: p.popular ? siteConfig.darkColor : siteConfig.primaryColor, textDecoration: 'none', fontSize: 18, fontWeight: 700 }}>ابدأ الآن</Link>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ===== FAQ ===== */}
        <section style={{ padding: '100px 24px', background: 'rgba(201, 162, 39, 0.03)' }}>
          <div style={{ maxWidth: 900, margin: '0 auto' }}>
            <h2 style={{ fontSize: 52, fontWeight: 900, color: 'white', textAlign: 'center', marginBottom: 60 }}>أسئلة <span style={{ color: siteConfig.primaryColor }}>شائعة</span></h2>
            {[
              { q: 'هل يمكنني تجربة النظام مجاناً؟', a: 'نعم! نوفر تجربة مجانية كاملة لمدة 14 يوم بدون الحاجة لبطاقة ائتمانية.' },
              { q: 'هل متين متوافق مع نظام نور؟', a: 'نعم، متين متكامل 100% مع نظام نور ويمكن مزامنة البيانات تلقائياً.' },
              { q: 'كيف يتم الدعم الفني؟', a: 'نوفر دعم فني على مدار الساعة 24/7 عبر الواتساب، الإيميل، والهاتف بفريق سعودي متخصص.' },
              { q: 'هل البيانات آمنة؟', a: 'نستخدم أحدث تقنيات التشفير SSL/TLS مع نسخ احتياطي يومي لضمان أمان بياناتك.' }
            ].map((faq, i) => (
              <div key={i} style={{ background: 'rgba(255, 255, 255, 0.03)', border: '1px solid rgba(255, 255, 255, 0.08)', borderRadius: 20, padding: 32, marginBottom: 20 }}>
                <h3 style={{ fontSize: 20, fontWeight: 700, color: 'white', marginBottom: 12 }}>؟ {faq.q}</h3>
                <p style={{ fontSize: 16, color: 'rgba(255, 255, 255, 0.7)', lineHeight: 1.7 }}>{faq.a}</p>
              </div>
            ))}
          </div>
        </section>

        {/* ===== APP DOWNLOAD ===== */}
        <section style={{ padding: '100px 24px' }}>
          <div style={{ maxWidth: 900, margin: '0 auto', textAlign: 'center' }}>
            <div style={{ fontSize: 100, marginBottom: 28 }}>📱</div>
            <h2 style={{ fontSize: 48, fontWeight: 900, color: 'white', marginBottom: 20 }}>تطبيق <span style={{ color: siteConfig.primaryColor }}>متين</span> قريباً</h2>
            <p style={{ fontSize: 20, color: 'rgba(255, 255, 255, 0.7)', marginBottom: 40 }}>سيتوفر على iOS و Android</p>
            <div style={{ display: 'flex', gap: 20, justifyContent: 'center' }}>
              <div style={{ background: 'rgba(255, 255, 255, 0.1)', padding: '16px 32px', borderRadius: 14, opacity: 0.6, color: 'white', fontSize: 18 }}>🍎 App Store</div>
              <div style={{ background: 'rgba(255, 255, 255, 0.1)', padding: '16px 32px', borderRadius: 14, opacity: 0.6, color: 'white', fontSize: 18 }}>🤖 Google Play</div>
            </div>
          </div>
        </section>

        {/* ===== FINAL CTA ===== */}
        <section style={{ padding: '120px 24px', background: 'rgba(201, 162, 39, 0.05)' }}>
          <div style={{ maxWidth: 900, margin: '0 auto', textAlign: 'center' }}>
            <h2 style={{ fontSize: 56, fontWeight: 900, color: 'white', marginBottom: 28 }}>جاهز لتحويل <span style={{ color: siteConfig.primaryColor }}>مؤسستك؟</span></h2>
            <p style={{ fontSize: 22, color: 'rgba(255, 255, 255, 0.7)', marginBottom: 48 }}>انضم للمئات من المؤسسات التعليمية التي تثق بمتين</p>
            <div style={{ display: 'flex', gap: 20, justifyContent: 'center', flexWrap: 'wrap' }}>
              <Link href="/register" style={{ padding: '22px 56px', background: `linear-gradient(135deg, ${siteConfig.primaryColor} 0%, ${siteConfig.secondaryColor} 100%)`, borderRadius: 16, color: siteConfig.darkColor, textDecoration: 'none', fontSize: 22, fontWeight: 800, boxShadow: '0 8px 32px rgba(201, 162, 39, 0.4)' }}>🚀 ابدأ مجاناً الآن</Link>
              <Link href="/contact" style={{ padding: '22px 56px', background: 'transparent', border: '3px solid rgba(255, 255, 255, 0.3)', borderRadius: 16, color: 'white', textDecoration: 'none', fontSize: 22, fontWeight: 700 }}>📞 تحدث مع مستشار</Link>
            </div>
          </div>
        </section>

        {/* ===== PARTNERS - شركاؤنا (بدون أسماء - في الأسفل) ===== */}
        <section style={{ padding: '60px 24px', background: 'rgba(0, 0, 0, 0.2)' }}>
          <div style={{ maxWidth: 1200, margin: '0 auto' }}>
            <p style={{ textAlign: 'center', color: 'rgba(255, 255, 255, 0.5)', fontSize: 16, marginBottom: 32 }}>شركاؤنا</p>
            <div style={{ display: 'flex', gap: 24, justifyContent: 'center', alignItems: 'center', flexWrap: 'wrap' }}>
              {partners.map((partner) => (
                <div key={partner.id} style={{ 
                  width: 80,
                  height: 80,
                  background: 'rgba(255, 255, 255, 0.05)', 
                  border: '1px solid rgba(255, 255, 255, 0.1)', 
                  borderRadius: 16, 
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center'
                }}>
                  {partner.logo ? (
                    <img src={partner.logo} alt="شريك" style={{ maxHeight: 50, maxWidth: 50 }} />
                  ) : (
                    <div style={{ fontSize: 36, opacity: 0.5 }}>{partner.icon}</div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ===== CONTACT INFO ===== */}
        <section style={{ padding: '60px 24px', background: 'rgba(0, 0, 0, 0.3)' }}>
          <div style={{ maxWidth: 1200, margin: '0 auto', display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: 40, textAlign: 'center' }}>
            <div>
              <div style={{ fontSize: 40, marginBottom: 12 }}>📧</div>
              <div style={{ color: 'rgba(255,255,255,0.5)', fontSize: 14, marginBottom: 4 }}>البريد الإلكتروني</div>
              <div style={{ color: 'white', fontWeight: 700, fontSize: 18 }}>{siteConfig.email}</div>
            </div>
            <div>
              <div style={{ fontSize: 40, marginBottom: 12 }}>📱</div>
              <div style={{ color: 'rgba(255,255,255,0.5)', fontSize: 14, marginBottom: 4 }}>الجوال</div>
              <div style={{ color: 'white', fontWeight: 700, fontSize: 18 }}>{siteConfig.phone}</div>
            </div>
            <div>
              <div style={{ fontSize: 40, marginBottom: 12 }}>🌐</div>
              <div style={{ color: 'rgba(255,255,255,0.5)', fontSize: 14, marginBottom: 4 }}>الموقع</div>
              <div style={{ color: 'white', fontWeight: 700, fontSize: 18 }}>{siteConfig.website}</div>
            </div>
            <div>
              <div style={{ fontSize: 40, marginBottom: 12 }}>📍</div>
              <div style={{ color: 'rgba(255,255,255,0.5)', fontSize: 14, marginBottom: 4 }}>الموقع</div>
              <div style={{ color: 'white', fontWeight: 700, fontSize: 18 }}>{siteConfig.location}</div>
            </div>
          </div>
        </section>

        {/* ===== FOOTER ===== */}
        <footer style={{ padding: '50px 24px', borderTop: '1px solid rgba(201, 162, 39, 0.1)' }}>
          <div style={{ maxWidth: 1400, margin: '0 auto', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 24 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <div style={{ width: 40, height: 40, background: siteConfig.primaryColor, borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20, fontWeight: 800, color: siteConfig.darkColor }}>{siteConfig.logoIcon}</div>
              <span style={{ fontSize: 24, fontWeight: 900, color: siteConfig.primaryColor }}>{siteConfig.logoText}</span>
            </div>
            <div style={{ display: 'flex', gap: 32 }}>
              <Link href="/about" style={{ color: 'rgba(255, 255, 255, 0.5)', textDecoration: 'none', fontSize: 15 }}>عن متين</Link>
              <Link href="/pricing" style={{ color: 'rgba(255, 255, 255, 0.5)', textDecoration: 'none', fontSize: 15 }}>الأسعار</Link>
              <Link href="/contact" style={{ color: 'rgba(255, 255, 255, 0.5)', textDecoration: 'none', fontSize: 15 }}>تواصل معنا</Link>
              <Link href="/community" style={{ color: 'rgba(255, 255, 255, 0.5)', textDecoration: 'none', fontSize: 15 }}>التواصل الاجتماعي</Link>
              <Link href="/store" style={{ color: 'rgba(255, 255, 255, 0.5)', textDecoration: 'none', fontSize: 15 }}>المتجر</Link>
            </div>
            <p style={{ color: 'rgba(255, 255, 255, 0.4)', fontSize: 14 }}>© 2026 متين - صنع في المملكة العربية السعودية 🇸🇦</p>
          </div>
        </footer>

      </div>
    </>
  );
}
