import { NextResponse } from 'next/server';
import { pool, getUserFromRequest } from '@/lib/auth';

export async function GET(request: Request) {
  try {
    const user = await getUserFromRequest(request);
    if (!user) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });

    let query = '';
    let params: any[] = [];

    if (user.role === 'super_admin') {
      query = 'SELECT * FROM integrations ORDER BY name';
    } else {
      query = `
        SELECT i.*, 
          CASE WHEN si.school_id IS NOT NULL THEN true ELSE false END as is_connected,
          si.config as school_config,
          si.connected_at
        FROM integrations i
        LEFT JOIN school_integrations si ON si.integration_id = i.id AND si.school_id = $1
        WHERE i.is_active = true
        ORDER BY i.name
      `;
      params = [user.school_id];
    }

    const result = await pool.query(query, params);
    return NextResponse.json({ data: result.rows, total: result.rowCount });
  } catch (error: any) {
    console.error('Integrations GET error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const user = await getUserFromRequest(request);
    if (!user || user.role !== 'super_admin') return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });

    const body = await request.json();
    const { name, type, config, is_active } = body;
    const id = 'int_' + Date.now();

    const result = await pool.query(
      `INSERT INTO integrations (id, name, type, config, is_active, created_at, updated_at) 
       VALUES ($1, $2, $3, $4, $5, NOW(), NOW()) RETURNING *`,
      [id, name, type, JSON.stringify(config || {}), is_active !== false]
    );
    return NextResponse.json({ data: result.rows[0] });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function PUT(request: Request) {
  try {
    const user = await getUserFromRequest(request);
    if (!user || user.role !== 'super_admin') return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });

    const body = await request.json();
    const { id, name, type, config, is_active } = body;

    const result = await pool.query(
      `UPDATE integrations SET name=$1, type=$2, config=$3, is_active=$4, updated_at=NOW() WHERE id=$5 RETURNING *`,
      [name, type, JSON.stringify(config || {}), is_active !== false, id]
    );
    return NextResponse.json({ data: result.rows[0] });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const user = await getUserFromRequest(request);
    if (!user || user.role !== 'super_admin') return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });

    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    await pool.query('DELETE FROM integrations WHERE id = $1', [id]);
    return NextResponse.json({ success: true });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
