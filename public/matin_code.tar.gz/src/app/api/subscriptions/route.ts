import { NextResponse } from 'next/server';
import { pool, getUserFromRequest, getFilterSQL, getInsertIds } from '@/lib/auth';
import { getPaymentCredentials } from '@/lib/integrations';

export async function GET(request: Request) {
  try {
    const user = await getUserFromRequest(request);
    if (!user) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });
    const filter = getFilterSQL(user);
    const result = await pool.query(
      `SELECT * FROM subscriptions WHERE 1=1 ${filter.sql} ORDER BY created_at DESC LIMIT 200`,
      filter.params
    );
    return NextResponse.json(result.rows);
  } catch (error) { console.error('Error:', error); return NextResponse.json([]); }
}

export async function POST(request: Request) {
  try {
    const user = await getUserFromRequest(request);
    if (!user) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });
    const ids = getInsertIds(user);
    const body = await request.json();
    const { plan, amount, payment_method, school_id } = body;
    if (!plan || !amount) return NextResponse.json({ error: 'الخطة والمبلغ مطلوبان' }, { status: 400 });

    const owner_id = ids.owner_id;

    // جلب بوابة الدفع المفعلة
    let paymentProvider = null;
    let paymentCredentials = null;

    const moyasar = await getPaymentCredentials('moyasar', owner_id);
    const hyperpay = await getPaymentCredentials('hyperpay', owner_id);
    const tap = await getPaymentCredentials('tap', owner_id);

    if (moyasar) { paymentProvider = 'moyasar'; paymentCredentials = moyasar; }
    else if (hyperpay) { paymentProvider = 'hyperpay'; paymentCredentials = hyperpay; }
    else if (tap) { paymentProvider = 'tap'; paymentCredentials = tap; }

    // إنشاء الاشتراك
    const result = await pool.query(
      `INSERT INTO subscriptions (plan, amount, payment_method, payment_provider, status, school_id, owner_id, start_date, end_date, created_at)
       VALUES ($1,$2,$3,$4,'pending',$5,$6,NOW(), NOW() + INTERVAL '1 year', NOW()) RETURNING *`,
      [plan, amount, payment_method || 'online', paymentProvider || 'manual', school_id || ids.school_id, owner_id]
    );

    // لو أونلاين، أرجع بيانات الدفع
    if (payment_method === 'online' && paymentProvider && paymentCredentials) {
      return NextResponse.json({
        ...result.rows[0],
        payment: {
          provider: paymentProvider,
          publishable_key: paymentCredentials.api_key,
          amount,
          currency: 'SAR'
        }
      }, { status: 201 });
    }

    return NextResponse.json(result.rows[0], { status: 201 });
  } catch (error) { console.error('Error:', error); return NextResponse.json({ error: 'فشل' }, { status: 500 }); }
}

export async function PUT(request: Request) {
  try {
    const user = await getUserFromRequest(request);
    if (!user) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });
    const body = await request.json();
    const { id, status, plan, amount } = body;
    if (!id) return NextResponse.json({ error: 'المعرف مطلوب' }, { status: 400 });
    const result = await pool.query(
      'UPDATE subscriptions SET status=$1, plan=$2, amount=$3 WHERE id=$4 RETURNING *',
      [status, plan, amount, id]
    );
    return NextResponse.json(result.rows[0]);
  } catch (error) { console.error('Error:', error); return NextResponse.json({ error: 'فشل' }, { status: 500 }); }
}

export async function DELETE(request: Request) {
  try {
    const user = await getUserFromRequest(request);
    if (!user) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    if (!id) return NextResponse.json({ error: 'المعرف مطلوب' }, { status: 400 });
    await pool.query('DELETE FROM subscriptions WHERE id = $1', [id]);
    return NextResponse.json({ success: true });
  } catch (error) { console.error('Error:', error); return NextResponse.json({ error: 'فشل' }, { status: 500 }); }
}
