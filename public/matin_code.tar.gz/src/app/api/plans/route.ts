import { NextRequest, NextResponse } from 'next/server';
import { pool, getUserFromRequest } from '@/lib/auth';
export async function GET(req: NextRequest) {
  try {
    const user = await getUserFromRequest(req);
    if (!user) return NextResponse.json({ error: 'غير مصرح' }, { status: 401 });
    const result = await pool.query('SELECT * FROM plans ORDER BY price_monthly ASC');
    return NextResponse.json({ data: result.rows, total: result.rowCount });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
export async function POST(req: NextRequest) {
  try {
    const user = await getUserFromRequest(req);
    if (!user || user.role !== 'super_admin') return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });
    const body = await req.json();
    const { name, name_ar, price_monthly, price_yearly, max_students, max_teachers, features } = body;
    const result = await pool.query(
      `INSERT INTO plans (name, name_ar, price_monthly, price_yearly, max_students, max_teachers, features, created_at) 
       VALUES ($1, $2, $3, $4, $5, $6, $7, NOW()) RETURNING *`,
      [name, name_ar, price_monthly || 0, price_yearly || 0, max_students || 100, max_teachers || 10, JSON.stringify(features || [])]
    );
    return NextResponse.json({ data: result.rows[0] });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
export async function PUT(req: NextRequest) {
  try {
    const user = await getUserFromRequest(req);
    if (!user || user.role !== 'super_admin') return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });
    const body = await req.json();
    const { id, name, name_ar, price_monthly, price_yearly, max_students, max_teachers, features, is_active } = body;
    const result = await pool.query(
      `UPDATE plans SET name=$1, name_ar=$2, price_monthly=$3, price_yearly=$4, max_students=$5, max_teachers=$6, features=$7, is_active=$8 WHERE id=$9 RETURNING *`,
      [name, name_ar, price_monthly, price_yearly, max_students, max_teachers, JSON.stringify(features || []), is_active !== false, id]
    );
    return NextResponse.json({ data: result.rows[0] });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
export async function DELETE(req: NextRequest) {
  try {
    const user = await getUserFromRequest(req);
    if (!user || user.role !== 'super_admin') return NextResponse.json({ error: 'غير مصرح' }, { status: 403 });
    const { searchParams } = new URL(req.url);
    const id = searchParams.get('id');
    await pool.query('DELETE FROM plans WHERE id = $1', [id]);
    return NextResponse.json({ success: true });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
