'use client';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Sidebar from '@/components/Sidebar';
import DashboardHeader from '@/components/DashboardHeader';
import SessionTimeout from '@/components/SessionTimeout';

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [screenSize, setScreenSize] = useState<'mobile' | 'tablet' | 'desktop'>('desktop');
  const [userRole, setUserRole] = useState('');
  const router = useRouter();

  useEffect(() => {
    const verifyUser = async () => {
      try {
        const token = localStorage.getItem('matin_token');
        if (!token) {
          router.push('/login');
          return;
        }

        // ✅ الخطوة الحاسمة: اجلب بيانات المستخدم من السيرفر دائماً
        const res = await fetch('/api/auth/me', {
          headers: { 'Authorization': 'Bearer ' + token }
        });

        if (!res.ok) {
          localStorage.removeItem('matin_user');
          localStorage.removeItem('matin_token');
          router.push('/login');
          return;
        }

        const data = await res.json();
        const user = data.user || data;

        if (!user || !user.id) {
          router.push('/login');
          return;
        }

        // ✅ حدّث localStorage بالبيانات الصحيحة من السيرفر
        localStorage.setItem('matin_user', JSON.stringify(user));
        setUserRole(user.role || '');
        setLoading(false);

      } catch {
        // في حالة فشل الاتصال، استخدم localStorage كـ fallback
        const stored = localStorage.getItem('matin_user');
        if (!stored) {
          router.push('/login');
          return;
        }
        try {
          const u = JSON.parse(stored);
          setUserRole(u.role || '');
          setLoading(false);
        } catch {
          router.push('/login');
        }
      }
    };

    verifyUser();
  }, [router]);

  useEffect(() => {
    const checkScreen = () => {
      const w = window.innerWidth;
      if (w < 768) { setScreenSize('mobile'); setSidebarOpen(false); }
      else if (w < 1024) { setScreenSize('tablet'); setSidebarOpen(false); }
      else { setScreenSize('desktop'); setSidebarOpen(true); }
    };
    checkScreen();
    window.addEventListener('resize', checkScreen);
    return () => window.removeEventListener('resize', checkScreen);
  }, []);

  if (loading) {
    return (
      <div style={{ minHeight: '100vh', background: 'linear-gradient(135deg, #0D1B2A 0%, #1B263B 100%)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <style>{`@keyframes pulse { 0%, 100% { transform: scale(1); opacity: 1; } 50% { transform: scale(1.08); opacity: 0.8; } }`}</style>
        <div style={{ textAlign: 'center' }}>
          <div style={{ width: 80, height: 80, background: 'linear-gradient(135deg, #C9A227 0%, #D4B03D 100%)', borderRadius: 20, margin: '0 auto 24px', animation: 'pulse 2s infinite' }} />
          <p style={{ color: '#C9A227', fontSize: 20, fontWeight: 600 }}>جاري تحميل لوحة التحكم...</p>
          <p style={{ color: 'rgba(255,255,255,0.5)', fontSize: 14, marginTop: 8 }}>متين - نظام إدارة التعليم المتكامل</p>
        </div>
      </div>
    );
  }

  const isDesktop = screenSize === 'desktop';
  const mainPadding = screenSize === 'mobile' ? 10 : screenSize === 'tablet' ? 16 : 24;

  return (
    <div style={{ 
      minHeight: '100vh', 
      background: 'linear-gradient(135deg, #0D1B2A 0%, #1B263B 50%, #0D1B2A 100%)', 
      direction: 'rtl', 
      fontFamily: 'IBM Plex Sans Arabic, sans-serif',
      display: 'flex',
      flexDirection: 'row',
    }}>
      <link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
      <style>{`@keyframes pulse { 0%, 100% { transform: scale(1); opacity: 1; } 50% { transform: scale(1.08); opacity: 0.8; } }`}</style>
      <SessionTimeout />
      
      {/* ✅ نمرر userRole للـ Sidebar مباشرة من السيرفر */}
      <Sidebar 
        isOpen={isDesktop ? true : sidebarOpen} 
        onClose={() => setSidebarOpen(false)} 
        screenSize={screenSize}
        userRole={userRole}
      />
      
      <div style={{ 
        flex: 1, 
        minWidth: 0,
        display: 'flex',
        flexDirection: 'column',
        minHeight: '100vh',
        overflow: 'hidden',
      }}>
        <DashboardHeader 
          onMenuClick={() => setSidebarOpen(!sidebarOpen)} 
          showMenuButton={!isDesktop} 
        />
        <main style={{ 
          flex: 1,
          padding: mainPadding, 
          overflowY: 'auto',
          overflowX: 'hidden',
        }}>
          {children}
        </main>
        <footer style={{ 
          padding: screenSize === 'mobile' ? '12px 10px' : '16px 24px', 
          borderTop: '1px solid rgba(255,255,255,0.06)', 
          display: 'flex', 
          justifyContent: 'space-between', 
          alignItems: 'center', 
          flexWrap: 'wrap', 
          gap: 8,
          flexShrink: 0,
        }}>
          <p style={{ color: 'rgba(255,255,255,0.4)', fontSize: screenSize === 'mobile' ? 10 : 12, margin: 0 }}>© 2026 متين - جميع الحقوق محفوظة</p>
          <p style={{ color: 'rgba(255,255,255,0.4)', fontSize: screenSize === 'mobile' ? 10 : 12, margin: 0 }}>صنع بـ ❤️ في المملكة العربية السعودية</p>
        </footer>
      </div>
    </div>
  );
}
