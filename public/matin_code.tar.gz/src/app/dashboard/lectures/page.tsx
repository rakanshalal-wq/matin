'use client';
import { useState, useEffect } from 'react';

const getHeaders = (): Record<string, string> => { try { const token = localStorage.getItem('matin_token'); if (token) return { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token }; const u = JSON.parse(localStorage.getItem('matin_user') || '{}'); return { 'Content-Type': 'application/json', 'x-user-id': String(u.id || '') }; } catch { return { 'Content-Type': 'application/json' }; } };

const typeConfig: any = {
  in_person: { label: 'حضوري', color: '#10B981', bg: 'rgba(16,185,129,0.12)', icon: '🏫' },
  online: { label: 'أونلاين', color: '#3B82F6', bg: 'rgba(59,130,246,0.12)', icon: '💻' },
  recorded: { label: 'مسجلة', color: '#8B5CF6', bg: 'rgba(139,92,246,0.12)', icon: '🎥' },
};
const confirmConfig: any = {
  pending: { label: 'بانتظار التأكيد', color: '#F59E0B', bg: 'rgba(245,158,11,0.12)', icon: '⏳' },
  confirmed: { label: 'مؤكدة', color: '#10B981', bg: 'rgba(16,185,129,0.12)', icon: '✓' },
  auto_online: { label: 'تحولت أونلاين تلقائياً', color: '#3B82F6', bg: 'rgba(59,130,246,0.12)', icon: '🔄' },
  auto_recorded: { label: 'تحولت تسجيل تلقائياً', color: '#8B5CF6', bg: 'rgba(139,92,246,0.12)', icon: '🔄' },
};
const statusConfig: any = {
  scheduled: { label: 'مجدولة', color: '#F59E0B' },
  live: { label: 'جارية الآن', color: '#EF4444' },
  completed: { label: 'مكتملة', color: '#10B981' },
  recorded: { label: 'مسجلة', color: '#8B5CF6' },
  missed: { label: 'فائتة', color: '#6B7280' },
};

export default function LecturesPage() {
  const [lectures, setLectures] = useState<any[]>([]);
  const [classes, setClasses] = useState<any[]>([]);
  const [teachers, setTeachers] = useState<any[]>([]);
  const [subjects, setSubjects] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [user, setUser] = useState<any>(null);
  const [form, setForm] = useState({ title: '', date: '', type: 'in_person', class_id: '', teacher_id: '', subject_id: '', duration_minutes: '45', room: '', description: '' });
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState('');

  useEffect(() => {
    const u = JSON.parse(localStorage.getItem('matin_user') || '{}');
    setUser(u);
    fetchAll();
  }, []);

  const fetchAll = async () => {
    try {
      const [lRes, cRes, tRes, sRes] = await Promise.all([
        fetch('/api/lectures', { headers: getHeaders() }),
        fetch('/api/classes', { headers: getHeaders() }),
        fetch('/api/teachers', { headers: getHeaders() }),
        fetch('/api/subjects', { headers: getHeaders() }),
      ]);
      const [lData, cData, tData, sData] = await Promise.all([lRes.json(), cRes.json(), tRes.json(), sRes.json()]);
      setLectures(Array.isArray(lData) ? lData : []);
      setClasses(Array.isArray(cData) ? cData : []);
      setTeachers(Array.isArray(tData) ? tData : []);
      setSubjects(Array.isArray(sData) ? sData : []);
    } catch {} finally { setLoading(false); }
  };

  const handleAdd = async () => {
    if (!form.title) { setMsg('عنوان المحاضرة مطلوب'); return; }
    if (!form.date) { setMsg('التاريخ والوقت مطلوب'); return; }
    setSaving(true); setMsg('');
    try {
      const res = await fetch('/api/lectures', { method: 'POST', headers: getHeaders(), body: JSON.stringify({...form, duration_minutes: parseInt(form.duration_minutes)}) });
      const data = await res.json();
      if (!res.ok) { setMsg(data.error || 'فشل'); setSaving(false); return; }
      fetchAll();
      setForm({ title: '', date: '', type: 'in_person', class_id: '', teacher_id: '', subject_id: '', duration_minutes: '45', room: '', description: '' });
      setShowAdd(false);
    } catch { setMsg('خطأ'); } finally { setSaving(false); }
  };

  const handleAction = async (id: number, action: string) => {
    const labels: any = { confirm: 'تأكيد', convert_online: 'تحويل أونلاين', convert_recorded: 'تحويل تسجيل', complete: 'إنهاء' };
    if (!confirm(`${labels[action]} هذه المحاضرة؟`)) return;
    try {
      const res = await fetch('/api/lectures', { method: 'PUT', headers: getHeaders(), body: JSON.stringify({ id, action }) });
      if (res.ok) fetchAll();
    } catch {}
  };

  const handleDelete = async (id: number) => {
    if (!confirm('حذف هذه المحاضرة؟')) return;
    await fetch(`/api/lectures?id=${id}`, { method: 'DELETE', headers: getHeaders() });
    setLectures(lectures.filter(l => l.id !== id));
  };

  const canAdd = ['super_admin', 'owner', 'admin', 'teacher'].includes(user?.role);
  const inputStyle = { width: '100%', padding: '12px 16px', background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 10, color: '#fff', fontSize: 14, fontFamily: 'IBM Plex Sans Arabic, sans-serif', outline: 'none', direction: 'rtl' as const };

  if (loading) return <div style={{ padding: 40, textAlign: 'center', color: '#C9A227' }}>جاري التحميل...</div>;

  return (
    <div style={{ padding: '24px', direction: 'rtl', fontFamily: 'IBM Plex Sans Arabic, sans-serif' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <div>
          <h1 style={{ fontSize: 24, fontWeight: 700, color: '#C9A227', margin: 0 }}>🎓 المحاضرات الذكية</h1>
          <p style={{ color: '#9CA3AF', fontSize: 14, margin: '4px 0 0' }}>{lectures.length} محاضرة</p>
        </div>
        {canAdd && (
          <button onClick={() => setShowAdd(!showAdd)} style={{ padding: '10px 24px', background: showAdd ? '#374151' : 'linear-gradient(135deg, #C9A227, #E8C547)', color: showAdd ? '#fff' : '#000', border: 'none', borderRadius: 10, fontSize: 14, fontWeight: 700, cursor: 'pointer', fontFamily: 'IBM Plex Sans Arabic, sans-serif' }}>
            {showAdd ? '✕ إلغاء' : '+ إضافة محاضرة'}
          </button>
        )}
      </div>

      {/* شرح النظام */}
      <div style={{ padding: 14, background: 'rgba(201,162,39,0.08)', border: '1px solid rgba(201,162,39,0.2)', borderRadius: 12, marginBottom: 20, fontSize: 13, color: '#C9A227', lineHeight: 1.8 }}>
        ⚡ <strong>نظام التأكيد التلقائي:</strong> ساعتين قبل → إشعار للدكتور → لو ما أكد = أونلاين → ساعة قبل → لو ما أكد = تسجيل
      </div>

      {msg && <div style={{ padding: 12, background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.3)', borderRadius: 10, color: '#EF4444', marginBottom: 16, fontSize: 14 }}>{msg}</div>}

      {showAdd && (
        <div style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(201,162,39,0.2)', borderRadius: 16, padding: 24, marginBottom: 24 }}>
          <h3 style={{ color: '#C9A227', fontSize: 18, margin: '0 0 20px', fontWeight: 700 }}>إضافة محاضرة جديدة</h3>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 16 }}>
            <div style={{ gridColumn: '1 / -1' }}>
              <label style={{ color: '#9CA3AF', fontSize: 13, marginBottom: 6, display: 'block' }}>عنوان المحاضرة *</label>
              <input style={inputStyle} placeholder="مثال: محاضرة الرياضيات - الفصل الثالث" value={form.title} onChange={e => setForm({...form, title: e.target.value})} />
            </div>
            <div>
              <label style={{ color: '#9CA3AF', fontSize: 13, marginBottom: 6, display: 'block' }}>التاريخ والوقت *</label>
              <input type="datetime-local" style={inputStyle} value={form.date} onChange={e => setForm({...form, date: e.target.value})} />
            </div>
            <div>
              <label style={{ color: '#9CA3AF', fontSize: 13, marginBottom: 6, display: 'block' }}>النوع</label>
              <select style={{...inputStyle, cursor: 'pointer'}} value={form.type} onChange={e => setForm({...form, type: e.target.value})}>
                <option value="in_person">🏫 حضوري</option>
                <option value="online">💻 أونلاين</option>
                <option value="recorded">🎥 مسجلة</option>
              </select>
            </div>
            <div>
              <label style={{ color: '#9CA3AF', fontSize: 13, marginBottom: 6, display: 'block' }}>المدة (دقائق)</label>
              <input type="number" style={inputStyle} value={form.duration_minutes} onChange={e => setForm({...form, duration_minutes: e.target.value})} />
            </div>
            <div>
              <label style={{ color: '#9CA3AF', fontSize: 13, marginBottom: 6, display: 'block' }}>الفصل</label>
              <select style={{...inputStyle, cursor: 'pointer'}} value={form.class_id} onChange={e => setForm({...form, class_id: e.target.value})}>
                <option value="">اختر الفصل</option>
                {classes.map(c => <option key={c.id} value={c.id}>{c.name_ar || c.name}</option>)}
              </select>
            </div>
            <div>
              <label style={{ color: '#9CA3AF', fontSize: 13, marginBottom: 6, display: 'block' }}>المعلم</label>
              <select style={{...inputStyle, cursor: 'pointer'}} value={form.teacher_id} onChange={e => setForm({...form, teacher_id: e.target.value})}>
                <option value="">اختر المعلم</option>
                {teachers.map(t => <option key={t.id} value={t.id}>{t.name || t.employee_id}</option>)}
              </select>
            </div>
            <div>
              <label style={{ color: '#9CA3AF', fontSize: 13, marginBottom: 6, display: 'block' }}>المادة</label>
              <select style={{...inputStyle, cursor: 'pointer'}} value={form.subject_id} onChange={e => setForm({...form, subject_id: e.target.value})}>
                <option value="">اختر المادة</option>
                {subjects.map(s => <option key={s.id} value={s.id}>{s.name_ar || s.name}</option>)}
              </select>
            </div>
            <div>
              <label style={{ color: '#9CA3AF', fontSize: 13, marginBottom: 6, display: 'block' }}>القاعة</label>
              <input style={inputStyle} placeholder="مثال: قاعة 101" value={form.room} onChange={e => setForm({...form, room: e.target.value})} />
            </div>
            <div>
              <label style={{ color: '#9CA3AF', fontSize: 13, marginBottom: 6, display: 'block' }}>الوصف</label>
              <input style={inputStyle} placeholder="وصف مختصر" value={form.description} onChange={e => setForm({...form, description: e.target.value})} />
            </div>
          </div>
          <button onClick={handleAdd} disabled={saving} style={{ marginTop: 20, padding: '12px 32px', background: 'linear-gradient(135deg, #C9A227, #E8C547)', color: '#000', border: 'none', borderRadius: 10, fontSize: 15, fontWeight: 700, cursor: 'pointer', fontFamily: 'IBM Plex Sans Arabic, sans-serif', opacity: saving ? 0.5 : 1 }}>
            {saving ? 'جاري الحفظ...' : '✓ إضافة المحاضرة'}
          </button>
        </div>
      )}

      {/* قائمة المحاضرات */}
      {lectures.length === 0 ? (
        <div style={{ textAlign: 'center', padding: 60, background: 'rgba(255,255,255,0.02)', borderRadius: 16, border: '1px solid rgba(255,255,255,0.05)' }}>
          <div style={{ fontSize: 48, marginBottom: 16 }}>🎓</div>
          <h3 style={{ color: '#fff', fontSize: 18, margin: '0 0 8px' }}>لا توجد محاضرات بعد</h3>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {lectures.map((l: any) => {
            const tp = typeConfig[l.type] || typeConfig.in_person;
            const cs = confirmConfig[l.confirmation_status] || confirmConfig.pending;
            const st = statusConfig[l.status] || statusConfig.scheduled;
            const lectureDate = l.date ? new Date(l.date) : null;
            const isUpcoming = lectureDate && lectureDate > new Date();

            return (
              <div key={l.id} style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 14, padding: 20 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8, flexWrap: 'wrap' }}>
                      <h3 style={{ color: '#fff', fontSize: 16, fontWeight: 700, margin: 0 }}>{l.title}</h3>
                      <span style={{ padding: '3px 10px', borderRadius: 20, fontSize: 11, background: tp.bg, color: tp.color }}>{tp.icon} {tp.label}</span>
                      <span style={{ padding: '3px 10px', borderRadius: 20, fontSize: 11, background: cs.bg, color: cs.color }}>{cs.icon} {cs.label}</span>
                      <span style={{ fontSize: 11, color: st.color }}>● {st.label}</span>
                    </div>
                    <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap', marginBottom: 8 }}>
                      {lectureDate && <span style={{ color: '#9CA3AF', fontSize: 13 }}>📅 {lectureDate.toLocaleDateString('ar-SA')} — {lectureDate.toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' })}</span>}
                      <span style={{ color: '#9CA3AF', fontSize: 13 }}>⏱️ {l.duration_minutes || 45} دقيقة</span>
                      {l.teacher_display_name && <span style={{ color: '#9CA3AF', fontSize: 13 }}>👨‍🏫 {l.teacher_display_name}</span>}
                      {l.class_name && <span style={{ color: '#9CA3AF', fontSize: 13 }}>🏛️ {l.class_name}</span>}
                      {l.subject_name_ar && <span style={{ color: '#9CA3AF', fontSize: 13 }}>📚 {l.subject_name_ar}</span>}
                      {l.room && <span style={{ color: '#9CA3AF', fontSize: 13 }}>📍 {l.room}</span>}
                    </div>
                    {l.auto_converted && <div style={{ padding: '6px 12px', background: 'rgba(245,158,11,0.08)', borderRadius: 8, fontSize: 12, color: '#F59E0B', marginBottom: 8 }}>🔄 {l.conversion_reason}</div>}
                  </div>

                  {canAdd && (
                    <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginRight: 12 }}>
                      {l.confirmation_status === 'pending' && isUpcoming && (
                        <button onClick={() => handleAction(l.id, 'confirm')} style={{ padding: '5px 14px', background: 'rgba(16,185,129,0.1)', color: '#10B981', border: '1px solid rgba(16,185,129,0.2)', borderRadius: 8, fontSize: 12, cursor: 'pointer', fontFamily: 'IBM Plex Sans Arabic, sans-serif' }}>✓ تأكيد</button>
                      )}
                      {l.confirmation_status === 'pending' && (
                        <button onClick={() => handleAction(l.id, 'convert_online')} style={{ padding: '5px 14px', background: 'rgba(59,130,246,0.1)', color: '#3B82F6', border: '1px solid rgba(59,130,246,0.2)', borderRadius: 8, fontSize: 12, cursor: 'pointer', fontFamily: 'IBM Plex Sans Arabic, sans-serif' }}>💻 أونلاين</button>
                      )}
                      {l.confirmation_status === 'auto_online' && (
                        <button onClick={() => handleAction(l.id, 'convert_recorded')} style={{ padding: '5px 14px', background: 'rgba(139,92,246,0.1)', color: '#8B5CF6', border: '1px solid rgba(139,92,246,0.2)', borderRadius: 8, fontSize: 12, cursor: 'pointer', fontFamily: 'IBM Plex Sans Arabic, sans-serif' }}>🎥 تسجيل</button>
                      )}
                      {(l.status === 'scheduled' || l.status === 'live') && (
                        <button onClick={() => handleAction(l.id, 'complete')} style={{ padding: '5px 14px', background: 'rgba(107,114,128,0.1)', color: '#6B7280', border: '1px solid rgba(107,114,128,0.2)', borderRadius: 8, fontSize: 12, cursor: 'pointer', fontFamily: 'IBM Plex Sans Arabic, sans-serif' }}>✓ إنهاء</button>
                      )}
                      <button onClick={() => handleDelete(l.id)} style={{ padding: '5px 14px', background: 'rgba(239,68,68,0.1)', color: '#EF4444', border: '1px solid rgba(239,68,68,0.2)', borderRadius: 8, fontSize: 12, cursor: 'pointer', fontFamily: 'IBM Plex Sans Arabic, sans-serif' }}>🗑️</button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
