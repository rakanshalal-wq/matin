'use client';
import { useState, useEffect } from 'react';
const getHeaders = (): Record<string, string> => { try { const token = localStorage.getItem('matin_token'); if (token) return { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token }; const u = JSON.parse(localStorage.getItem('matin_user') || '{}'); return { 'Content-Type': 'application/json', 'x-user-id': String(u.id || '') }; } catch { return { 'Content-Type': 'application/json' }; } };

export default function SchoolInvoicesPage() {
  const [invoices, setInvoices] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterStatus, setFilterStatus] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    const u = JSON.parse(localStorage.getItem('matin_user') || '{}');
    setUser(u);
    fetchInvoices();
  }, []);

  const fetchInvoices = async () => {
    try {
      const res = await fetch('/api/finance?type=all_payments', { headers: getHeaders() });
      if (res.ok) {
        const data = await res.json();
        setInvoices(Array.isArray(data) ? data : []);
      } else {
        // fallback: جلب من payments عبر dashboard
        const res2 = await fetch('/api/finance?type=dashboard', { headers: getHeaders() });
        const data2 = await res2.json();
        setInvoices(Array.isArray(data2?.recent_payments) ? data2.recent_payments : []);
      }
    } catch (e) { console.error(e); } finally { setLoading(false); }
  };

  const stats = {
    total: invoices.reduce((s, i) => s + parseFloat(i.amount || 0), 0),
    paid: invoices.filter(i => i.status === 'paid').reduce((s, i) => s + parseFloat(i.amount || 0), 0),
    pending: invoices.filter(i => i.status === 'pending' || i.status === 'initiated').reduce((s, i) => s + parseFloat(i.amount || 0), 0),
    failed: invoices.filter(i => i.status === 'failed').reduce((s, i) => s + parseFloat(i.amount || 0), 0),
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'paid': return { text: '✅ مدفوعة', color: '#10B981', bg: 'rgba(16,185,129,0.1)' };
      case 'pending': case 'initiated': return { text: '⏳ بانتظار الدفع', color: '#F59E0B', bg: 'rgba(245,158,11,0.1)' };
      case 'failed': return { text: '❌ فشلت', color: '#EF4444', bg: 'rgba(239,68,68,0.1)' };
      default: return { text: status, color: '#6B7280', bg: 'rgba(107,114,128,0.1)' };
    }
  };

  const filtered = invoices.filter(inv => {
    const matchSearch = (inv.user_name || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (inv.id || '').toString().includes(searchTerm) ||
      (inv.package || '').toLowerCase().includes(searchTerm.toLowerCase());
    const matchStatus = filterStatus === 'all' || inv.status === filterStatus;
    return matchSearch && matchStatus;
  });

  if (loading) return <div style={{ padding: 40, textAlign: 'center', color: '#C9A227', fontSize: 18 }}>⏳ جاري التحميل...</div>;

  return (
    <div style={{ padding: '24px', direction: 'rtl', fontFamily: 'IBM Plex Sans Arabic, sans-serif' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24, flexWrap: 'wrap', gap: 12 }}>
        <div>
          <h1 style={{ fontSize: 26, fontWeight: 800, color: '#C9A227', margin: 0 }}>🧾 فواتير المدارس</h1>
          <p style={{ color: '#9CA3AF', marginTop: 6, fontSize: 14 }}>إدارة ومتابعة فواتير اشتراكات المؤسسات</p>
        </div>
      </div>

      {/* إحصائيات */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 16, marginBottom: 24 }}>
        {[
          { label: 'إجمالي الفواتير', value: `${stats.total.toLocaleString()} ر.س`, icon: '🧾', color: '#C9A227' },
          { label: 'المدفوعة', value: `${stats.paid.toLocaleString()} ر.س`, icon: '✅', color: '#10B981' },
          { label: 'المعلقة', value: `${stats.pending.toLocaleString()} ر.س`, icon: '⏳', color: '#F59E0B' },
          { label: 'الفاشلة', value: `${stats.failed.toLocaleString()} ر.س`, icon: '❌', color: '#EF4444' },
        ].map((s, i) => (
          <div key={i} style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 14, padding: 20 }}>
            <div style={{ fontSize: 28, marginBottom: 8 }}>{s.icon}</div>
            <div style={{ color: s.color, fontSize: 20, fontWeight: 800 }}>{s.value}</div>
            <div style={{ color: '#9CA3AF', fontSize: 13, marginTop: 4 }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* فلاتر */}
      <div style={{ display: 'flex', gap: 12, marginBottom: 20, flexWrap: 'wrap' }}>
        <input
          type="text"
          placeholder="🔍 بحث بالاسم أو رقم الفاتورة..."
          value={searchTerm}
          onChange={e => setSearchTerm(e.target.value)}
          style={{ padding: '10px 16px', background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, color: 'white', fontSize: 14, outline: 'none', minWidth: 250, fontFamily: 'IBM Plex Sans Arabic, sans-serif' }}
        />
        <select
          value={filterStatus}
          onChange={e => setFilterStatus(e.target.value)}
          style={{ padding: '10px 16px', background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, color: 'white', fontSize: 14, outline: 'none', cursor: 'pointer', fontFamily: 'IBM Plex Sans Arabic, sans-serif' }}
        >
          <option value="all">كل الحالات</option>
          <option value="paid">مدفوعة</option>
          <option value="pending">معلقة</option>
          <option value="failed">فاشلة</option>
        </select>
      </div>

      {/* جدول الفواتير */}
      {filtered.length === 0 ? (
        <div style={{ textAlign: 'center', padding: 60, background: 'rgba(255,255,255,0.02)', borderRadius: 16, border: '1px solid rgba(255,255,255,0.05)' }}>
          <div style={{ fontSize: 48, marginBottom: 16 }}>🧾</div>
          <h3 style={{ color: '#fff', fontSize: 18, margin: '0 0 8px' }}>لا توجد فواتير</h3>
          <p style={{ color: '#9CA3AF', fontSize: 14 }}>ستظهر الفواتير هنا عند إجراء أي عمليات دفع</p>
        </div>
      ) : (
        <div style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 14, overflow: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: 'rgba(201,162,39,0.08)' }}>
                <th style={{ padding: '14px 16px', textAlign: 'right', color: '#C9A227', fontWeight: 700, fontSize: 13 }}>#</th>
                <th style={{ padding: '14px 16px', textAlign: 'right', color: '#C9A227', fontWeight: 700, fontSize: 13 }}>المؤسسة / المستخدم</th>
                <th style={{ padding: '14px 16px', textAlign: 'center', color: '#C9A227', fontWeight: 700, fontSize: 13 }}>الباقة</th>
                <th style={{ padding: '14px 16px', textAlign: 'center', color: '#C9A227', fontWeight: 700, fontSize: 13 }}>المبلغ</th>
                <th style={{ padding: '14px 16px', textAlign: 'center', color: '#C9A227', fontWeight: 700, fontSize: 13 }}>الحالة</th>
                <th style={{ padding: '14px 16px', textAlign: 'center', color: '#C9A227', fontWeight: 700, fontSize: 13 }}>التاريخ</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((inv: any, idx: number) => {
                const badge = getStatusBadge(inv.status);
                return (
                  <tr key={inv.id} style={{ borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
                    <td style={{ padding: '12px 16px', color: '#6B7280', fontSize: 13 }}>#{inv.id}</td>
                    <td style={{ padding: '12px 16px', color: 'white', fontSize: 14, fontWeight: 600 }}>{inv.user_name || `مستخدم #${inv.user_id}`}</td>
                    <td style={{ padding: '12px 16px', textAlign: 'center', color: '#9CA3AF', fontSize: 13 }}>{inv.package || inv.description || '-'}</td>
                    <td style={{ padding: '12px 16px', textAlign: 'center', color: '#C9A227', fontWeight: 700, fontSize: 15 }}>{parseFloat(inv.amount || 0).toLocaleString()} ر.س</td>
                    <td style={{ padding: '12px 16px', textAlign: 'center' }}>
                      <span style={{ padding: '4px 12px', borderRadius: 20, fontSize: 12, fontWeight: 600, background: badge.bg, color: badge.color }}>{badge.text}</span>
                    </td>
                    <td style={{ padding: '12px 16px', textAlign: 'center', color: '#9CA3AF', fontSize: 13 }}>
                      {inv.created_at ? new Date(inv.created_at).toLocaleDateString('ar-SA') : '-'}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
