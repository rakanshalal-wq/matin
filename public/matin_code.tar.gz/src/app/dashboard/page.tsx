'use client';
import { useState, useEffect } from 'react';
import Link from 'next/link';

const getHeaders = (): Record<string, string> => {
  try {
    const token = localStorage.getItem('matin_token');
    if (token) return { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token };
    const u = JSON.parse(localStorage.getItem('matin_user') || '{}');
    return { 'Content-Type': 'application/json', 'x-user-id': String(u.id || '') };
  } catch { return { 'Content-Type': 'application/json' }; }
};

export default function SuperAdminDashboard() {
  const [user, setUser] = useState<any>(null);
  const [stats, setStats] = useState<any>({});
  const [recentSchools, setRecentSchools] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    try {
      const token = localStorage.getItem('matin_token');
      if (token) {
        fetch('/api/auth/verify', { headers: { 'Authorization': 'Bearer ' + token } })
          .then(r => r.json())
          .then(data => {
            if (data.valid) {
              setUser(data.user);
              localStorage.setItem('matin_user', JSON.stringify(data.user));
              loadData(data.user);
            } else {
              window.location.href = '/login';
            }
          }).catch(() => setLoading(false));
      } else {
        const u = JSON.parse(localStorage.getItem('matin_user') || '{}');
        if (u.id) { setUser(u); loadData(u); }
        else { window.location.href = '/login'; }
      }
    } catch { setLoading(false); }
  }, []);

  const loadData = async (u: any) => {
    try {
      const [statsRes, schoolsRes] = await Promise.all([
        fetch('/api/dashboard-stats', { headers: getHeaders() }),
        fetch('/api/schools', { headers: getHeaders() }),
      ]);
      const [statsData, schoolsData] = await Promise.all([statsRes.json(), schoolsRes.json()]);
      setStats(statsData || {});
      const schools = Array.isArray(schoolsData) ? schoolsData : [];
      setRecentSchools(schools.slice(0, 5));
    } catch {} finally { setLoading(false); }
  };

  const handleToggleSchool = async (id: string, currentStatus: string) => {
    const newStatus = currentStatus === 'ACTIVE' ? 'SUSPENDED' : 'ACTIVE';
    try {
      const res = await fetch('/api/schools', {
        method: 'PUT',
        headers: getHeaders(),
        body: JSON.stringify({ id, status: newStatus }),
      });
      if (res.ok) {
        setRecentSchools(prev => prev.map(s => s.id === id ? { ...s, status: newStatus } : s));
      }
    } catch {}
  };

  const greetingByTime = () => {
    const h = time.getHours();
    if (h < 12) return 'صباح الخير';
    if (h < 17) return 'مساء الخير';
    return 'مساء النور';
  };

  const formatDate = () => {
    return time.toLocaleDateString('ar-SA', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
  };

  const formatTime = () => {
    return time.toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' });
  };

  const statusColor = (status: string) => {
    if (status === 'ACTIVE') return '#10B981';
    if (status === 'SUSPENDED') return '#EF4444';
    if (status === 'TRIAL') return '#F59E0B';
    return '#6B7280';
  };

  const statusLabel = (status: string) => {
    if (status === 'ACTIVE') return 'نشط';
    if (status === 'SUSPENDED') return 'موقوف';
    if (status === 'TRIAL') return 'تجريبي';
    return status;
  };

  if (loading) return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '60vh' }}>
      <div style={{ textAlign: 'center' }}>
        <div style={{ width: 60, height: 60, borderRadius: 16, background: 'rgba(201,162,39,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 28, margin: '0 auto 16px' }}>م</div>
        <div style={{ color: '#C9A227', fontWeight: 700, fontSize: 18 }}>جاري تحميل لوحة التحكم...</div>
      </div>
    </div>
  );

  const kpiCards = [
    { label: 'المؤسسات المسجلة', value: stats.schools ?? 0, icon: '🏫', color: '#C9A227', href: '/dashboard/schools', sub: `${stats.active_schools ?? 0} نشطة` },
    { label: 'إجمالي الطلاب', value: stats.students ?? 0, icon: '🎓', color: '#10B981', href: '/dashboard/users', sub: 'في كل المؤسسات' },
    { label: 'إجمالي المعلمين', value: stats.teachers ?? 0, icon: '👨‍🏫', color: '#3B82F6', href: '/dashboard/users', sub: 'في كل المؤسسات' },
    { label: 'الاشتراكات الفعالة', value: stats.active_subscriptions ?? 0, icon: '💎', color: '#8B5CF6', href: '/dashboard/subscriptions', sub: 'باقات مدفوعة' },
    { label: 'إيراد هذا الشهر', value: `${(stats.monthly_revenue ?? 0).toLocaleString()} ر.س`, icon: '💰', color: '#F59E0B', href: '/dashboard/finance', sub: 'مجموع الاشتراكات' },
    { label: 'طلبات معلقة', value: stats.pending ?? 0, icon: '⏳', color: '#EF4444', href: '/dashboard/schools', sub: 'تحتاج مراجعة' },
  ];

  const quickActions = [
    { label: 'إضافة مؤسسة', icon: '🏫', href: '/dashboard/schools/add', color: '#C9A227', desc: 'تسجيل مؤسسة جديدة' },
    { label: 'إدارة الباقات', icon: '💎', href: '/dashboard/subscriptions', color: '#8B5CF6', desc: 'تعديل الأسعار والخطط' },
    { label: 'الإعلانات', icon: '📢', href: '/dashboard/ads', color: '#F59E0B', desc: 'إدارة إعلانات المنصة' },
    { label: 'التكاملات', icon: '🔗', href: '/dashboard/integrations', color: '#3B82F6', desc: 'OpenAI · الدفع · SMS' },
    { label: 'الصفحة الرئيسية', icon: '🌐', href: '/dashboard/news', color: '#10B981', desc: 'أخبار · صور · محتوى' },
    { label: 'التقارير المالية', icon: '📈', href: '/dashboard/finance', color: '#EC4899', desc: 'إيرادات وإحصاءات' },
    { label: 'إدارة المستخدمين', icon: '👥', href: '/dashboard/users', color: '#6366F1', desc: 'صلاحيات وحسابات' },
    { label: 'النسخ الاحتياطي', icon: '💾', href: '/dashboard/backup', color: '#14B8A6', desc: 'حماية بيانات المنصة' },
  ];

  return (
    <div style={{ direction: 'rtl', fontFamily: 'IBM Plex Sans Arabic, Tajawal, sans-serif', padding: '0 4px' }}>

      {/* ===== HEADER BAR ===== */}
      <div style={{
        background: 'linear-gradient(135deg, rgba(201,162,39,0.08) 0%, rgba(201,162,39,0.03) 100%)',
        border: '1px solid rgba(201,162,39,0.15)',
        borderRadius: 20,
        padding: '20px 28px',
        marginBottom: 28,
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        flexWrap: 'wrap',
        gap: 16,
      }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 6 }}>
            <span style={{ fontSize: 28 }}>👑</span>
            <h1 style={{ fontSize: 24, fontWeight: 900, color: '#C9A227', margin: 0 }}>
              {greetingByTime()}، {user?.name?.split(' ')[0] || 'رakan'}
            </h1>
          </div>
          <p style={{ color: 'rgba(255,255,255,0.45)', fontSize: 14, margin: 0 }}>
            لوحة تحكم مالك المنصة · منصة متين
          </p>
        </div>
        <div style={{ textAlign: 'left' }}>
          <div style={{ color: '#C9A227', fontSize: 22, fontWeight: 800, letterSpacing: 1 }}>{formatTime()}</div>
          <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: 13, marginTop: 2 }}>{formatDate()}</div>
        </div>
      </div>

      {/* ===== KPI CARDS ===== */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 14, marginBottom: 32 }}>
        {kpiCards.map((card, i) => (
          <Link key={i} href={card.href} style={{ textDecoration: 'none' }}>
            <div style={{
              background: 'rgba(255,255,255,0.03)',
              border: '1px solid rgba(255,255,255,0.07)',
              borderRadius: 16,
              padding: '18px 20px',
              cursor: 'pointer',
              transition: 'all 0.2s',
              position: 'relative',
              overflow: 'hidden',
            }}
              onMouseEnter={e => { (e.currentTarget as HTMLDivElement).style.borderColor = card.color + '40'; (e.currentTarget as HTMLDivElement).style.background = `${card.color}08`; }}
              onMouseLeave={e => { (e.currentTarget as HTMLDivElement).style.borderColor = 'rgba(255,255,255,0.07)'; (e.currentTarget as HTMLDivElement).style.background = 'rgba(255,255,255,0.03)'; }}
            >
              <div style={{ position: 'absolute', top: -10, left: -10, fontSize: 60, opacity: 0.05 }}>{card.icon}</div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <div>
                  <div style={{ color: 'rgba(255,255,255,0.45)', fontSize: 12, fontWeight: 600, marginBottom: 8, letterSpacing: 0.3 }}>{card.label}</div>
                  <div style={{ color: card.color, fontSize: 30, fontWeight: 900, lineHeight: 1 }}>{card.value}</div>
                  <div style={{ color: 'rgba(255,255,255,0.25)', fontSize: 11, marginTop: 6 }}>{card.sub}</div>
                </div>
                <div style={{ fontSize: 26, opacity: 0.8 }}>{card.icon}</div>
              </div>
            </div>
          </Link>
        ))}
      </div>

      {/* ===== MAIN GRID: quick actions + recent schools ===== */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.4fr', gap: 20, marginBottom: 28 }}>

        {/* Quick Actions */}
        <div style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.07)', borderRadius: 18, padding: 20 }}>
          <h2 style={{ color: 'white', fontSize: 16, fontWeight: 800, margin: '0 0 16px', display: 'flex', alignItems: 'center', gap: 8 }}>
            <span>⚡</span> وصول سريع
          </h2>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            {quickActions.map((a, i) => (
              <Link key={i} href={a.href} style={{ textDecoration: 'none' }}>
                <div style={{
                  background: 'rgba(255,255,255,0.03)',
                  border: '1px solid rgba(255,255,255,0.06)',
                  borderRadius: 12,
                  padding: '12px 14px',
                  cursor: 'pointer',
                  transition: 'all 0.18s',
                }}
                  onMouseEnter={e => { (e.currentTarget as HTMLDivElement).style.background = `${a.color}12`; (e.currentTarget as HTMLDivElement).style.borderColor = `${a.color}35`; }}
                  onMouseLeave={e => { (e.currentTarget as HTMLDivElement).style.background = 'rgba(255,255,255,0.03)'; (e.currentTarget as HTMLDivElement).style.borderColor = 'rgba(255,255,255,0.06)'; }}
                >
                  <div style={{ fontSize: 22, marginBottom: 6 }}>{a.icon}</div>
                  <div style={{ color: 'rgba(255,255,255,0.85)', fontSize: 13, fontWeight: 700, marginBottom: 2 }}>{a.label}</div>
                  <div style={{ color: 'rgba(255,255,255,0.3)', fontSize: 11 }}>{a.desc}</div>
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* Recent Schools */}
        <div style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.07)', borderRadius: 18, padding: 20 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
            <h2 style={{ color: 'white', fontSize: 16, fontWeight: 800, margin: 0, display: 'flex', alignItems: 'center', gap: 8 }}>
              <span>🏫</span> آخر المؤسسات المسجلة
            </h2>
            <Link href="/dashboard/schools" style={{ color: '#C9A227', fontSize: 13, textDecoration: 'none', fontWeight: 600 }}>عرض الكل ←</Link>
          </div>

          {recentSchools.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '32px 0', color: 'rgba(255,255,255,0.25)', fontSize: 14 }}>
              لا توجد مؤسسات مسجلة بعد
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {recentSchools.map((school, i) => (
                <div key={i} style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  background: 'rgba(255,255,255,0.02)',
                  border: '1px solid rgba(255,255,255,0.06)',
                  borderRadius: 12,
                  padding: '12px 14px',
                  gap: 12,
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 12, flex: 1, minWidth: 0 }}>
                    <div style={{
                      width: 38, height: 38, borderRadius: 10,
                      background: `${statusColor(school.status)}18`,
                      border: `1px solid ${statusColor(school.status)}30`,
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      fontSize: 18, flexShrink: 0,
                    }}>🏫</div>
                    <div style={{ minWidth: 0 }}>
                      <div style={{ color: 'rgba(255,255,255,0.9)', fontSize: 14, fontWeight: 700, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                        {school.name_ar || school.name || 'مؤسسة بدون اسم'}
                      </div>
                      <div style={{ color: 'rgba(255,255,255,0.3)', fontSize: 12, marginTop: 2 }}>
                        {school.owner_name || '—'} · {school.city || 'غير محدد'}
                      </div>
                    </div>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexShrink: 0 }}>
                    <span style={{
                      background: `${statusColor(school.status)}18`,
                      color: statusColor(school.status),
                      border: `1px solid ${statusColor(school.status)}30`,
                      borderRadius: 6, padding: '3px 10px', fontSize: 12, fontWeight: 700,
                    }}>{statusLabel(school.status)}</span>
                    <button
                      onClick={() => handleToggleSchool(school.id, school.status)}
                      style={{
                        background: school.status === 'ACTIVE' ? 'rgba(239,68,68,0.1)' : 'rgba(16,185,129,0.1)',
                        color: school.status === 'ACTIVE' ? '#EF4444' : '#10B981',
                        border: `1px solid ${school.status === 'ACTIVE' ? 'rgba(239,68,68,0.2)' : 'rgba(16,185,129,0.2)'}`,
                        borderRadius: 8, padding: '5px 10px', cursor: 'pointer', fontSize: 12, fontWeight: 700,
                      }}
                    >
                      {school.status === 'ACTIVE' ? '⏸ إيقاف' : '▶ تفعيل'}
                    </button>
                    <Link href={`/dashboard/schools?id=${school.id}`}>
                      <button style={{ background: 'rgba(201,162,39,0.1)', color: '#C9A227', border: '1px solid rgba(201,162,39,0.2)', borderRadius: 8, padding: '5px 10px', cursor: 'pointer', fontSize: 12, fontWeight: 700 }}>
                        ✏️ تعديل
                      </button>
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* ===== PLATFORM STATUS BAR ===== */}
      <div style={{
        background: 'rgba(255,255,255,0.02)',
        border: '1px solid rgba(255,255,255,0.07)',
        borderRadius: 16,
        padding: '16px 24px',
        display: 'flex',
        gap: 32,
        flexWrap: 'wrap',
        alignItems: 'center',
      }}>
        <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: 13, fontWeight: 700 }}>حالة المنصة</div>
        {[
          { label: 'السيرفر', value: '✅ يعمل', color: '#10B981' },
          { label: 'قاعدة البيانات', value: '✅ متصلة', color: '#10B981' },
          { label: 'إجمالي المستخدمين', value: String((stats.students ?? 0) + (stats.teachers ?? 0) + (stats.owners ?? 0)), color: '#C9A227' },
          { label: 'المدارس النشطة', value: String(stats.active_schools ?? stats.schools ?? 0), color: '#3B82F6' },
        ].map((item, i) => (
          <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <div style={{ width: 7, height: 7, borderRadius: '50%', background: item.color }} />
            <span style={{ color: 'rgba(255,255,255,0.35)', fontSize: 13 }}>{item.label}:</span>
            <span style={{ color: item.color, fontSize: 13, fontWeight: 700 }}>{item.value}</span>
          </div>
        ))}
      </div>

    </div>
  );
}
