'use client';
import { useState, useEffect } from 'react';

const getHeaders = (): Record<string, string> => { try { const token = localStorage.getItem('matin_token'); if (token) return { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token }; const u = JSON.parse(localStorage.getItem('matin_user') || '{}'); return { 'Content-Type': 'application/json', 'x-user-id': String(u.id || '') }; } catch { return { 'Content-Type': 'application/json' }; } };

const statusConfig: any = {
  DRAFT: { label: 'مسودة', color: '#9CA3AF', bg: 'rgba(156,163,175,0.15)', icon: '📝' },
  PUBLISHED: { label: 'منشور', color: '#3B82F6', bg: 'rgba(59,130,246,0.15)', icon: '📢' },
  ACTIVE: { label: 'جاري', color: '#F59E0B', bg: 'rgba(245,158,11,0.15)', icon: '⏱️' },
  COMPLETED: { label: 'مكتمل', color: '#10B981', bg: 'rgba(16,185,129,0.15)', icon: '✓' },
  CANCELLED: { label: 'ملغي', color: '#EF4444', bg: 'rgba(239,68,68,0.15)', icon: '✕' },
};
const typeLabels: any = { QUIZ: 'كويز', MIDTERM: 'نصفي', FINAL: 'نهائي', ASSIGNMENT: 'واجب', PRACTICE: 'تدريبي' };

export default function ExamsPage() {
  const [exams, setExams] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [user, setUser] = useState<any>(null);
  const [form, setForm] = useState({ title_ar: '', type: 'QUIZ', total_marks: '100', passing_marks: '50', duration: '60', description: '', scheduled_at: '' });
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState('');

  useEffect(() => {
    const u = JSON.parse(localStorage.getItem('matin_user') || '{}');
    setUser(u);
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const res = await fetch('/api/exams', { headers: getHeaders() });
      const data = await res.json();
      setExams(Array.isArray(data) ? data : []);
    } catch {} finally { setLoading(false); }
  };

  const handleAdd = async () => {
    if (!form.title_ar) { setMsg('عنوان الاختبار مطلوب'); return; }
    setSaving(true); setMsg('');
    try {
      const res = await fetch('/api/exams', { method: 'POST', headers: getHeaders(), body: JSON.stringify({...form, total_marks: parseInt(form.total_marks), passing_marks: parseInt(form.passing_marks), duration: parseInt(form.duration)}) });
      const data = await res.json();
      if (!res.ok) { setMsg(data.error || 'فشل'); setSaving(false); return; }
      setExams([data, ...exams]);
      setForm({ title_ar: '', type: 'QUIZ', total_marks: '100', passing_marks: '50', duration: '60', description: '', scheduled_at: '' });
      setShowAdd(false);
    } catch { setMsg('خطأ'); } finally { setSaving(false); }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('حذف هذا الاختبار؟')) return;
    await fetch(`/api/exams?id=${id}`, { method: 'DELETE', headers: getHeaders() });
    setExams(exams.filter(e => e.id !== id));
  };

  const handleStatusChange = async (id: string, status: string) => {
    try {
      await fetch('/api/exams', { method: 'PUT', headers: getHeaders(), body: JSON.stringify({ id, status }) });
      setExams(exams.map(e => e.id === id ? {...e, status} : e));
    } catch {}
  };

  const canAdd = ['super_admin', 'owner', 'admin', 'teacher'].includes(user?.role);
  const inputStyle = { width: '100%', padding: '12px 16px', background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 10, color: '#fff', fontSize: 14, fontFamily: 'IBM Plex Sans Arabic, sans-serif', outline: 'none', direction: 'rtl' as const };

  if (loading) return <div style={{ padding: 40, textAlign: 'center', color: '#C9A227' }}>جاري التحميل...</div>;

  return (
    <div style={{ padding: '24px', direction: 'rtl', fontFamily: 'IBM Plex Sans Arabic, sans-serif' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <div>
          <h1 style={{ fontSize: 24, fontWeight: 700, color: '#C9A227', margin: 0 }}>📝 الاختبارات</h1>
          <p style={{ color: '#9CA3AF', fontSize: 14, margin: '4px 0 0' }}>{exams.length} اختبار</p>
        </div>
        {canAdd && (
          <button onClick={() => setShowAdd(!showAdd)} style={{ padding: '10px 24px', background: showAdd ? '#374151' : 'linear-gradient(135deg, #C9A227, #E8C547)', color: showAdd ? '#fff' : '#000', border: 'none', borderRadius: 10, fontSize: 14, fontWeight: 700, cursor: 'pointer', fontFamily: 'IBM Plex Sans Arabic, sans-serif' }}>
            {showAdd ? '✕ إلغاء' : '+ إنشاء اختبار'}
          </button>
        )}
      </div>

      {msg && <div style={{ padding: 12, background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.3)', borderRadius: 10, color: '#EF4444', marginBottom: 16, fontSize: 14 }}>{msg}</div>}

      {showAdd && (
        <div style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(201,162,39,0.2)', borderRadius: 16, padding: 24, marginBottom: 24 }}>
          <h3 style={{ color: '#C9A227', fontSize: 18, margin: '0 0 20px', fontWeight: 700 }}>إنشاء اختبار جديد</h3>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 16 }}>
            <div style={{ gridColumn: '1 / -1' }}>
              <label style={{ color: '#9CA3AF', fontSize: 13, marginBottom: 6, display: 'block' }}>عنوان الاختبار *</label>
              <input style={inputStyle} placeholder="مثال: اختبار نصفي - الرياضيات" value={form.title_ar} onChange={e => setForm({...form, title_ar: e.target.value})} />
            </div>
            <div>
              <label style={{ color: '#9CA3AF', fontSize: 13, marginBottom: 6, display: 'block' }}>النوع</label>
              <select style={{...inputStyle, cursor: 'pointer'}} value={form.type} onChange={e => setForm({...form, type: e.target.value})}>
                <option value="QUIZ">كويز</option>
                <option value="MIDTERM">نصفي</option>
                <option value="FINAL">نهائي</option>
                <option value="ASSIGNMENT">واجب</option>
                <option value="PRACTICE">تدريبي</option>
              </select>
            </div>
            <div>
              <label style={{ color: '#9CA3AF', fontSize: 13, marginBottom: 6, display: 'block' }}>الدرجة الكاملة</label>
              <input type="number" style={inputStyle} value={form.total_marks} onChange={e => setForm({...form, total_marks: e.target.value})} />
            </div>
            <div>
              <label style={{ color: '#9CA3AF', fontSize: 13, marginBottom: 6, display: 'block' }}>درجة النجاح</label>
              <input type="number" style={inputStyle} value={form.passing_marks} onChange={e => setForm({...form, passing_marks: e.target.value})} />
            </div>
            <div>
              <label style={{ color: '#9CA3AF', fontSize: 13, marginBottom: 6, display: 'block' }}>المدة (دقائق)</label>
              <input type="number" style={inputStyle} value={form.duration} onChange={e => setForm({...form, duration: e.target.value})} />
            </div>
            <div>
              <label style={{ color: '#9CA3AF', fontSize: 13, marginBottom: 6, display: 'block' }}>موعد الاختبار</label>
              <input type="datetime-local" style={inputStyle} value={form.scheduled_at} onChange={e => setForm({...form, scheduled_at: e.target.value})} />
            </div>
            <div style={{ gridColumn: '1 / -1' }}>
              <label style={{ color: '#9CA3AF', fontSize: 13, marginBottom: 6, display: 'block' }}>الوصف</label>
              <input style={inputStyle} placeholder="وصف مختصر" value={form.description} onChange={e => setForm({...form, description: e.target.value})} />
            </div>
          </div>
          <button onClick={handleAdd} disabled={saving} style={{ marginTop: 20, padding: '12px 32px', background: 'linear-gradient(135deg, #C9A227, #E8C547)', color: '#000', border: 'none', borderRadius: 10, fontSize: 15, fontWeight: 700, cursor: 'pointer', fontFamily: 'IBM Plex Sans Arabic, sans-serif', opacity: saving ? 0.5 : 1 }}>
            {saving ? 'جاري الحفظ...' : '✓ إنشاء الاختبار'}
          </button>
        </div>
      )}

      {exams.length === 0 ? (
        <div style={{ textAlign: 'center', padding: 60, background: 'rgba(255,255,255,0.02)', borderRadius: 16, border: '1px solid rgba(255,255,255,0.05)' }}>
          <div style={{ fontSize: 48, marginBottom: 16 }}>📝</div>
          <h3 style={{ color: '#fff', fontSize: 18, margin: '0 0 8px' }}>لا توجد اختبارات بعد</h3>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {exams.map((e: any) => {
            const st = statusConfig[e.status] || statusConfig.DRAFT;
            return (
              <div key={e.id} style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 14, padding: 20 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
                      <h3 style={{ color: '#fff', fontSize: 16, fontWeight: 700, margin: 0 }}>{e.title_ar || e.title}</h3>
                      <span style={{ padding: '3px 10px', borderRadius: 20, fontSize: 11, background: st.bg, color: st.color }}>{st.icon} {st.label}</span>
                      <span style={{ padding: '3px 10px', borderRadius: 20, fontSize: 11, background: 'rgba(201,162,39,0.1)', color: '#C9A227' }}>{typeLabels[e.type] || e.type}</span>
                    </div>
                    <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
                      <span style={{ color: '#9CA3AF', fontSize: 13 }}>📊 {e.total_marks} درجة (النجاح: {e.passing_marks})</span>
                      <span style={{ color: '#9CA3AF', fontSize: 13 }}>⏱️ {e.duration} دقيقة</span>
                      <span style={{ color: '#9CA3AF', fontSize: 13 }}>❓ {e.questions_count || 0} سؤال</span>
                      <span style={{ color: '#9CA3AF', fontSize: 13 }}>👥 {e.students_count || 0} طالب</span>
                      {e.scheduled_at && <span style={{ color: '#9CA3AF', fontSize: 13 }}>📅 {new Date(e.scheduled_at).toLocaleDateString('ar-SA')}</span>}
                    </div>
                  </div>
                  {canAdd && (
                    <div style={{ display: 'flex', gap: 6 }}>
                      {e.status === 'DRAFT' && <button onClick={() => handleStatusChange(e.id, 'PUBLISHED')} style={{ padding: '5px 12px', background: 'rgba(59,130,246,0.1)', color: '#3B82F6', border: 'none', borderRadius: 6, fontSize: 11, cursor: 'pointer', fontFamily: 'IBM Plex Sans Arabic, sans-serif' }}>📢 نشر</button>}
                      {e.status === 'PUBLISHED' && <button onClick={() => handleStatusChange(e.id, 'ACTIVE')} style={{ padding: '5px 12px', background: 'rgba(245,158,11,0.1)', color: '#F59E0B', border: 'none', borderRadius: 6, fontSize: 11, cursor: 'pointer', fontFamily: 'IBM Plex Sans Arabic, sans-serif' }}>▶ تفعيل</button>}
                      {e.status === 'ACTIVE' && <button onClick={() => handleStatusChange(e.id, 'COMPLETED')} style={{ padding: '5px 12px', background: 'rgba(16,185,129,0.1)', color: '#10B981', border: 'none', borderRadius: 6, fontSize: 11, cursor: 'pointer', fontFamily: 'IBM Plex Sans Arabic, sans-serif' }}>✓ إنهاء</button>}
                      <button onClick={() => handleDelete(e.id)} style={{ padding: '5px 12px', background: 'rgba(239,68,68,0.1)', color: '#EF4444', border: 'none', borderRadius: 6, fontSize: 11, cursor: 'pointer', fontFamily: 'IBM Plex Sans Arabic, sans-serif' }}>🗑️</button>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
