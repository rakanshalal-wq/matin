'use client';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';

const G = '#C9A227', G2 = '#E8C547';
const DARK = '#060C18', CARD = 'rgba(255,255,255,0.03)', BORDER = 'rgba(255,255,255,0.07)';

const api = (url: string, opts: RequestInit = {}) =>
  fetch(url, { credentials: 'include', headers: { 'Content-Type': 'application/json' }, ...opts });

type Tab = 'overview'|'schools'|'users'|'plans'|'ads'|'finance'|'store'|'integrations'|'analytics'|'support'|'community'|'partners'|'notifications'|'security'|'backup'|'settings';

const TABS: {id:Tab;icon:string;label:string}[] = [
  {id:'overview',    icon:'📊', label:'نظرة عامة'},
  {id:'schools',     icon:'🏫', label:'المؤسسات'},
  {id:'users',       icon:'👥', label:'المستخدمون'},
  {id:'plans',       icon:'📦', label:'الباقات'},
  {id:'ads',         icon:'📢', label:'الإعلانات'},
  {id:'finance',     icon:'💰', label:'المالية'},
  {id:'store',       icon:'🛒', label:'المتجر'},
  {id:'integrations',icon:'🔌', label:'التكاملات'},
  {id:'analytics',   icon:'📈', label:'التحليلات'},
  {id:'support',     icon:'💬', label:'الدعم'},
  {id:'community',   icon:'🌐', label:'المجتمع'},
  {id:'partners',    icon:'🤝', label:'الشركاء'},
  {id:'notifications',icon:'🔔',label:'الإشعارات'},
  {id:'security',    icon:'🔐', label:'الأمان'},
  {id:'backup',      icon:'💾', label:'النسخ الاحتياطية'},
  {id:'settings',    icon:'⚙️', label:'الإعدادات'},
];

function Toast({msg, ok}: {msg:string;ok:boolean}) {
  return (
    <div style={{position:'fixed',top:24,left:'50%',transform:'translateX(-50%)',zIndex:9999,
      background:ok?'rgba(16,185,129,0.95)':'rgba(239,68,68,0.95)',
      color:'white',padding:'12px 32px',borderRadius:12,fontWeight:700,fontSize:14,
      boxShadow:'0 8px 40px rgba(0,0,0,0.5)',backdropFilter:'blur(12px)',
      border:`1px solid ${ok?'rgba(16,185,129,0.4)':'rgba(239,68,68,0.4)'}`}}>
      {msg}
    </div>
  );
}

function StatCard({icon,label,value,sub,color,onClick}:any) {
  return (
    <div onClick={onClick} style={{background:CARD,border:`1px solid ${BORDER}`,
      borderTop:`2px solid ${color}44`,borderRadius:16,padding:'20px 18px',
      cursor:onClick?'pointer':'default',transition:'all 0.2s'}}
      onMouseEnter={e=>{if(onClick)(e.currentTarget as HTMLElement).style.background='rgba(255,255,255,0.06)'}}
      onMouseLeave={e=>{if(onClick)(e.currentTarget as HTMLElement).style.background=CARD}}>
      <div style={{fontSize:28,marginBottom:10}}>{icon}</div>
      <div style={{fontSize:26,fontWeight:800,color,marginBottom:4}}>{typeof value==='number'?value.toLocaleString('ar-SA'):value}</div>
      <div style={{fontSize:12,color:'rgba(255,255,255,0.5)',fontWeight:600,marginBottom:2}}>{label}</div>
      {sub && <div style={{fontSize:11,color:'rgba(255,255,255,0.3)'}}>{sub}</div>}
    </div>
  );
}

function SectionHeader({title,sub,btn,onBtn}:any) {
  return (
    <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:24,flexWrap:'wrap',gap:12}}>
      <div>
        <h2 style={{fontSize:22,fontWeight:800,margin:0,color:'white'}}>{title}</h2>
        {sub && <p style={{color:'rgba(255,255,255,0.4)',fontSize:13,margin:'4px 0 0'}}>{sub}</p>}
      </div>
      {btn && <button onClick={onBtn} style={{background:`linear-gradient(135deg,${G},${G2})`,color:'#060C18',
        padding:'10px 22px',borderRadius:10,border:'none',fontWeight:700,cursor:'pointer',fontSize:14}}>
        {btn}
      </button>}
    </div>
  );
}

function Badge({label,color,bg}:{label:string;color:string;bg:string}) {
  return <span style={{background:bg,color,padding:'3px 10px',borderRadius:6,fontSize:11,fontWeight:700}}>{label}</span>;
}

function statusBadge(s:string) {
  const map:any = {
    ACTIVE:'#10B981',active:'#10B981',approved:'#10B981',
    TRIAL:'#F59E0B',trial:'#F59E0B',pending:'#F59E0B',
    SUSPENDED:'#EF4444',suspended:'#EF4444',rejected:'#EF4444',inactive:'#6B7280',
  };
  const labels:any = {ACTIVE:'نشط',active:'نشط',approved:'مفعّل',TRIAL:'تجريبي',trial:'تجريبي',pending:'معلق',SUSPENDED:'موقوف',suspended:'موقوف',rejected:'مرفوض',inactive:'غير نشط'};
  const c = map[s]||'#6B7280';
  return <Badge label={labels[s]||s} color={c} bg={`${c}18`}/>;
}

function Modal({title,onClose,children}:any) {
  return (
    <div style={{position:'fixed',inset:0,background:'rgba(0,0,0,0.8)',display:'flex',alignItems:'center',justifyContent:'center',zIndex:1000,padding:20}}>
      <div style={{background:'#0D1B2A',border:`1px solid ${BORDER}`,borderRadius:20,padding:32,width:'100%',maxWidth:520,maxHeight:'85vh',overflowY:'auto'}}>
        <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:24}}>
          <h3 style={{color:'white',fontWeight:800,fontSize:18,margin:0}}>{title}</h3>
          <button onClick={onClose} style={{background:'none',border:'none',color:'rgba(255,255,255,0.4)',fontSize:22,cursor:'pointer'}}>✕</button>
        </div>
        {children}
      </div>
    </div>
  );
}

function Input({label,value,onChange,type='text',placeholder=''}:any) {
  return (
    <div style={{marginBottom:14}}>
      <label style={{color:'rgba(255,255,255,0.5)',fontSize:12,fontWeight:600,display:'block',marginBottom:6}}>{label}</label>
      <input type={type} value={value} onChange={e=>onChange(e.target.value)} placeholder={placeholder}
        style={{width:'100%',background:'rgba(255,255,255,0.05)',border:`1px solid ${BORDER}`,borderRadius:10,
          padding:'10px 14px',color:'white',fontSize:13,outline:'none',boxSizing:'border-box'}}/>
    </div>
  );
}

function SaveBtn({label,onClick}:any) {
  return (
    <button onClick={onClick} style={{width:'100%',background:`linear-gradient(135deg,${G},${G2})`,
      color:'#060C18',padding:'13px',borderRadius:10,border:'none',fontWeight:800,cursor:'pointer',fontSize:14,marginTop:8}}>
      {label}
    </button>
  );
}

function EmptyState({icon,msg,btnLabel,onBtn}:any) {
  return (
    <div style={{textAlign:'center',padding:'60px 20px',background:CARD,border:`1px solid ${BORDER}`,borderRadius:16}}>
      <div style={{fontSize:52,marginBottom:16}}>{icon}</div>
      <div style={{color:'rgba(255,255,255,0.3)',fontSize:15,marginBottom:btnLabel?20:0}}>{msg}</div>
      {btnLabel && <button onClick={onBtn} style={{background:`linear-gradient(135deg,${G},${G2})`,color:'#060C18',
        padding:'10px 24px',borderRadius:10,border:'none',fontWeight:700,cursor:'pointer',fontSize:14}}>
        {btnLabel}
      </button>}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════
export default function SuperAdminDashboard() {
  const router = useRouter();
  const [me, setMe] = useState<any>(null);
  const [tab, setTab] = useState<Tab>('overview');
  const [loading, setLoading] = useState(true);
  const [toast, setToast] = useState<{msg:string;ok:boolean}|null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(true);

  // Data
  const [stats, setStats]             = useState<any>({});
  const [schools, setSchools]         = useState<any[]>([]);
  const [users, setUsers]             = useState<any[]>([]);
  const [plans, setPlans]             = useState<any[]>([]);
  const [ads, setAds]                 = useState<any[]>([]);
  const [subs, setSubs]               = useState<any[]>([]);
  const [leads, setLeads]             = useState<any[]>([]);
  const [coupons, setCoupons]         = useState<any[]>([]);
  const [support, setSupport]         = useState<any[]>([]);
  const [partners, setPartners]       = useState<any[]>([]);
  const [integrations, setIntegrations] = useState<any[]>([]);
  const [actLog, setActLog]           = useState<any[]>([]);
  const [errLogs, setErrLogs]         = useState<any[]>([]);
  const [products, setProducts]       = useState<any[]>([]);
  const [orders, setOrders]           = useState<any[]>([]);
  const [posts, setPosts]             = useState<any[]>([]);
  const [forums, setForums]           = useState<any[]>([]);
  const [surveys, setSurveys]         = useState<any[]>([]);
  const [settings, setSettings]       = useState<any>({});
  const [visitors, setVisitors]       = useState<any[]>([]);

  // Modals
  const [schoolModal, setSchoolModal] = useState(false);
  const [adModal, setAdModal]         = useState(false);
  const [planModal, setPlanModal]     = useState(false);
  const [couponModal, setCouponModal] = useState(false);
  const [partnerModal, setPartnerModal] = useState(false);
  const [editItem, setEditItem]       = useState<any>(null);

  // Forms
  const [sf, setSf] = useState({name_ar:'',email:'',phone:'',city:'',status:'TRIAL'});
  const [af, setAf] = useState({title:'',image_url:'',click_url:'',position:'top',priority:'1',start_date:'',end_date:''});
  const [pf, setPf] = useState({name:'',name_ar:'',price_monthly:'',price_yearly:'',max_students:'500',max_teachers:'20',features:''});
  const [cf, setCf] = useState({code:'',discount_type:'percentage',discount_value:'',max_uses:'',expires_at:''});
  const [partF, setPartF] = useState({name:'',logo_url:'',website:'',description:''});

  // Filters
  const [schoolSearch, setSchoolSearch] = useState('');
  const [schoolStatus, setSchoolStatus] = useState('all');
  const [userSearch, setUserSearch]     = useState('');
  const [userRole, setUserRole]         = useState('all');

  const showToast = (msg:string, ok=true) => {
    setToast({msg,ok});
    setTimeout(()=>setToast(null),3500);
  };

  useEffect(()=>{
    const init = async ()=>{
      try {
        const r = await api('/api/auth/me');
        if(!r.ok){router.push('/login');return;}
        const u = await r.json();
        if(u?.role !== 'super_admin'){router.push('/dashboard');return;}
        setMe(u);
        await Promise.all([
          fetchStats(), fetchSchools(), fetchUsers(), fetchPlans(),
          fetchAds(), fetchSubs(), fetchLeads(), fetchSupport(),
          fetchIntegrations(), fetchProducts(), fetchOrders(),
          fetchPosts(), fetchPartners(), fetchActLog(),
        ]);
      } catch { router.push('/login'); }
      finally { setLoading(false); }
    };
    init();
  },[]);

  const fetchStats        = async () => { try { const r=await api('/api/dashboard-stats'); const d=await r.json(); setStats(d); } catch {} };
  const fetchSchools      = async () => { try { const r=await api('/api/schools'); const d=await r.json(); setSchools(Array.isArray(d)?d:[]); } catch {} };
  const fetchUsers        = async () => { try { const r=await api('/api/users'); const d=await r.json(); setUsers(Array.isArray(d)?d:[]); } catch {} };
  const fetchPlans        = async () => { try { const r=await api('/api/plans'); const d=await r.json(); setPlans(Array.isArray(d)?d:[]); } catch {} };
  const fetchAds          = async () => { try { const r=await api('/api/ads/manage'); const d=await r.json(); setAds(Array.isArray(d)?d:[]); } catch {} };
  const fetchSubs         = async () => { try { const r=await api('/api/subscriptions'); const d=await r.json(); setSubs(Array.isArray(d)?d:[]); } catch {} };
  const fetchLeads        = async () => { try { const r=await api('/api/leads'); const d=await r.json(); setLeads(Array.isArray(d)?d:[]); } catch {} };
  const fetchSupport      = async () => { try { const r=await api('/api/support'); const d=await r.json(); setSupport(Array.isArray(d)?d:[]); } catch {} };
  const fetchIntegrations = async () => { try { const r=await api('/api/integrations'); const d=await r.json(); setIntegrations(Array.isArray(d)?d:[]); } catch {} };
  const fetchProducts     = async () => { try { const r=await api('/api/store/products'); const d=await r.json(); setProducts(Array.isArray(d.products)?d.products:[]); } catch {} };
  const fetchOrders       = async () => { try { const r=await api('/api/store/orders'); const d=await r.json(); setOrders(Array.isArray(d.orders)?d.orders:[]); } catch {} };
  const fetchPosts        = async () => { try { const r=await api('/api/posts'); const d=await r.json(); setPosts(Array.isArray(d.posts)?d.posts:[]); } catch {} };
  const fetchPartners     = async () => { try { const r=await api('/api/partners'); const d=await r.json(); setPartners(Array.isArray(d.partners)?d.partners:[]); } catch {} };
  const fetchActLog       = async () => { try { const r=await api('/api/activity-log'); const d=await r.json(); setActLog(Array.isArray(d)?d:[]); } catch {} };

  // ── Actions ──────────────────────────────────────────────────
  const saveSchool = async () => {
    if(!sf.name_ar){showToast('اسم المؤسسة مطلوب',false);return;}
    try {
      const method = editItem?'PUT':'POST';
      const body = editItem?{id:editItem.id,...sf}:sf;
      const r = await api('/api/schools',{method,body:JSON.stringify(body)});
      if(!r.ok){showToast('فشل الحفظ',false);return;}
      showToast(editItem?'تم تحديث المؤسسة ✅':'تمت إضافة المؤسسة ✅');
      setSchoolModal(false); setEditItem(null);
      setSf({name_ar:'',email:'',phone:'',city:'',status:'TRIAL'});
      fetchSchools();
    } catch { showToast('خطأ في الاتصال',false); }
  };

  const changeSchoolStatus = async (id:string,status:string) => {
    try { await api('/api/schools',{method:'PUT',body:JSON.stringify({id,status})}); fetchSchools(); showToast(status==='ACTIVE'?'تم التفعيل ✅':'تم الإيقاف'); } catch {}
  };

  const deleteSchool = async (id:string) => {
    if(!confirm('حذف المؤسسة؟ لا يمكن التراجع.'))return;
    try { await api(`/api/schools?id=${id}`,{method:'DELETE'}); fetchSchools(); showToast('تم الحذف'); } catch {}
  };

  const changeUserStatus = async (id:string,status:string) => {
    try {
      await api('/api/auth',{method:'POST',body:JSON.stringify({action:'toggle_status',user_id:parseInt(id),new_status:status})});
      fetchUsers(); showToast(status==='active'?'تم التفعيل ✅':'تم الإيقاف');
    } catch {}
  };

  const deleteUser = async (id:string,role:string) => {
    if(role==='super_admin'){showToast('لا يمكن حذف مالك المنصة',false);return;}
    if(!confirm('حذف المستخدم؟'))return;
    try {
      await api('/api/auth',{method:'POST',body:JSON.stringify({action:'delete_user',user_id:parseInt(id)})});
      fetchUsers(); showToast('تم الحذف');
    } catch {}
  };

  const saveAd = async () => {
    if(!af.title){showToast('عنوان الإعلان مطلوب',false);return;}
    try {
      const method = editItem?'PUT':'POST';
      const body = editItem?{id:editItem.id,...af,is_platform_ad:true}:{...af,is_platform_ad:true,is_active:true,priority:parseInt(af.priority)};
      const r = await api('/api/ads',{method,body:JSON.stringify(body)});
      if(!r.ok){showToast('فشل الحفظ',false);return;}
      showToast(editItem?'تم تحديث الإعلان ✅':'تم نشر الإعلان ✅');
      setAdModal(false); setEditItem(null);
      setAf({title:'',image_url:'',click_url:'',position:'top',priority:'1',start_date:'',end_date:''});
      fetchAds();
    } catch { showToast('خطأ',false); }
  };

  const toggleAd = async (ad:any) => {
    try { await api('/api/ads',{method:'PUT',body:JSON.stringify({id:ad.id,is_active:!ad.is_active})}); fetchAds(); } catch {}
  };

  const deleteAd = async (id:number) => {
    if(!confirm('حذف الإعلان؟'))return;
    try { await api(`/api/ads?id=${id}`,{method:'DELETE'}); fetchAds(); showToast('تم الحذف'); } catch {}
  };

  const savePlan = async () => {
    if(!pf.name_ar){showToast('اسم الباقة مطلوب',false);return;}
    try {
      const method = editItem?'PUT':'POST';
      const body = {
        ...(editItem?{id:editItem.id}:{}),
        name:pf.name||pf.name_ar, name_ar:pf.name_ar,
        price_monthly:parseFloat(pf.price_monthly)||0,
        price_yearly:parseFloat(pf.price_yearly)||0,
        max_students:parseInt(pf.max_students)||500,
        max_teachers:parseInt(pf.max_teachers)||20,
        features:pf.features.split('\n').filter(Boolean),
        is_active:true
      };
      const r = await api('/api/plans',{method,body:JSON.stringify(body)});
      if(!r.ok){showToast('فشل الحفظ',false);return;}
      showToast(editItem?'تم تحديث الباقة ✅':'تمت إضافة الباقة ✅');
      setPlanModal(false); setEditItem(null);
      setPf({name:'',name_ar:'',price_monthly:'',price_yearly:'',max_students:'500',max_teachers:'20',features:''});
      fetchPlans();
    } catch { showToast('خطأ',false); }
  };

  const deletePost = async (id:number) => {
    if(!confirm('حذف المنشور؟'))return;
    try { await api(`/api/posts?id=${id}`,{method:'DELETE'}); fetchPosts(); showToast('تم الحذف'); } catch {}
  };

  const createBackup = async () => {
    try {
      showToast('جاري إنشاء النسخة الاحتياطية...⏳');
      const r = await api('/api/backup',{method:'POST',body:JSON.stringify({action:'create'})});
      const d = await r.json();
      if(d.success) showToast('تم إنشاء النسخة الاحتياطية ✅');
      else showToast(d.error||'فشل',false);
    } catch { showToast('خطأ',false); }
  };

  const sendNotification = async (title:string,body:string) => {
    try {
      const r = await api('/api/push-notifications',{method:'POST',body:JSON.stringify({title,body,target:'all'})});
      const d = await r.json();
      if(d.success||r.ok) showToast('تم إرسال الإشعار ✅');
      else showToast('فشل الإرسال',false);
    } catch { showToast('خطأ',false); }
  };

  // ── Filters ──
  const filteredSchools = schools.filter(s=>{
    const n=(s.name||s.name_ar||'').toLowerCase();
    return n.includes(schoolSearch.toLowerCase()) && (schoolStatus==='all'||s.status===schoolStatus);
  });
  const filteredUsers = users.filter(u=>{
    const match=(u.name||'').toLowerCase().includes(userSearch.toLowerCase())||(u.email||'').toLowerCase().includes(userSearch.toLowerCase());
    return match && (userRole==='all'||u.role===userRole);
  });

  const timeAgo = (d:string)=>{
    if(!d)return'—';
    const diff=Date.now()-new Date(d).getTime();
    const m=Math.floor(diff/60000);
    if(m<1)return'الآن';if(m<60)return`منذ ${m}د`;
    const h=Math.floor(m/60);if(h<24)return`منذ ${h}س`;
    return`منذ ${Math.floor(h/24)} يوم`;
  };

  if(loading) return (
    <div style={{display:'flex',alignItems:'center',justifyContent:'center',minHeight:'70vh',flexDirection:'column',gap:16,background:DARK}}>
      <div style={{width:64,height:64,background:`linear-gradient(135deg,${G},${G2})`,borderRadius:18,display:'flex',alignItems:'center',justifyContent:'center',fontSize:32,boxShadow:`0 0 60px ${G}55`}}>👑</div>
      <p style={{color:G,fontWeight:700,fontSize:15}}>جاري تحميل لوحة تحكم المنصة...</p>
    </div>
  );

  // ════════════════════════════════════════════════════════════════
  return (
    <div style={{direction:'rtl',fontFamily:"'Segoe UI',system-ui,sans-serif",minHeight:'100vh',background:DARK,color:'white',display:'flex'}}>

      {toast && <Toast msg={toast.msg} ok={toast.ok}/>}

      {/* ── Sidebar ── */}
      <div style={{width:sidebarOpen?220:64,flexShrink:0,background:'rgba(0,0,0,0.4)',borderLeft:`1px solid ${BORDER}`,
        transition:'width 0.3s',overflow:'hidden',display:'flex',flexDirection:'column',position:'sticky',top:0,height:'100vh'}}>

        {/* Logo */}
        <div style={{padding:'20px 16px',borderBottom:`1px solid ${BORDER}`,display:'flex',alignItems:'center',gap:12}}>
          <div style={{width:36,height:36,background:`linear-gradient(135deg,${G},${G2})`,borderRadius:10,
            display:'flex',alignItems:'center',justifyContent:'center',fontSize:18,flexShrink:0}}>👑</div>
          {sidebarOpen && <div>
            <div style={{fontSize:14,fontWeight:800,color:G}}>مالك المنصة</div>
            <div style={{fontSize:10,color:'rgba(255,255,255,0.3)'}}>{me?.name}</div>
          </div>}
        </div>

        {/* Tabs */}
        <div style={{flex:1,overflowY:'auto',padding:'8px 0'}}>
          {TABS.map(t=>(
            <button key={t.id} onClick={()=>setTab(t.id)}
              style={{width:'100%',display:'flex',alignItems:'center',gap:12,padding:'10px 16px',
                background:tab===t.id?`${G}18`:'transparent',
                borderRight:tab===t.id?`3px solid ${G}`:'3px solid transparent',
                border:'none',cursor:'pointer',color:tab===t.id?G:'rgba(255,255,255,0.45)',
                fontWeight:tab===t.id?700:400,fontSize:13,textAlign:'right',transition:'all 0.15s',
                whiteSpace:'nowrap'}}>
              <span style={{fontSize:16,flexShrink:0}}>{t.icon}</span>
              {sidebarOpen && t.label}
            </button>
          ))}
        </div>

        {/* Toggle */}
        <button onClick={()=>setSidebarOpen(!sidebarOpen)}
          style={{padding:'14px 16px',background:'none',border:'none',cursor:'pointer',
            color:'rgba(255,255,255,0.3)',borderTop:`1px solid ${BORDER}`,fontSize:16}}>
          {sidebarOpen?'◀':'▶'}
        </button>
      </div>

      {/* ── Main ── */}
      <div style={{flex:1,padding:'28px 32px',overflowY:'auto',maxHeight:'100vh'}}>

        {/* ════ نظرة عامة ════ */}
        {tab==='overview' && (
          <div>
            <SectionHeader title="📊 نظرة عامة" sub={`مرحباً ${me?.name} — لوحة تحكم منصة متين التعليمية`}/>

            <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(160px,1fr))',gap:14,marginBottom:28}}>
              <StatCard icon="🏫" label="المؤسسات النشطة" value={stats.schools||schools.length} color={G} onClick={()=>setTab('schools')}/>
              <StatCard icon="👑" label="ملاك المدارس" value={stats.owners||0} color="#8B5CF6" onClick={()=>setTab('users')}/>
              <StatCard icon="🎓" label="إجمالي الطلاب" value={stats.students||0} color="#10B981" onClick={()=>setTab('users')}/>
              <StatCard icon="👨‍🏫" label="إجمالي المعلمين" value={stats.teachers||0} color="#3B82F6" onClick={()=>setTab('users')}/>
              <StatCard icon="⏳" label="طلبات معلقة" value={stats.pending||0} color="#F59E0B" sub="تنتظر الموافقة" onClick={()=>setTab('users')}/>
              <StatCard icon="👥" label="إجمالي المستخدمين" value={stats.active_users||users.length} color="#06B6D4" onClick={()=>setTab('users')}/>
              <StatCard icon="📢" label="إعلانات نشطة" value={ads.filter(a=>a.is_active).length} color="#F59E0B" onClick={()=>setTab('ads')}/>
              <StatCard icon="📦" label="الباقات" value={plans.length} color="#EC4899" onClick={()=>setTab('plans')}/>
            </div>

            {/* إجراءات سريعة */}
            <div style={{marginBottom:28}}>
              <div style={{fontSize:11,fontWeight:700,color:'rgba(255,255,255,0.3)',letterSpacing:2,marginBottom:14}}>⚡ إجراءات سريعة</div>
              <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(140px,1fr))',gap:10}}>
                {[
                  {icon:'🏫',label:'إضافة مؤسسة',   action:()=>{setTab('schools');setTimeout(()=>setSchoolModal(true),100)}},
                  {icon:'📢',label:'إعلان جديد',     action:()=>{setTab('ads');setTimeout(()=>setAdModal(true),100)}},
                  {icon:'📦',label:'باقة جديدة',      action:()=>{setTab('plans');setTimeout(()=>setPlanModal(true),100)}},
                  {icon:'🔔',label:'إشعار جماعي',    action:()=>setTab('notifications')},
                  {icon:'💾',label:'نسخة احتياطية',  action:()=>setTab('backup')},
                  {icon:'📈',label:'التحليلات',      action:()=>setTab('analytics')},
                ].map((a,i)=>(
                  <button key={i} onClick={a.action} style={{background:CARD,border:`1px solid ${BORDER}`,
                    borderRadius:14,padding:'16px 12px',cursor:'pointer',textAlign:'center',
                    display:'flex',flexDirection:'column',alignItems:'center',gap:8,transition:'all 0.2s'}}
                    onMouseEnter={e=>(e.currentTarget.style.background=`${G}12`)}
                    onMouseLeave={e=>(e.currentTarget.style.background=CARD)}>
                    <span style={{fontSize:26}}>{a.icon}</span>
                    <span style={{color:'rgba(255,255,255,0.65)',fontSize:12,fontWeight:600}}>{a.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* آخر المؤسسات + العملاء المحتملين */}
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:20}}>
              <div style={{background:CARD,border:`1px solid ${BORDER}`,borderRadius:16,padding:20}}>
                <div style={{display:'flex',justifyContent:'space-between',marginBottom:16}}>
                  <span style={{fontWeight:700}}>🏫 آخر المؤسسات</span>
                  <button onClick={()=>setTab('schools')} style={{background:'none',border:'none',color:G,cursor:'pointer',fontSize:12}}>عرض الكل ←</button>
                </div>
                {schools.slice(0,5).map((s,i)=>(
                  <div key={i} style={{display:'flex',justifyContent:'space-between',alignItems:'center',padding:'10px 0',borderBottom:`1px solid ${BORDER}`}}>
                    <div>
                      <div style={{fontWeight:600,fontSize:13}}>{s.name||s.name_ar}</div>
                      <div style={{color:'rgba(255,255,255,0.3)',fontSize:11}}>{s.city||'—'}</div>
                    </div>
                    {statusBadge(s.status)}
                  </div>
                ))}
                {schools.length===0 && <div style={{color:'rgba(255,255,255,0.3)',textAlign:'center',padding:20}}>لا توجد مؤسسات</div>}
              </div>

              <div style={{background:CARD,border:`1px solid ${BORDER}`,borderRadius:16,padding:20}}>
                <div style={{display:'flex',justifyContent:'space-between',marginBottom:16}}>
                  <span style={{fontWeight:700}}>🎯 العملاء المحتملين</span>
                  <span style={{background:`${G}18`,color:G,padding:'2px 10px',borderRadius:6,fontSize:11,fontWeight:700}}>{leads.length}</span>
                </div>
                {leads.slice(0,5).map((l,i)=>(
                  <div key={i} style={{display:'flex',justifyContent:'space-between',alignItems:'center',padding:'10px 0',borderBottom:`1px solid ${BORDER}`}}>
                    <div>
                      <div style={{fontWeight:600,fontSize:13}}>{l.school_name||l.name||'—'}</div>
                      <div style={{color:'rgba(255,255,255,0.3)',fontSize:11}}>{l.email||'—'}</div>
                    </div>
                    <span style={{color:'rgba(255,255,255,0.3)',fontSize:11}}>{timeAgo(l.created_at)}</span>
                  </div>
                ))}
                {leads.length===0 && <div style={{color:'rgba(255,255,255,0.3)',textAlign:'center',padding:20}}>لا يوجد عملاء محتملون</div>}
              </div>
            </div>
          </div>
        )}

        {/* ════ المؤسسات ════ */}
        {tab==='schools' && (
          <div>
            <SectionHeader title="🏫 إدارة المؤسسات" sub={`${schools.length} مؤسسة مسجلة`} btn="+ إضافة مؤسسة" onBtn={()=>{setEditItem(null);setSf({name_ar:'',email:'',phone:'',city:'',status:'TRIAL'});setSchoolModal(true)}}/>

            <div style={{display:'flex',gap:10,marginBottom:16,flexWrap:'wrap'}}>
              <input value={schoolSearch} onChange={e=>setSchoolSearch(e.target.value)} placeholder="🔍 بحث..."
                style={{flex:1,minWidth:200,background:'rgba(255,255,255,0.05)',border:`1px solid ${BORDER}`,
                  borderRadius:10,padding:'10px 14px',color:'white',fontSize:13,outline:'none'}}/>
              {['all','ACTIVE','TRIAL','SUSPENDED'].map(s=>(
                <button key={s} onClick={()=>setSchoolStatus(s)}
                  style={{padding:'8px 16px',borderRadius:8,border:`1px solid ${schoolStatus===s?G:BORDER}`,
                    background:schoolStatus===s?`${G}18`:'transparent',
                    color:schoolStatus===s?G:'rgba(255,255,255,0.4)',cursor:'pointer',fontSize:12,fontWeight:600}}>
                  {s==='all'?'الكل':s==='ACTIVE'?'نشط':s==='TRIAL'?'تجريبي':'موقوف'}
                </button>
              ))}
            </div>

            <div style={{background:CARD,border:`1px solid ${BORDER}`,borderRadius:16,overflow:'hidden'}}>
              <div style={{display:'grid',gridTemplateColumns:'2fr 1fr 1fr 1fr 1.5fr',padding:'12px 20px',
                background:'rgba(255,255,255,0.04)',borderBottom:`1px solid ${BORDER}`}}>
                {['المؤسسة','المدينة','المالك','الحالة','إجراءات'].map((h,i)=>(
                  <span key={i} style={{color:'rgba(255,255,255,0.3)',fontSize:11,fontWeight:700,textTransform:'uppercase'}}>{h}</span>
                ))}
              </div>
              {filteredSchools.length===0
                ? <div style={{textAlign:'center',padding:40,color:'rgba(255,255,255,0.3)'}}>لا توجد نتائج</div>
                : filteredSchools.map((s,i)=>(
                <div key={i} style={{display:'grid',gridTemplateColumns:'2fr 1fr 1fr 1fr 1.5fr',
                  padding:'14px 20px',borderBottom:`1px solid ${BORDER}`,alignItems:'center'}}>
                  <div>
                    <div style={{fontWeight:600,fontSize:14}}>{s.name||s.name_ar}</div>
                    <div style={{color:'rgba(255,255,255,0.3)',fontSize:11}}>{s.email||'—'}</div>
                  </div>
                  <div style={{color:'rgba(255,255,255,0.5)',fontSize:13}}>{s.city||'—'}</div>
                  <div style={{color:'rgba(255,255,255,0.5)',fontSize:12}}>{s.owner_name||'—'}</div>
                  {statusBadge(s.status)}
                  <div style={{display:'flex',gap:6,flexWrap:'wrap'}}>
                    {s.status!=='ACTIVE'&&s.status!=='active'&&<button onClick={()=>changeSchoolStatus(s.id,'ACTIVE')} style={{background:'rgba(16,185,129,0.12)',border:'1px solid rgba(16,185,129,0.25)',color:'#10B981',padding:'4px 10px',borderRadius:6,cursor:'pointer',fontSize:11,fontWeight:600}}>تفعيل</button>}
                    {(s.status==='ACTIVE'||s.status==='active')&&<button onClick={()=>changeSchoolStatus(s.id,'SUSPENDED')} style={{background:'rgba(245,158,11,0.12)',border:'1px solid rgba(245,158,11,0.25)',color:'#F59E0B',padding:'4px 10px',borderRadius:6,cursor:'pointer',fontSize:11,fontWeight:600}}>إيقاف</button>}
                    <button onClick={()=>{setEditItem(s);setSf({name_ar:s.name_ar||s.name||'',email:s.email||'',phone:s.phone||'',city:s.city||'',status:s.status||'TRIAL'});setSchoolModal(true)}} style={{background:'rgba(59,130,246,0.12)',border:'1px solid rgba(59,130,246,0.25)',color:'#3B82F6',padding:'4px 10px',borderRadius:6,cursor:'pointer',fontSize:11,fontWeight:600}}>تعديل</button>
                    <button onClick={()=>deleteSchool(s.id)} style={{background:'rgba(239,68,68,0.12)',border:'1px solid rgba(239,68,68,0.25)',color:'#EF4444',padding:'4px 10px',borderRadius:6,cursor:'pointer',fontSize:11,fontWeight:600}}>حذف</button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ════ المستخدمون ════ */}
        {tab==='users' && (
          <div>
            <SectionHeader title="👥 إدارة المستخدمين" sub={`${users.length} مستخدم مسجل`}/>
            <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(130px,1fr))',gap:12,marginBottom:20}}>
              {[
                {label:'ملاك مدارس',value:users.filter(u=>u.role==='owner').length,color:'#8B5CF6'},
                {label:'معلمون',value:users.filter(u=>u.role==='teacher').length,color:'#3B82F6'},
                {label:'طلاب',value:users.filter(u=>u.role==='student').length,color:'#10B981'},
                {label:'معلقون',value:users.filter(u=>u.status==='pending').length,color:'#F59E0B'},
              ].map((c,i)=>(
                <div key={i} style={{background:CARD,border:`1px solid ${BORDER}`,borderRadius:12,padding:'14px',textAlign:'center'}}>
                  <div style={{fontSize:20,fontWeight:800,color:c.color}}>{c.value}</div>
                  <div style={{fontSize:11,color:'rgba(255,255,255,0.4)',marginTop:4}}>{c.label}</div>
                </div>
              ))}
            </div>

            <div style={{display:'flex',gap:10,marginBottom:16,flexWrap:'wrap'}}>
              <input value={userSearch} onChange={e=>setUserSearch(e.target.value)} placeholder="🔍 بحث بالاسم أو البريد..."
                style={{flex:1,minWidth:200,background:'rgba(255,255,255,0.05)',border:`1px solid ${BORDER}`,borderRadius:10,padding:'10px 14px',color:'white',fontSize:13,outline:'none'}}/>
              {['all','owner','teacher','student','parent'].map(r=>(
                <button key={r} onClick={()=>setUserRole(r)}
                  style={{padding:'8px 14px',borderRadius:8,border:`1px solid ${userRole===r?G:BORDER}`,
                    background:userRole===r?`${G}18`:'transparent',color:userRole===r?G:'rgba(255,255,255,0.4)',cursor:'pointer',fontSize:12,fontWeight:600}}>
                  {r==='all'?'الكل':r==='owner'?'ملاك':r==='teacher'?'معلمون':r==='student'?'طلاب':'أولياء'}
                </button>
              ))}
            </div>

            <div style={{background:CARD,border:`1px solid ${BORDER}`,borderRadius:16,overflow:'hidden'}}>
              <div style={{display:'grid',gridTemplateColumns:'2fr 1fr 1fr 1fr 1fr',padding:'12px 20px',
                background:'rgba(255,255,255,0.04)',borderBottom:`1px solid ${BORDER}`}}>
                {['المستخدم','الدور','الحالة','التسجيل','إجراءات'].map((h,i)=>(
                  <span key={i} style={{color:'rgba(255,255,255,0.3)',fontSize:11,fontWeight:700}}>{h}</span>
                ))}
              </div>
              {filteredUsers.map((u,i)=>{
                const roleColors:any={super_admin:G,owner:'#8B5CF6',admin:'#3B82F6',teacher:'#10B981',student:'#EC4899',parent:'#F59E0B'};
                const roleLabels:any={super_admin:'مالك المنصة',owner:'مالك مدرسة',admin:'مدير',teacher:'معلم',student:'طالب',parent:'ولي أمر'};
                return (
                  <div key={i} style={{display:'grid',gridTemplateColumns:'2fr 1fr 1fr 1fr 1fr',
                    padding:'14px 20px',borderBottom:`1px solid ${BORDER}`,alignItems:'center'}}>
                    <div>
                      <div style={{fontWeight:600,fontSize:14}}>{u.name}</div>
                      <div style={{color:'rgba(255,255,255,0.3)',fontSize:11}}>{u.email}</div>
                    </div>
                    <span style={{color:roleColors[u.role]||'#6B7280',fontSize:12,fontWeight:700}}>{roleLabels[u.role]||u.role}</span>
                    {statusBadge(u.status)}
                    <span style={{color:'rgba(255,255,255,0.4)',fontSize:12}}>{timeAgo(u.created_at)}</span>
                    <div style={{display:'flex',gap:6,flexWrap:'wrap'}}>
                      {u.role!=='super_admin'&&u.status!=='active'&&<button onClick={()=>changeUserStatus(u.id,'active')} style={{background:'rgba(16,185,129,0.12)',border:'1px solid rgba(16,185,129,0.25)',color:'#10B981',padding:'4px 10px',borderRadius:6,cursor:'pointer',fontSize:11}}>تفعيل</button>}
                      {u.role!=='super_admin'&&u.status==='active'&&<button onClick={()=>changeUserStatus(u.id,'suspended')} style={{background:'rgba(245,158,11,0.12)',border:'1px solid rgba(245,158,11,0.25)',color:'#F59E0B',padding:'4px 10px',borderRadius:6,cursor:'pointer',fontSize:11}}>إيقاف</button>}
                      {u.role!=='super_admin'&&<button onClick={()=>deleteUser(u.id,u.role)} style={{background:'rgba(239,68,68,0.12)',border:'1px solid rgba(239,68,68,0.25)',color:'#EF4444',padding:'4px 10px',borderRadius:6,cursor:'pointer',fontSize:11}}>حذف</button>}
                    </div>
                  </div>
                );
              })}
              {filteredUsers.length===0&&<div style={{textAlign:'center',padding:40,color:'rgba(255,255,255,0.3)'}}>لا توجد نتائج</div>}
            </div>
          </div>
        )}

        {/* ════ الباقات ════ */}
        {tab==='plans' && (
          <div>
            <SectionHeader title="📦 إدارة الباقات" sub="الباقات المعروضة على المؤسسات" btn="+ باقة جديدة" onBtn={()=>{setEditItem(null);setPf({name:'',name_ar:'',price_monthly:'',price_yearly:'',max_students:'500',max_teachers:'20',features:''});setPlanModal(true)}}/>
            <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(260px,1fr))',gap:16}}>
              {plans.map((p,i)=>(
                <div key={i} style={{background:CARD,border:`1px solid ${p.is_active!==false?`${G}33`:BORDER}`,borderRadius:16,padding:24,position:'relative'}}>
                  {p.is_active!==false&&<div style={{position:'absolute',top:12,left:12,background:`${G}22`,color:G,padding:'2px 10px',borderRadius:6,fontSize:11,fontWeight:700}}>● نشط</div>}
                  <div style={{fontSize:32,marginBottom:12}}>{i===0?'🥉':i===1?'🥈':i===2?'🥇':'💎'}</div>
                  <div style={{fontSize:18,fontWeight:800,marginBottom:4}}>{p.name_ar||p.name}</div>
                  <div style={{fontSize:26,fontWeight:800,color:G,marginBottom:4}}>
                    {p.price_monthly===0?'مجاناً':`${p.price_monthly} ريال`}
                    {p.price_monthly>0&&<span style={{fontSize:12,color:'rgba(255,255,255,0.3)',fontWeight:400}}>/شهر</span>}
                  </div>
                  {p.price_yearly>0&&<div style={{fontSize:12,color:'rgba(255,255,255,0.3)',marginBottom:12}}>{p.price_yearly} ريال/سنة</div>}
                  <div style={{fontSize:12,color:'rgba(255,255,255,0.4)',marginBottom:12}}>
                    👨‍🎓 حتى {p.max_students} طالب · 👨‍🏫 {p.max_teachers} معلم
                  </div>
                  {p.features&&(
                    <div style={{marginBottom:16}}>
                      {(Array.isArray(p.features)?p.features:String(p.features).split('\n')).slice(0,4).map((f:string,j:number)=>(
                        <div key={j} style={{color:'rgba(255,255,255,0.5)',fontSize:12,marginBottom:4,display:'flex',gap:8}}>
                          <span style={{color:'#10B981'}}>✓</span>{f}
                        </div>
                      ))}
                    </div>
                  )}
                  <div style={{display:'flex',gap:8}}>
                    <button onClick={()=>{setEditItem(p);setPf({name:p.name||'',name_ar:p.name_ar||p.name||'',price_monthly:String(p.price_monthly||0),price_yearly:String(p.price_yearly||0),max_students:String(p.max_students||500),max_teachers:String(p.max_teachers||20),features:Array.isArray(p.features)?p.features.join('\n'):String(p.features||'')});setPlanModal(true)}}
                      style={{flex:1,background:'rgba(59,130,246,0.12)',border:'1px solid rgba(59,130,246,0.25)',color:'#3B82F6',padding:'8px',borderRadius:8,cursor:'pointer',fontSize:12,fontWeight:600}}>تعديل</button>
                  </div>
                </div>
              ))}
              {plans.length===0&&<EmptyState icon="📦" msg="لا توجد باقات بعد" btnLabel="+ أضف باقة" onBtn={()=>setPlanModal(true)}/>}
            </div>
          </div>
        )}

        {/* ════ الإعلانات ════ */}
        {tab==='ads' && (
          <div>
            <SectionHeader title="📢 الإعلانات المركزية" sub="تظهر تلقائياً في جميع مدارس المنصة" btn="+ إعلان جديد" onBtn={()=>{setEditItem(null);setAf({title:'',image_url:'',click_url:'',position:'top',priority:'1',start_date:'',end_date:''});setAdModal(true)}}/>
            <div style={{background:`${G}0D`,border:`1px solid ${G}22`,borderRadius:12,padding:'14px 18px',marginBottom:20,display:'flex',gap:12,alignItems:'center'}}>
              <span style={{fontSize:18}}>💡</span>
              <p style={{color:'rgba(255,255,255,0.5)',fontSize:13,margin:0}}>
                الإعلانات المنشورة هنا تظهر في <strong style={{color:G}}>جميع صفحات المدارس</strong> تلقائياً.
              </p>
            </div>
            {ads.length===0
              ? <EmptyState icon="📢" msg="لا توجد إعلانات" btnLabel="+ أضف إعلان" onBtn={()=>setAdModal(true)}/>
              : <div style={{display:'grid',gap:12}}>
                {ads.map((ad,i)=>(
                  <div key={i} style={{background:CARD,border:`1px solid ${ad.is_active?'rgba(16,185,129,0.2)':BORDER}`,borderRadius:14,padding:20,display:'flex',gap:16,alignItems:'center',flexWrap:'wrap'}}>
                    {ad.image_url
                      ? <img src={ad.image_url} alt="" style={{width:80,height:56,objectFit:'cover',borderRadius:8,border:`1px solid ${BORDER}`,flexShrink:0}}/>
                      : <div style={{width:80,height:56,background:`${G}18`,borderRadius:8,display:'flex',alignItems:'center',justifyContent:'center',fontSize:24,flexShrink:0}}>📢</div>}
                    <div style={{flex:1}}>
                      <div style={{fontWeight:700,fontSize:15,marginBottom:4}}>{ad.title}</div>
                      <div style={{display:'flex',gap:8,flexWrap:'wrap'}}>
                        <span style={{background:ad.is_active?'rgba(16,185,129,0.15)':'rgba(107,114,128,0.15)',color:ad.is_active?'#10B981':'#6B7280',padding:'2px 8px',borderRadius:5,fontSize:11,fontWeight:700}}>
                          {ad.is_active?'● نشط':'○ موقوف'}
                        </span>
                        <span style={{background:`${G}18`,color:G,padding:'2px 8px',borderRadius:5,fontSize:11}}>{ad.position}</span>
                        <span style={{color:'rgba(255,255,255,0.3)',fontSize:11}}>👁 {ad.views||0} · 🖱 {ad.clicks||0}</span>
                      </div>
                    </div>
                    <div style={{display:'flex',gap:8,flexShrink:0}}>
                      <button onClick={()=>toggleAd(ad)} style={{background:ad.is_active?'rgba(107,114,128,0.12)':'rgba(16,185,129,0.12)',border:`1px solid ${ad.is_active?'rgba(107,114,128,0.25)':'rgba(16,185,129,0.25)'}`,color:ad.is_active?'#6B7280':'#10B981',padding:'6px 12px',borderRadius:8,cursor:'pointer',fontSize:12,fontWeight:600}}>
                        {ad.is_active?'إيقاف':'تفعيل'}
                      </button>
                      <button onClick={()=>{setEditItem(ad);setAf({title:ad.title||'',image_url:ad.image_url||'',click_url:ad.click_url||'',position:ad.position||'top',priority:String(ad.priority||1),start_date:'',end_date:''});setAdModal(true)}} style={{background:'rgba(59,130,246,0.12)',border:'1px solid rgba(59,130,246,0.25)',color:'#3B82F6',padding:'6px 12px',borderRadius:8,cursor:'pointer',fontSize:12}}>تعديل</button>
                      <button onClick={()=>deleteAd(ad.id)} style={{background:'rgba(239,68,68,0.12)',border:'1px solid rgba(239,68,68,0.25)',color:'#EF4444',padding:'6px 12px',borderRadius:8,cursor:'pointer',fontSize:12}}>حذف</button>
                    </div>
                  </div>
                ))}
              </div>
            }
          </div>
        )}

        {/* ════ المالية ════ */}
        {tab==='finance' && (
          <div>
            <SectionHeader title="💰 التقارير المالية" sub="الإيرادات والاشتراكات"/>
            <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(200px,1fr))',gap:14,marginBottom:24}}>
              <StatCard icon="📦" label="اشتراكات نشطة" value={subs.filter(s=>s.status==='active').length} color="#10B981"/>
              <StatCard icon="💵" label="إجمالي الاشتراكات" value={subs.length} color={G}/>
              <StatCard icon="🎫" label="الكوبونات" value={coupons.length} color="#8B5CF6"/>
            </div>
            <div style={{background:CARD,border:`1px solid ${BORDER}`,borderRadius:16,overflow:'hidden',marginBottom:20}}>
              <div style={{padding:'16px 20px',borderBottom:`1px solid ${BORDER}`,fontWeight:700}}>📋 الاشتراكات الأخيرة</div>
              {subs.slice(0,10).map((s,i)=>(
                <div key={i} style={{display:'flex',justifyContent:'space-between',alignItems:'center',padding:'14px 20px',borderBottom:`1px solid ${BORDER}`}}>
                  <div>
                    <div style={{fontWeight:600,fontSize:14}}>{s.school_name||s.user_name||'—'}</div>
                    <div style={{color:'rgba(255,255,255,0.3)',fontSize:11}}>{s.plan_name||'—'} · {timeAgo(s.created_at)}</div>
                  </div>
                  <div style={{display:'flex',gap:10,alignItems:'center'}}>
                    <span style={{fontWeight:700,color:G}}>{s.amount||'—'} ريال</span>
                    {statusBadge(s.status)}
                  </div>
                </div>
              ))}
              {subs.length===0&&<div style={{textAlign:'center',padding:40,color:'rgba(255,255,255,0.3)'}}>لا توجد اشتراكات</div>}
            </div>
          </div>
        )}

        {/* ════ المتجر ════ */}
        {tab==='store' && (
          <div>
            <SectionHeader title="🛒 المتجر المركزي" sub="المنتجات والطلبات"/>
            <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(200px,1fr))',gap:14,marginBottom:24}}>
              <StatCard icon="📦" label="المنتجات" value={products.length} color={G}/>
              <StatCard icon="📋" label="الطلبات" value={orders.length} color="#10B981"/>
              <StatCard icon="⏳" label="طلبات معلقة" value={orders.filter(o=>o.status==='pending').length} color="#F59E0B"/>
            </div>
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:20}}>
              <div style={{background:CARD,border:`1px solid ${BORDER}`,borderRadius:16,overflow:'hidden'}}>
                <div style={{padding:'16px 20px',borderBottom:`1px solid ${BORDER}`,fontWeight:700}}>📦 المنتجات</div>
                {products.slice(0,8).map((p,i)=>(
                  <div key={i} style={{display:'flex',justifyContent:'space-between',alignItems:'center',padding:'12px 20px',borderBottom:`1px solid ${BORDER}`}}>
                    <div style={{fontWeight:600,fontSize:13}}>{p.name||p.name_ar}</div>
                    <span style={{color:G,fontWeight:700,fontSize:13}}>{p.price} ريال</span>
                  </div>
                ))}
                {products.length===0&&<div style={{textAlign:'center',padding:40,color:'rgba(255,255,255,0.3)'}}>لا توجد منتجات</div>}
              </div>
              <div style={{background:CARD,border:`1px solid ${BORDER}`,borderRadius:16,overflow:'hidden'}}>
                <div style={{padding:'16px 20px',borderBottom:`1px solid ${BORDER}`,fontWeight:700}}>📋 آخر الطلبات</div>
                {orders.slice(0,8).map((o,i)=>(
                  <div key={i} style={{display:'flex',justifyContent:'space-between',alignItems:'center',padding:'12px 20px',borderBottom:`1px solid ${BORDER}`}}>
                    <div style={{fontSize:13}}>{o.customer_name||'—'}</div>
                    <div style={{display:'flex',gap:8,alignItems:'center'}}>
                      <span style={{color:G,fontSize:12}}>{o.total} ريال</span>
                      {statusBadge(o.status)}
                    </div>
                  </div>
                ))}
                {orders.length===0&&<div style={{textAlign:'center',padding:40,color:'rgba(255,255,255,0.3)'}}>لا توجد طلبات</div>}
              </div>
            </div>
          </div>
        )}

        {/* ════ التكاملات ════ */}
        {tab==='integrations' && (
          <div>
            <SectionHeader title="🔌 التكاملات" sub="ربط الخدمات الخارجية بالمنصة"/>
            {integrations.length===0
              ? <EmptyState icon="🔌" msg="لا توجد تكاملات مفعلة"/>
              : (() => {
                const cats = [...new Set(integrations.map((i:any)=>i.category))];
                return cats.map(cat=>(
                  <div key={cat} style={{marginBottom:24}}>
                    <div style={{fontSize:12,fontWeight:700,color:'rgba(255,255,255,0.3)',letterSpacing:1.5,marginBottom:12}}>{cat}</div>
                    <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(220px,1fr))',gap:12}}>
                      {integrations.filter((i:any)=>i.category===cat).map((intg:any,i:number)=>(
                        <div key={i} style={{background:CARD,border:`1px solid ${intg.is_active?`${G}33`:BORDER}`,borderRadius:14,padding:18}}>
                          <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:8}}>
                            <div style={{fontWeight:700,fontSize:14}}>{intg.name}</div>
                            <span style={{background:intg.is_active?'rgba(16,185,129,0.15)':'rgba(107,114,128,0.15)',color:intg.is_active?'#10B981':'#6B7280',padding:'2px 8px',borderRadius:5,fontSize:10,fontWeight:700}}>
                              {intg.is_active?'مفعّل':'معطّل'}
                            </span>
                          </div>
                          <div style={{color:'rgba(255,255,255,0.3)',fontSize:12}}>{intg.description||'—'}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                ));
              })()
            }
          </div>
        )}

        {/* ════ التحليلات ════ */}
        {tab==='analytics' && (
          <div>
            <SectionHeader title="📈 التحليلات" sub="إحصاءات استخدام المنصة"/>
            <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(200px,1fr))',gap:14,marginBottom:24}}>
              <StatCard icon="👁" label="إجمالي الزوار" value={visitors.length} color="#3B82F6"/>
              <StatCard icon="🏫" label="المؤسسات النشطة" value={schools.filter(s=>s.status==='ACTIVE'||s.status==='active').length} color="#10B981"/>
              <StatCard icon="📋" label="الاستبيانات" value={surveys.length} color="#8B5CF6"/>
              <StatCard icon="🎯" label="العملاء المحتملون" value={leads.length} color="#F59E0B"/>
            </div>
            <div style={{background:CARD,border:`1px solid ${BORDER}`,borderRadius:16,padding:24,textAlign:'center'}}>
              <div style={{fontSize:40,marginBottom:12}}>📊</div>
              <p style={{color:'rgba(255,255,255,0.4)',fontSize:14,marginBottom:20}}>تحليلات تفصيلية متاحة قريباً</p>
              <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:12,maxWidth:500,margin:'0 auto'}}>
                {[
                  {label:'مؤسسات نشطة',value:schools.filter(s=>s.status==='ACTIVE'||s.status==='active').length,pct:'100%'},
                  {label:'معدل التحويل',value:`${leads.length?Math.round((schools.length/leads.length)*100):0}%`,pct:'—'},
                  {label:'العملاء المحتملون',value:leads.length,pct:'جديد'},
                ].map((c,i)=>(
                  <div key={i} style={{background:'rgba(255,255,255,0.04)',borderRadius:12,padding:16}}>
                    <div style={{fontSize:20,fontWeight:800,color:G}}>{c.value}</div>
                    <div style={{fontSize:11,color:'rgba(255,255,255,0.4)',marginTop:4}}>{c.label}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ════ الدعم ════ */}
        {tab==='support' && (
          <div>
            <SectionHeader title="💬 الدعم والشكاوى" sub="طلبات الدعم من المؤسسات"/>
            <div style={{background:CARD,border:`1px solid ${BORDER}`,borderRadius:16,overflow:'hidden'}}>
              <div style={{display:'grid',gridTemplateColumns:'2fr 1fr 1fr 1fr',padding:'12px 20px',background:'rgba(255,255,255,0.04)',borderBottom:`1px solid ${BORDER}`}}>
                {['الطلب','المرسل','النوع','الحالة'].map((h,i)=>(
                  <span key={i} style={{color:'rgba(255,255,255,0.3)',fontSize:11,fontWeight:700}}>{h}</span>
                ))}
              </div>
              {support.slice(0,20).map((s,i)=>(
                <div key={i} style={{display:'grid',gridTemplateColumns:'2fr 1fr 1fr 1fr',padding:'14px 20px',borderBottom:`1px solid ${BORDER}`,alignItems:'center'}}>
                  <div style={{fontWeight:600,fontSize:13}}>{s.subject||s.title||'—'}</div>
                  <div style={{color:'rgba(255,255,255,0.4)',fontSize:12}}>{s.user_name||s.name||'—'}</div>
                  <div style={{color:'rgba(255,255,255,0.4)',fontSize:12}}>{s.type||'—'}</div>
                  {statusBadge(s.status||'pending')}
                </div>
              ))}
              {support.length===0&&<div style={{textAlign:'center',padding:40,color:'rgba(255,255,255,0.3)'}}>لا توجد طلبات دعم</div>}
            </div>
          </div>
        )}

        {/* ════ المجتمع ════ */}
        {tab==='community' && (
          <div>
            <SectionHeader title="🌐 المجتمع والتواصل" sub="المنشورات والمنتديات"/>
            <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(200px,1fr))',gap:14,marginBottom:24}}>
              <StatCard icon="📝" label="المنشورات" value={posts.length} color="#3B82F6"/>
              <StatCard icon="💬" label="المنتديات" value={forums.length} color="#10B981"/>
            </div>
            <div style={{background:CARD,border:`1px solid ${BORDER}`,borderRadius:16,overflow:'hidden'}}>
              <div style={{padding:'16px 20px',borderBottom:`1px solid ${BORDER}`,fontWeight:700}}>📝 آخر المنشورات</div>
              {posts.slice(0,10).map((p,i)=>(
                <div key={i} style={{display:'flex',justifyContent:'space-between',alignItems:'center',padding:'14px 20px',borderBottom:`1px solid ${BORDER}`}}>
                  <div>
                    <div style={{fontWeight:600,fontSize:13}}>{p.content?.substring(0,60)||'—'}...</div>
                    <div style={{color:'rgba(255,255,255,0.3)',fontSize:11}}>{p.author_name||'—'} · {timeAgo(p.created_at)}</div>
                  </div>
                  <button onClick={()=>deletePost(p.id)} style={{background:'rgba(239,68,68,0.12)',border:'1px solid rgba(239,68,68,0.25)',color:'#EF4444',padding:'4px 10px',borderRadius:6,cursor:'pointer',fontSize:11}}>حذف</button>
                </div>
              ))}
              {posts.length===0&&<div style={{textAlign:'center',padding:40,color:'rgba(255,255,255,0.3)'}}>لا توجد منشورات</div>}
            </div>
          </div>
        )}

        {/* ════ الشركاء ════ */}
        {tab==='partners' && (
          <div>
            <SectionHeader title="🤝 الشركاء" sub="شركاء منصة متين"/>
            <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(220px,1fr))',gap:16}}>
              {partners.map((p,i)=>(
                <div key={i} style={{background:CARD,border:`1px solid ${BORDER}`,borderRadius:16,padding:20,textAlign:'center'}}>
                  {p.logo_url&&<img src={p.logo_url} alt="" style={{width:60,height:60,objectFit:'contain',borderRadius:12,marginBottom:12}}/>}
                  <div style={{fontWeight:700,fontSize:15,marginBottom:4}}>{p.name}</div>
                  <div style={{color:'rgba(255,255,255,0.4)',fontSize:12,marginBottom:12}}>{p.description||'—'}</div>
                  {p.website&&<a href={p.website} target="_blank" rel="noreferrer" style={{color:G,fontSize:12,textDecoration:'none'}}>🔗 الموقع</a>}
                </div>
              ))}
              {partners.length===0&&<EmptyState icon="🤝" msg="لا يوجد شركاء بعد"/>}
            </div>
          </div>
        )}

        {/* ════ الإشعارات ════ */}
        {tab==='notifications' && (
          <div>
            <SectionHeader title="🔔 الإشعارات المركزية" sub="إرسال إشعارات لجميع مستخدمي المنصة"/>
            <div style={{background:CARD,border:`1px solid ${BORDER}`,borderRadius:16,padding:28,maxWidth:560}}>
              <div style={{fontSize:16,fontWeight:700,marginBottom:20}}>📢 إشعار جماعي جديد</div>
              <NotificationForm onSend={sendNotification} showToast={showToast}/>
            </div>
          </div>
        )}

        {/* ════ الأمان ════ */}
        {tab==='security' && (
          <div>
            <SectionHeader title="🔐 الأمان والسجلات" sub="سجلات النشاط والأخطاء"/>
            <div style={{background:CARD,border:`1px solid ${BORDER}`,borderRadius:16,overflow:'hidden',marginBottom:20}}>
              <div style={{padding:'16px 20px',borderBottom:`1px solid ${BORDER}`,fontWeight:700}}>📋 سجل النشاط</div>
              {actLog.slice(0,15).map((a,i)=>(
                <div key={i} style={{display:'flex',justifyContent:'space-between',padding:'12px 20px',borderBottom:`1px solid ${BORDER}`}}>
                  <div>
                    <div style={{fontSize:13,fontWeight:600}}>{a.action||a.description||'—'}</div>
                    <div style={{color:'rgba(255,255,255,0.3)',fontSize:11}}>{a.user_name||a.ip||'—'}</div>
                  </div>
                  <span style={{color:'rgba(255,255,255,0.3)',fontSize:11}}>{timeAgo(a.created_at)}</span>
                </div>
              ))}
              {actLog.length===0&&<div style={{textAlign:'center',padding:40,color:'rgba(255,255,255,0.3)'}}>لا توجد سجلات</div>}
            </div>
          </div>
        )}

        {/* ════ النسخ الاحتياطية ════ */}
        {tab==='backup' && (
          <div>
            <SectionHeader title="💾 النسخ الاحتياطية" sub="نسخ احتياطية لقاعدة البيانات"/>
            <div style={{background:CARD,border:`1px solid ${BORDER}`,borderRadius:16,padding:28,textAlign:'center',marginBottom:20}}>
              <div style={{fontSize:52,marginBottom:16}}>💾</div>
              <p style={{color:'rgba(255,255,255,0.5)',fontSize:14,marginBottom:24}}>إنشاء نسخة احتياطية كاملة لقاعدة البيانات</p>
              <button onClick={createBackup} style={{background:`linear-gradient(135deg,${G},${G2})`,color:'#060C18',
                padding:'14px 36px',borderRadius:12,border:'none',fontWeight:800,cursor:'pointer',fontSize:15}}>
                💾 إنشاء نسخة احتياطية الآن
              </button>
            </div>
          </div>
        )}

        {/* ════ الإعدادات ════ */}
        {tab==='settings' && (
          <div>
            <SectionHeader title="⚙️ إعدادات المنصة"/>
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:20}}>
              {[
                {icon:'🏛️',title:'إعدادات عامة',desc:'اسم المنصة، الشعار، البريد'},
                {icon:'🔑',title:'Developer API',desc:'مفاتيح API للمطورين'},
                {icon:'🔗',title:'Webhooks',desc:'إدارة الـ Webhooks'},
                {icon:'🛡️',title:'الأمان',desc:'كلمات المرور وصلاحيات الوصول'},
                {icon:'📧',title:'إعدادات البريد',desc:'SMTP وقوالب الإيميلات'},
                {icon:'💳',title:'إعدادات الدفع',desc:'بوابات الدفع وAPI Keys'},
              ].map((s,i)=>(
                <div key={i} style={{background:CARD,border:`1px solid ${BORDER}`,borderRadius:14,padding:24,
                  cursor:'pointer',transition:'all 0.2s'}}
                  onMouseEnter={e=>(e.currentTarget.style.border=`1px solid ${G}44`)}
                  onMouseLeave={e=>(e.currentTarget.style.border=`1px solid ${BORDER}`)}>
                  <div style={{fontSize:32,marginBottom:12}}>{s.icon}</div>
                  <div style={{fontWeight:700,fontSize:15,marginBottom:4}}>{s.title}</div>
                  <div style={{color:'rgba(255,255,255,0.4)',fontSize:13}}>{s.desc}</div>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>

      {/* ══════════════════════════════════
           MODALS
         ══════════════════════════════════ */}

      {schoolModal && (
        <Modal title={editItem?'✏️ تعديل مؤسسة':'🏫 إضافة مؤسسة جديدة'} onClose={()=>{setSchoolModal(false);setEditItem(null)}}>
          <Input label="اسم المؤسسة *" value={sf.name_ar} onChange={(v:string)=>setSf({...sf,name_ar:v})} placeholder="مثال: مدرسة النور"/>
          <Input label="البريد الإلكتروني" value={sf.email} onChange={(v:string)=>setSf({...sf,email:v})} type="email"/>
          <Input label="رقم الهاتف" value={sf.phone} onChange={(v:string)=>setSf({...sf,phone:v})}/>
          <Input label="المدينة" value={sf.city} onChange={(v:string)=>setSf({...sf,city:v})}/>
          {editItem && (
            <div style={{marginBottom:14}}>
              <label style={{color:'rgba(255,255,255,0.5)',fontSize:12,fontWeight:600,display:'block',marginBottom:6}}>الحالة</label>
              <select value={sf.status} onChange={e=>setSf({...sf,status:e.target.value})}
                style={{width:'100%',background:'rgba(255,255,255,0.05)',border:`1px solid ${BORDER}`,borderRadius:10,padding:'10px 14px',color:'white',fontSize:13,outline:'none'}}>
                <option value="TRIAL">تجريبي</option>
                <option value="ACTIVE">نشط</option>
                <option value="SUSPENDED">موقوف</option>
              </select>
            </div>
          )}
          <SaveBtn label={editItem?'حفظ التعديلات':'إضافة المؤسسة'} onClick={saveSchool}/>
        </Modal>
      )}

      {adModal && (
        <Modal title={editItem?'✏️ تعديل الإعلان':'📢 إعلان جديد'} onClose={()=>{setAdModal(false);setEditItem(null)}}>
          <Input label="عنوان الإعلان *" value={af.title} onChange={(v:string)=>setAf({...af,title:v})}/>
          <Input label="رابط الصورة" value={af.image_url} onChange={(v:string)=>setAf({...af,image_url:v})} type="url" placeholder="https://..."/>
          <Input label="رابط النقر" value={af.click_url} onChange={(v:string)=>setAf({...af,click_url:v})} type="url" placeholder="https://..."/>
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
            <div style={{marginBottom:14}}>
              <label style={{color:'rgba(255,255,255,0.5)',fontSize:12,fontWeight:600,display:'block',marginBottom:6}}>الموضع</label>
              <select value={af.position} onChange={e=>setAf({...af,position:e.target.value})}
                style={{width:'100%',background:'rgba(255,255,255,0.05)',border:`1px solid ${BORDER}`,borderRadius:10,padding:'10px 14px',color:'white',fontSize:13,outline:'none'}}>
                <option value="top">أعلى الصفحة</option>
                <option value="bottom">أسفل الصفحة</option>
                <option value="sidebar">الشريط الجانبي</option>
                <option value="popup">نافذة منبثقة</option>
                <option value="all">جميع المواضع</option>
              </select>
            </div>
            <Input label="الأولوية" value={af.priority} onChange={(v:string)=>setAf({...af,priority:v})} type="number"/>
          </div>
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
            <Input label="تاريخ البداية" value={af.start_date} onChange={(v:string)=>setAf({...af,start_date:v})} type="date"/>
            <Input label="تاريخ الانتهاء" value={af.end_date} onChange={(v:string)=>setAf({...af,end_date:v})} type="date"/>
          </div>
          <SaveBtn label={editItem?'حفظ التعديلات':'نشر الإعلان في جميع المدارس'} onClick={saveAd}/>
        </Modal>
      )}

      {planModal && (
        <Modal title={editItem?'✏️ تعديل الباقة':'📦 باقة جديدة'} onClose={()=>{setPlanModal(false);setEditItem(null)}}>
          <Input label="اسم الباقة بالعربي *" value={pf.name_ar} onChange={(v:string)=>setPf({...pf,name_ar:v})} placeholder="الباقة الذهبية"/>
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
            <Input label="السعر الشهري (ريال)" value={pf.price_monthly} onChange={(v:string)=>setPf({...pf,price_monthly:v})} type="number"/>
            <Input label="السعر السنوي (ريال)" value={pf.price_yearly} onChange={(v:string)=>setPf({...pf,price_yearly:v})} type="number"/>
          </div>
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
            <Input label="أقصى عدد طلاب" value={pf.max_students} onChange={(v:string)=>setPf({...pf,max_students:v})} type="number"/>
            <Input label="أقصى عدد معلمين" value={pf.max_teachers} onChange={(v:string)=>setPf({...pf,max_teachers:v})} type="number"/>
          </div>
          <div style={{marginBottom:14}}>
            <label style={{color:'rgba(255,255,255,0.5)',fontSize:12,fontWeight:600,display:'block',marginBottom:6}}>المميزات (سطر لكل ميزة)</label>
            <textarea value={pf.features} onChange={e=>setPf({...pf,features:e.target.value})} rows={4}
              placeholder={'بنك أسئلة AI\nمراقبة اختبارات\nتقارير تفصيلية'}
              style={{width:'100%',background:'rgba(255,255,255,0.05)',border:`1px solid ${BORDER}`,borderRadius:10,
                padding:'10px 14px',color:'white',fontSize:13,outline:'none',resize:'vertical',boxSizing:'border-box'}}/>
          </div>
          <SaveBtn label={editItem?'حفظ التعديلات':'إضافة الباقة'} onClick={savePlan}/>
        </Modal>
      )}

    </div>
  );
}

// ── مكون الإشعارات ──────────────────────────────────────────────
function NotificationForm({onSend, showToast}:any) {
  const [title, setTitle] = useState('');
  const [body, setBody]   = useState('');
  const send = async () => {
    if(!title||!body){showToast('العنوان والمحتوى مطلوبان',false);return;}
    await onSend(title,body);
    setTitle(''); setBody('');
  };
  return (
    <div>
      <Input label="عنوان الإشعار *" value={title} onChange={setTitle} placeholder="مثال: تحديث مهم"/>
      <div style={{marginBottom:14}}>
        <label style={{color:'rgba(255,255,255,0.5)',fontSize:12,fontWeight:600,display:'block',marginBottom:6}}>محتوى الإشعار *</label>
        <textarea value={body} onChange={e=>setBody(e.target.value)} rows={4} placeholder="اكتب محتوى الإشعار هنا..."
          style={{width:'100%',background:'rgba(255,255,255,0.05)',border:`1px solid rgba(255,255,255,0.07)`,
            borderRadius:10,padding:'10px 14px',color:'white',fontSize:13,outline:'none',resize:'vertical',boxSizing:'border-box'}}/>
      </div>
      <div style={{background:'rgba(245,158,11,0.08)',border:'1px solid rgba(245,158,11,0.2)',borderRadius:10,padding:'12px 16px',marginBottom:16}}>
        <p style={{color:'rgba(245,158,11,0.8)',fontSize:12,margin:0}}>⚠️ سيتم إرسال هذا الإشعار لجميع مستخدمي المنصة</p>
      </div>
      <button onClick={send} style={{width:'100%',background:'linear-gradient(135deg,#C9A227,#E8C547)',color:'#060C18',
        padding:'13px',borderRadius:10,border:'none',fontWeight:800,cursor:'pointer',fontSize:14}}>
        🔔 إرسال الإشعار لجميع المستخدمين
      </button>
    </div>
  );
}
