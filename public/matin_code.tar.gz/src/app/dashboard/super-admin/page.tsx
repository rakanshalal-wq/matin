'use client';
import { useState, useEffect, useCallback } from 'react';
import Link from 'next/link';

const getHeaders = (): Record<string, string> => {
  try {
    const token = localStorage.getItem('matin_token');
    if (token) return { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token };
    const u = JSON.parse(localStorage.getItem('matin_user') || '{}');
    return { 'Content-Type': 'application/json', 'x-user-id': String(u.id || '') };
  } catch { return { 'Content-Type': 'application/json' }; }
};

// ==========================================
// مكونات مساعدة
// ==========================================
const Card = ({ children, style = {} }: { children: React.ReactNode; style?: React.CSSProperties }) => (
  <div style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 14, padding: 20, ...style }}>
    {children}
  </div>
);

const StatCard = ({ label, value, icon, color, href, trend }: { label: string; value: number | string; icon: string; color: string; href?: string; trend?: string }) => {
  const content = (
    <div style={{ background: 'rgba(255,255,255,0.03)', border: `1px solid ${color}25`, borderRadius: 14, padding: 20, cursor: href ? 'pointer' : 'default', transition: 'all 0.3s', position: 'relative' as const, overflow: 'hidden' }}>
      <div style={{ position: 'absolute', top: -10, left: -10, width: 60, height: 60, background: `${color}08`, borderRadius: '50%' }} />
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', position: 'relative' as const }}>
        <div>
          <div style={{ color: 'rgba(255,255,255,0.5)', fontSize: 12, marginBottom: 8, fontWeight: 500 }}>{label}</div>
          <div style={{ color: 'white', fontSize: 30, fontWeight: 800 }}>{typeof value === 'number' ? value.toLocaleString('ar-SA') : value}</div>
          {trend && <div style={{ color: trend.startsWith('+') ? '#10B981' : '#EF4444', fontSize: 11, marginTop: 6, fontWeight: 600 }}>{trend}</div>}
        </div>
        <div style={{ width: 48, height: 48, background: `${color}15`, borderRadius: 12, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 24 }}>{icon}</div>
      </div>
    </div>
  );
  if (href) return <Link href={href} style={{ textDecoration: 'none' }}>{content}</Link>;
  return content;
};

const SectionTitle = ({ icon, title, action }: { icon: string; title: string; action?: React.ReactNode }) => (
  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16, marginTop: 28 }}>
    <h2 style={{ color: 'white', fontSize: 18, fontWeight: 700, margin: 0 }}>{icon} {title}</h2>
    {action}
  </div>
);

const Badge = ({ text, color }: { text: string; color: string }) => (
  <span style={{ padding: '3px 10px', borderRadius: 20, fontSize: 11, fontWeight: 600, background: `${color}15`, color }}>{text}</span>
);

const roleLabels: Record<string, { label: string; color: string }> = {
  super_admin: { label: 'مالك المنصة', color: '#C9A227' },
  owner: { label: 'مالك مدرسة', color: '#8B5CF6' },
  admin: { label: 'مدير', color: '#3B82F6' },
  teacher: { label: 'معلم', color: '#10B981' },
  student: { label: 'طالب', color: '#06B6D4' },
  parent: { label: 'ولي أمر', color: '#F59E0B' },
};

const statusLabels: Record<string, { label: string; color: string }> = {
  active: { label: 'نشط', color: '#10B981' },
  pending: { label: 'معلق', color: '#F59E0B' },
  suspended: { label: 'موقوف', color: '#EF4444' },
  rejected: { label: 'مرفوض', color: '#EF4444' },
};

// ==========================================
// الصفحة الرئيسية
// ==========================================
export default function SuperAdminDashboard() {
  const [user, setUser] = useState<any>(null);
  const [stats, setStats] = useState<any>({});
  const [schools, setSchools] = useState<any[]>([]);
  const [users, setUsers] = useState<any[]>([]);
  const [pendingUsers, setPendingUsers] = useState<any[]>([]);
  const [recentActivity, setRecentActivity] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<string>('overview');
  const [actionLoading, setActionLoading] = useState<string>('');
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');

  useEffect(() => {
    const u = JSON.parse(localStorage.getItem('matin_user') || '{}');
    if (!u.id || u.role !== 'super_admin') {
      window.location.href = '/dashboard';
      return;
    }
    setUser(u);
    loadAll();
  }, []);

  const loadAll = useCallback(async () => {
    setLoading(true);
    try {
      const [statsRes, schoolsRes, usersRes, activityRes] = await Promise.all([
        fetch('/api/dashboard-stats', { headers: getHeaders() }),
        fetch('/api/schools', { headers: getHeaders() }),
        fetch('/api/auth', { method: 'POST', headers: getHeaders(), body: JSON.stringify({ action: 'get_users', role_filter: 'all', status_filter: 'all' }) }),
        fetch('/api/activity-log', { headers: getHeaders() }).catch(() => null),
      ]);
      const [statsData, schoolsData, usersData] = await Promise.all([
        statsRes.json(), schoolsRes.json(), usersRes.json()
      ]);
      const activityData = activityRes ? await activityRes.json().catch(() => []) : [];
      
      setStats(statsData || {});
      setSchools(Array.isArray(schoolsData) ? schoolsData : []);
      const allUsers = Array.isArray(usersData) ? usersData : [];
      setUsers(allUsers);
      setPendingUsers(allUsers.filter((u: any) => u.status === 'pending'));
      setRecentActivity(Array.isArray(activityData) ? activityData.slice(0, 10) : []);
    } catch (e) {
      console.error('Error loading data:', e);
    } finally { setLoading(false); }
  }, []);

  const handleUserAction = async (userId: number, action: string) => {
    setActionLoading(`${userId}-${action}`);
    try {
      await fetch('/api/auth', {
        method: 'POST',
        headers: getHeaders(),
        body: JSON.stringify({ action, user_id: userId }),
      });
      await loadAll();
    } catch (e) {
      console.error('Action error:', e);
    } finally { setActionLoading(''); }
  };

  if (loading) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '60vh' }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{ width: 70, height: 70, background: 'linear-gradient(135deg, #C9A227 0%, #D4B03D 100%)', borderRadius: 18, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 32, margin: '0 auto 20px', animation: 'pulse 2s infinite' }}>👑</div>
          <div style={{ color: '#C9A227', fontWeight: 700, fontSize: 18 }}>جاري تحميل لوحة مالك المنصة...</div>
          <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: 13, marginTop: 8 }}>يتم جلب البيانات من جميع الأنظمة</div>
        </div>
      </div>
    );
  }

  const tabs = [
    { id: 'overview', label: 'نظرة عامة', icon: '📊' },
    { id: 'pending', label: `طلبات معلقة (${pendingUsers.length})`, icon: '⏳' },
    { id: 'schools', label: `المدارس (${schools.length})`, icon: '🏫' },
    { id: 'users', label: `المستخدمون (${users.length})`, icon: '👥' },
    { id: 'finance', label: 'المالية', icon: '💰' },
    { id: 'system', label: 'النظام', icon: '⚙️' },
  ];

  const inputStyle: React.CSSProperties = { width: '100%', background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 8, padding: '10px 14px', color: 'white', fontSize: 14, outline: 'none', fontFamily: 'inherit' };

  // فلترة المستخدمين
  const filteredUsers = users.filter(u => {
    const term = searchTerm.toLowerCase();
    const matchSearch = !term || u.name?.toLowerCase().includes(term) || u.email?.toLowerCase().includes(term) || u.phone?.includes(searchTerm);
    const matchRole = roleFilter === 'all' || u.role === roleFilter;
    const matchStatus = statusFilter === 'all' || u.status === statusFilter;
    return matchSearch && matchRole && matchStatus;
  });

  return (
    <div>
      {/* Header */}
      <div style={{ marginBottom: 24, display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 16 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <div style={{ width: 52, height: 52, background: 'linear-gradient(135deg, #C9A227, #D4B03D)', borderRadius: 14, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 26, boxShadow: '0 4px 15px rgba(201,162,39,0.3)' }}>👑</div>
          <div>
            <h1 style={{ fontSize: 24, fontWeight: 800, color: 'white', margin: 0 }}>مرحباً {user?.name || 'مالك المنصة'}</h1>
            <p style={{ color: 'rgba(255,255,255,0.5)', fontSize: 13, margin: '4px 0 0' }}>لوحة التحكم الرئيسية لمنصة متين التعليمية</p>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button onClick={() => loadAll()} style={{ padding: '10px 18px', background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 10, color: 'white', cursor: 'pointer', fontSize: 13, fontFamily: 'inherit' }}>🔄 تحديث</button>
        </div>
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: 6, marginBottom: 24, flexWrap: 'wrap', background: 'rgba(255,255,255,0.02)', borderRadius: 12, padding: 4 }}>
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            style={{
              padding: '10px 18px', borderRadius: 10, border: 'none', cursor: 'pointer', fontFamily: 'inherit', fontSize: 13, fontWeight: 600, transition: 'all 0.2s',
              background: activeTab === tab.id ? 'linear-gradient(135deg, #C9A227, #D4B03D)' : 'transparent',
              color: activeTab === tab.id ? '#0D1B2A' : 'rgba(255,255,255,0.6)',
            }}
          >
            {tab.icon} {tab.label}
          </button>
        ))}
      </div>

      {/* ============================================ */}
      {/* تبويب: نظرة عامة */}
      {/* ============================================ */}
      {activeTab === 'overview' && (
        <div>
          {/* بطاقات الإحصاءات الرئيسية */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 14, marginBottom: 24 }}>
            <StatCard label="المدارس المشتركة" value={stats.schools || 0} icon="🏫" color="#C9A227" href="/dashboard/schools" />
            <StatCard label="ملاك المدارس" value={stats.owners || 0} icon="👑" color="#8B5CF6" href="/dashboard/users" />
            <StatCard label="إجمالي الطلاب" value={stats.students || 0} icon="🎓" color="#3B82F6" href="/dashboard/students" />
            <StatCard label="إجمالي المعلمين" value={stats.teachers || 0} icon="👨‍🏫" color="#10B981" href="/dashboard/teachers" />
            <StatCard label="مستخدمين نشطين" value={stats.active_users || 0} icon="✅" color="#06B6D4" />
            <StatCard label="طلبات معلقة" value={pendingUsers.length} icon="⏳" color="#EF4444" href="/dashboard/super-admin" />
          </div>

          {/* تنبيهات مهمة */}
          {pendingUsers.length > 0 && (
            <div style={{ background: 'rgba(245,158,11,0.08)', border: '1px solid rgba(245,158,11,0.25)', borderRadius: 12, padding: '14px 20px', marginBottom: 20, display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 12 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <span style={{ fontSize: 20 }}>⚠️</span>
                <div>
                  <div style={{ color: '#F59E0B', fontWeight: 700, fontSize: 14 }}>لديك {pendingUsers.length} طلب تسجيل معلق</div>
                  <div style={{ color: 'rgba(255,255,255,0.5)', fontSize: 12, marginTop: 2 }}>يرجى مراجعة الطلبات والموافقة عليها أو رفضها</div>
                </div>
              </div>
              <button onClick={() => setActiveTab('pending')} style={{ padding: '8px 18px', background: '#F59E0B', color: '#0D1B2A', border: 'none', borderRadius: 8, cursor: 'pointer', fontWeight: 700, fontSize: 13, fontFamily: 'inherit' }}>مراجعة الطلبات</button>
            </div>
          )}

          {/* توزيع المستخدمين */}
          <SectionTitle icon="👥" title="توزيع المستخدمين" />
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', gap: 12, marginBottom: 24 }}>
            {Object.entries(roleLabels).map(([role, info]) => {
              const count = users.filter(u => u.role === role).length;
              return (
                <Card key={role} style={{ textAlign: 'center', borderColor: `${info.color}20` }}>
                  <div style={{ color: info.color, fontSize: 26, fontWeight: 800 }}>{count}</div>
                  <div style={{ color: 'rgba(255,255,255,0.5)', fontSize: 12, marginTop: 4 }}>{info.label}</div>
                </Card>
              );
            })}
          </div>

          {/* إجراءات سريعة */}
          <SectionTitle icon="⚡" title="إجراءات سريعة" />
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', gap: 10, marginBottom: 24 }}>
            {[
              { label: 'إضافة مدرسة', icon: '🏫', href: '/dashboard/schools', color: '#C9A227' },
              { label: 'إدارة المستخدمين', icon: '👥', href: '/dashboard/users', color: '#3B82F6' },
              { label: 'إدارة الطاقم', icon: '👨‍🏫', href: '/dashboard/staff', color: '#10B981' },
              { label: 'بنك الأسئلة', icon: '❓', href: '/dashboard/question-bank', color: '#8B5CF6' },
              { label: 'الباقات', icon: '💎', href: '/dashboard/subscriptions', color: '#F59E0B' },
              { label: 'التقارير', icon: '📈', href: '/dashboard/reports', color: '#06B6D4' },
              { label: 'الإعدادات', icon: '⚙️', href: '/dashboard/settings', color: '#6B7280' },
              { label: 'الدعم الفني', icon: '🎧', href: '/dashboard/support', color: '#EF4444' },
            ].map((a, i) => (
              <Link key={i} href={a.href} style={{ textDecoration: 'none' }}>
                <div style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 12, padding: '14px 10px', textAlign: 'center', cursor: 'pointer', transition: 'all 0.2s' }}>
                  <div style={{ fontSize: 26, marginBottom: 6 }}>{a.icon}</div>
                  <div style={{ color: 'rgba(255,255,255,0.7)', fontSize: 12, fontWeight: 600 }}>{a.label}</div>
                </div>
              </Link>
            ))}
          </div>

          {/* آخر المدارس المسجلة */}
          {schools.length > 0 && (
            <>
              <SectionTitle icon="🏫" title="آخر المدارس المسجلة" action={<Link href="/dashboard/schools" style={{ color: '#C9A227', fontSize: 13, textDecoration: 'none' }}>عرض الكل ←</Link>} />
              <div style={{ display: 'grid', gap: 8 }}>
                {schools.slice(0, 5).map((school: any) => (
                  <Card key={school.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 12, padding: '14px 20px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                      <div style={{ width: 42, height: 42, background: 'rgba(201,162,39,0.1)', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20 }}>🏫</div>
                      <div>
                        <div style={{ color: 'white', fontWeight: 700, fontSize: 15 }}>{school.name_ar || school.name}</div>
                        <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: 12, marginTop: 2 }}>
                          {school.city && <span>📍 {school.city}</span>}
                          {school.email && <span style={{ marginRight: 12 }}>✉️ {school.email}</span>}
                        </div>
                      </div>
                    </div>
                    <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                      <Badge text={school.status === 'ACTIVE' ? 'نشط' : school.status === 'TRIAL' ? 'تجريبي' : school.status || 'غير محدد'} color={school.status === 'ACTIVE' ? '#10B981' : school.status === 'TRIAL' ? '#F59E0B' : '#EF4444'} />
                    </div>
                  </Card>
                ))}
              </div>
            </>
          )}
        </div>
      )}

      {/* ============================================ */}
      {/* تبويب: طلبات معلقة */}
      {/* ============================================ */}
      {activeTab === 'pending' && (
        <div>
          <SectionTitle icon="⏳" title={`طلبات التسجيل المعلقة (${pendingUsers.length})`} />
          {pendingUsers.length === 0 ? (
            <Card style={{ textAlign: 'center', padding: 60 }}>
              <div style={{ fontSize: 48, marginBottom: 16 }}>✅</div>
              <div style={{ color: 'white', fontSize: 18, fontWeight: 700, marginBottom: 8 }}>لا توجد طلبات معلقة</div>
              <div style={{ color: 'rgba(255,255,255,0.5)', fontSize: 14 }}>جميع الطلبات تمت مراجعتها</div>
            </Card>
          ) : (
            <div style={{ display: 'grid', gap: 10 }}>
              {pendingUsers.map((u: any) => (
                <Card key={u.id} style={{ padding: '16px 20px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 12 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                      <div style={{ width: 44, height: 44, background: 'rgba(245,158,11,0.1)', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20 }}>
                        {u.role === 'owner' ? '👑' : u.role === 'teacher' ? '👨‍🏫' : u.role === 'student' ? '🎓' : '👤'}
                      </div>
                      <div>
                        <div style={{ color: 'white', fontWeight: 700, fontSize: 15 }}>{u.name}</div>
                        <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: 12, marginTop: 2 }}>
                          {u.email} {u.phone && <span style={{ marginRight: 8 }}>| {u.phone}</span>}
                        </div>
                        <div style={{ display: 'flex', gap: 6, marginTop: 6 }}>
                          <Badge text={roleLabels[u.role]?.label || u.role} color={roleLabels[u.role]?.color || '#6B7280'} />
                          {u.city && <Badge text={u.city} color="#6B7280" />}
                          {u.package && u.package !== 'basic' && <Badge text={u.package === 'advanced' ? 'متقدم' : 'مؤسسي'} color="#8B5CF6" />}
                        </div>
                      </div>
                    </div>
                    <div style={{ display: 'flex', gap: 8 }}>
                      <button
                        onClick={() => handleUserAction(u.id, 'approve')}
                        disabled={actionLoading === `${u.id}-approve`}
                        style={{ padding: '8px 20px', background: '#10B981', color: 'white', border: 'none', borderRadius: 8, cursor: 'pointer', fontWeight: 700, fontSize: 13, fontFamily: 'inherit', opacity: actionLoading === `${u.id}-approve` ? 0.6 : 1 }}
                      >
                        {actionLoading === `${u.id}-approve` ? '⏳' : '✅'} قبول
                      </button>
                      <button
                        onClick={() => { if (confirm('هل أنت متأكد من رفض هذا الطلب؟')) handleUserAction(u.id, 'reject'); }}
                        disabled={actionLoading === `${u.id}-reject`}
                        style={{ padding: '8px 20px', background: 'rgba(239,68,68,0.1)', color: '#EF4444', border: '1px solid rgba(239,68,68,0.3)', borderRadius: 8, cursor: 'pointer', fontWeight: 700, fontSize: 13, fontFamily: 'inherit', opacity: actionLoading === `${u.id}-reject` ? 0.6 : 1 }}
                      >
                        {actionLoading === `${u.id}-reject` ? '⏳' : '❌'} رفض
                      </button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ============================================ */}
      {/* تبويب: المدارس */}
      {/* ============================================ */}
      {activeTab === 'schools' && (
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20, flexWrap: 'wrap', gap: 12 }}>
            <h2 style={{ color: 'white', fontSize: 20, fontWeight: 700, margin: 0 }}>🏫 المدارس المشتركة ({schools.length})</h2>
            <Link href="/dashboard/schools">
              <button style={{ padding: '10px 20px', background: 'linear-gradient(135deg, #C9A227, #D4B03D)', color: '#0D1B2A', border: 'none', borderRadius: 10, cursor: 'pointer', fontWeight: 700, fontFamily: 'inherit', fontSize: 13 }}>+ إضافة مدرسة</button>
            </Link>
          </div>

          {/* إحصائيات المدارس */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: 12, marginBottom: 20 }}>
            <StatCard label="إجمالي المدارس" value={schools.length} icon="🏫" color="#C9A227" />
            <StatCard label="مدارس نشطة" value={schools.filter(s => s.status === 'ACTIVE').length} icon="✅" color="#10B981" />
            <StatCard label="فترة تجريبية" value={schools.filter(s => s.status === 'TRIAL').length} icon="⏳" color="#F59E0B" />
            <StatCard label="معلقة" value={schools.filter(s => !['ACTIVE', 'TRIAL'].includes(s.status)).length} icon="⚠️" color="#EF4444" />
          </div>

          {/* قائمة المدارس */}
          <div style={{ display: 'grid', gap: 10 }}>
            {schools.length === 0 ? (
              <Card style={{ textAlign: 'center', padding: 60 }}>
                <div style={{ fontSize: 48, marginBottom: 16 }}>🏫</div>
                <div style={{ color: 'white', fontSize: 18, fontWeight: 700, marginBottom: 8 }}>لا توجد مدارس مسجلة بعد</div>
                <Link href="/dashboard/schools"><button style={{ marginTop: 12, padding: '10px 24px', background: '#C9A227', color: '#0D1B2A', border: 'none', borderRadius: 10, cursor: 'pointer', fontWeight: 700, fontFamily: 'inherit' }}>+ إضافة أول مدرسة</button></Link>
              </Card>
            ) : schools.map((school: any) => (
              <Card key={school.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 12, padding: '14px 20px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                  <div style={{ width: 44, height: 44, background: 'rgba(201,162,39,0.1)', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20 }}>🏫</div>
                  <div>
                    <div style={{ color: 'white', fontWeight: 700, fontSize: 15 }}>{school.name_ar || school.name}</div>
                    <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: 12, marginTop: 2, display: 'flex', gap: 12, flexWrap: 'wrap' }}>
                      {school.city && <span>📍 {school.city}</span>}
                      {school.email && <span>✉️ {school.email}</span>}
                      {school.phone && <span>📞 {school.phone}</span>}
                    </div>
                  </div>
                </div>
                <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                  <Badge text={school.status === 'ACTIVE' ? 'نشط' : school.status === 'TRIAL' ? 'تجريبي' : school.status || 'غير محدد'} color={school.status === 'ACTIVE' ? '#10B981' : school.status === 'TRIAL' ? '#F59E0B' : '#EF4444'} />
                  <Link href="/dashboard/schools">
                    <button style={{ padding: '6px 14px', background: 'rgba(201,162,39,0.1)', color: '#C9A227', border: '1px solid rgba(201,162,39,0.3)', borderRadius: 8, cursor: 'pointer', fontSize: 12, fontFamily: 'inherit' }}>تفاصيل</button>
                  </Link>
                </div>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* ============================================ */}
      {/* تبويب: المستخدمون */}
      {/* ============================================ */}
      {activeTab === 'users' && (
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20, flexWrap: 'wrap', gap: 12 }}>
            <h2 style={{ color: 'white', fontSize: 20, fontWeight: 700, margin: 0 }}>👥 جميع المستخدمين ({users.length})</h2>
            <Link href="/dashboard/users">
              <button style={{ padding: '10px 20px', background: 'linear-gradient(135deg, #C9A227, #D4B03D)', color: '#0D1B2A', border: 'none', borderRadius: 10, cursor: 'pointer', fontWeight: 700, fontFamily: 'inherit', fontSize: 13 }}>إدارة المستخدمين</button>
            </Link>
          </div>

          {/* توزيع الأدوار */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(130px, 1fr))', gap: 10, marginBottom: 20 }}>
            {Object.entries(roleLabels).map(([role, info]) => {
              const count = users.filter(u => u.role === role).length;
              return (
                <Card key={role} style={{ textAlign: 'center', borderColor: `${info.color}20`, padding: 14, cursor: 'pointer' }} >
                  <div style={{ color: info.color, fontSize: 24, fontWeight: 800 }}>{count}</div>
                  <div style={{ color: 'rgba(255,255,255,0.5)', fontSize: 11, marginTop: 4 }}>{info.label}</div>
                </Card>
              );
            })}
          </div>

          {/* فلاتر البحث */}
          <Card style={{ marginBottom: 16, padding: 16 }}>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 12 }}>
              <input type="text" placeholder="🔍 بحث بالاسم أو الإيميل أو الجوال..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} style={inputStyle} />
              <select value={roleFilter} onChange={(e) => setRoleFilter(e.target.value)} style={{ ...inputStyle, appearance: 'auto' as any }}>
                <option value="all">جميع الأدوار</option>
                {Object.entries(roleLabels).map(([role, info]) => (
                  <option key={role} value={role}>{info.label}</option>
                ))}
              </select>
              <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} style={{ ...inputStyle, appearance: 'auto' as any }}>
                <option value="all">جميع الحالات</option>
                {Object.entries(statusLabels).map(([status, info]) => (
                  <option key={status} value={status}>{info.label}</option>
                ))}
              </select>
            </div>
          </Card>

          {/* جدول المستخدمين */}
          <Card style={{ overflow: 'hidden', padding: 0 }}>
            {filteredUsers.length === 0 ? (
              <div style={{ padding: 40, textAlign: 'center', color: 'rgba(255,255,255,0.5)' }}>لا يوجد مستخدمين مطابقين للبحث</div>
            ) : (
              <div style={{ overflowX: 'auto' }}>
                <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: 700 }}>
                  <thead>
                    <tr style={{ background: 'rgba(201,162,39,0.08)' }}>
                      <th style={{ padding: '12px 16px', textAlign: 'right', color: '#C9A227', fontSize: 13, fontWeight: 700 }}>المستخدم</th>
                      <th style={{ padding: '12px 16px', textAlign: 'center', color: '#C9A227', fontSize: 13, fontWeight: 700 }}>الدور</th>
                      <th style={{ padding: '12px 16px', textAlign: 'center', color: '#C9A227', fontSize: 13, fontWeight: 700 }}>الحالة</th>
                      <th style={{ padding: '12px 16px', textAlign: 'center', color: '#C9A227', fontSize: 13, fontWeight: 700 }}>الجوال</th>
                      <th style={{ padding: '12px 16px', textAlign: 'center', color: '#C9A227', fontSize: 13, fontWeight: 700 }}>إجراءات</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredUsers.slice(0, 50).map((u: any) => (
                      <tr key={u.id} style={{ borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                        <td style={{ padding: '12px 16px' }}>
                          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                            <div style={{ width: 36, height: 36, background: `${roleLabels[u.role]?.color || '#6B7280'}15`, borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16 }}>
                              {u.role === 'super_admin' ? '👑' : u.role === 'owner' ? '🏫' : u.role === 'admin' ? '🔧' : u.role === 'teacher' ? '👨‍🏫' : u.role === 'student' ? '🎓' : '👤'}
                            </div>
                            <div>
                              <div style={{ color: 'white', fontWeight: 600, fontSize: 14 }}>{u.name}</div>
                              <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: 11 }}>{u.email}</div>
                            </div>
                          </div>
                        </td>
                        <td style={{ padding: '12px 16px', textAlign: 'center' }}>
                          <Badge text={roleLabels[u.role]?.label || u.role} color={roleLabels[u.role]?.color || '#6B7280'} />
                        </td>
                        <td style={{ padding: '12px 16px', textAlign: 'center' }}>
                          <Badge text={statusLabels[u.status]?.label || u.status || 'نشط'} color={statusLabels[u.status]?.color || '#10B981'} />
                        </td>
                        <td style={{ padding: '12px 16px', textAlign: 'center', color: 'rgba(255,255,255,0.6)', fontSize: 13 }}>{u.phone || '—'}</td>
                        <td style={{ padding: '12px 16px', textAlign: 'center' }}>
                          <div style={{ display: 'flex', gap: 6, justifyContent: 'center' }}>
                            {u.status === 'pending' && (
                              <>
                                <button onClick={() => handleUserAction(u.id, 'approve')} style={{ padding: '4px 12px', background: 'rgba(16,185,129,0.1)', color: '#10B981', border: '1px solid rgba(16,185,129,0.3)', borderRadius: 6, cursor: 'pointer', fontSize: 11, fontFamily: 'inherit' }}>✅ قبول</button>
                                <button onClick={() => handleUserAction(u.id, 'reject')} style={{ padding: '4px 12px', background: 'rgba(239,68,68,0.1)', color: '#EF4444', border: '1px solid rgba(239,68,68,0.3)', borderRadius: 6, cursor: 'pointer', fontSize: 11, fontFamily: 'inherit' }}>❌ رفض</button>
                              </>
                            )}
                            {u.status === 'active' && u.role !== 'super_admin' && (
                              <button onClick={() => handleUserAction(u.id, 'toggle_status')} style={{ padding: '4px 12px', background: 'rgba(239,68,68,0.1)', color: '#EF4444', border: '1px solid rgba(239,68,68,0.3)', borderRadius: 6, cursor: 'pointer', fontSize: 11, fontFamily: 'inherit' }}>إيقاف</button>
                            )}
                            {u.status === 'suspended' && (
                              <button onClick={() => handleUserAction(u.id, 'approve')} style={{ padding: '4px 12px', background: 'rgba(16,185,129,0.1)', color: '#10B981', border: '1px solid rgba(16,185,129,0.3)', borderRadius: 6, cursor: 'pointer', fontSize: 11, fontFamily: 'inherit' }}>تفعيل</button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
            {filteredUsers.length > 50 && (
              <div style={{ padding: 12, textAlign: 'center', borderTop: '1px solid rgba(255,255,255,0.06)' }}>
                <Link href="/dashboard/users" style={{ color: '#C9A227', fontSize: 13, textDecoration: 'none' }}>عرض باقي المستخدمين ({filteredUsers.length - 50}) ←</Link>
              </div>
            )}
          </Card>
        </div>
      )}

      {/* ============================================ */}
      {/* تبويب: المالية */}
      {/* ============================================ */}
      {activeTab === 'finance' && (
        <div>
          <SectionTitle icon="💰" title="النظرة المالية العامة" />
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 14, marginBottom: 24 }}>
            <StatCard label="إجمالي الإيرادات" value="—" icon="💰" color="#10B981" />
            <StatCard label="اشتراكات نشطة" value={schools.filter(s => s.status === 'ACTIVE').length} icon="📋" color="#C9A227" />
            <StatCard label="اشتراكات تجريبية" value={schools.filter(s => s.status === 'TRIAL').length} icon="⏳" color="#F59E0B" />
            <StatCard label="فواتير معلقة" value="—" icon="🧾" color="#EF4444" />
          </div>

          {/* توزيع الباقات */}
          <SectionTitle icon="💎" title="توزيع الباقات" />
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 14, marginBottom: 24 }}>
            {[
              { label: 'الباقة الأساسية (مجاني)', count: users.filter(u => u.role === 'owner' && (!u.package || u.package === 'basic')).length, color: '#6B7280', icon: '📦' },
              { label: 'الباقة المتقدمة', count: users.filter(u => u.role === 'owner' && u.package === 'advanced').length, color: '#3B82F6', icon: '🚀' },
              { label: 'الباقة المؤسسية', count: users.filter(u => u.role === 'owner' && u.package === 'enterprise').length, color: '#8B5CF6', icon: '🏢' },
            ].map((pkg, i) => (
              <Card key={i} style={{ borderColor: `${pkg.color}25` }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div>
                    <div style={{ color: 'rgba(255,255,255,0.5)', fontSize: 12, marginBottom: 6 }}>{pkg.label}</div>
                    <div style={{ color: pkg.color, fontSize: 28, fontWeight: 800 }}>{pkg.count}</div>
                    <div style={{ color: 'rgba(255,255,255,0.3)', fontSize: 11, marginTop: 4 }}>مالك مدرسة</div>
                  </div>
                  <div style={{ fontSize: 32 }}>{pkg.icon}</div>
                </div>
              </Card>
            ))}
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
            <Link href="/dashboard/finance" style={{ textDecoration: 'none' }}>
              <Card style={{ textAlign: 'center', cursor: 'pointer', padding: 24 }}>
                <div style={{ fontSize: 32, marginBottom: 8 }}>💰</div>
                <div style={{ color: 'white', fontWeight: 700, fontSize: 15 }}>إدارة المالية</div>
                <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: 12, marginTop: 4 }}>الفواتير والمدفوعات</div>
              </Card>
            </Link>
            <Link href="/dashboard/subscriptions" style={{ textDecoration: 'none' }}>
              <Card style={{ textAlign: 'center', cursor: 'pointer', padding: 24 }}>
                <div style={{ fontSize: 32, marginBottom: 8 }}>💎</div>
                <div style={{ color: 'white', fontWeight: 700, fontSize: 15 }}>إدارة الباقات</div>
                <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: 12, marginTop: 4 }}>الاشتراكات والأسعار</div>
              </Card>
            </Link>
          </div>
        </div>
      )}

      {/* ============================================ */}
      {/* تبويب: النظام */}
      {/* ============================================ */}
      {activeTab === 'system' && (
        <div>
          <SectionTitle icon="⚙️" title="حالة النظام" />
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 14, marginBottom: 24 }}>
            <Card style={{ borderColor: '#10B98125' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
                <div style={{ width: 10, height: 10, borderRadius: '50%', background: '#10B981' }} />
                <span style={{ color: '#10B981', fontWeight: 700, fontSize: 14 }}>النظام يعمل بشكل طبيعي</span>
              </div>
              <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: 12 }}>آخر فحص: الآن</div>
            </Card>
            <StatCard label="إجمالي الجداول" value="172" icon="🗄️" color="#3B82F6" />
            <StatCard label="APIs متاحة" value="130+" icon="🔌" color="#8B5CF6" />
          </div>

          <SectionTitle icon="🔗" title="إدارة النظام" />
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 12 }}>
            {[
              { label: 'الإعدادات العامة', icon: '⚙️', href: '/dashboard/settings', desc: 'إعدادات المنصة' },
              { label: 'الصلاحيات', icon: '🔑', href: '/dashboard/permissions', desc: 'إدارة الأدوار' },
              { label: 'التكاملات', icon: '🔗', href: '/dashboard/integrations', desc: 'ربط الخدمات' },
              { label: 'النسخ الاحتياطي', icon: '💾', href: '/dashboard/backup', desc: 'حماية البيانات' },
              { label: 'سجل العمليات', icon: '📋', href: '/dashboard/activity-log', desc: 'تتبع النشاط' },
              { label: 'سجل الأخطاء', icon: '🐛', href: '/dashboard/error-logs', desc: 'مراقبة الأخطاء' },
              { label: 'API للمطورين', icon: '🔌', href: '/dashboard/api', desc: 'واجهات برمجية' },
              { label: 'Webhooks', icon: '🔗', href: '/dashboard/webhooks', desc: 'إشعارات خارجية' },
              { label: 'الأمن والسلامة', icon: '🔒', href: '/dashboard/security', desc: 'حماية النظام' },
              { label: 'مفاتيح الطوارئ', icon: '🗝️', href: '/dashboard/emergency-keys', desc: 'وصول طارئ' },
            ].map((item, i) => (
              <Link key={i} href={item.href} style={{ textDecoration: 'none' }}>
                <Card style={{ cursor: 'pointer', padding: 16, transition: 'all 0.2s' }}>
                  <div style={{ fontSize: 24, marginBottom: 8 }}>{item.icon}</div>
                  <div style={{ color: 'white', fontWeight: 700, fontSize: 14, marginBottom: 4 }}>{item.label}</div>
                  <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: 11 }}>{item.desc}</div>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
