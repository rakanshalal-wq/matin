'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';

const INSTITUTION_TYPES = [
  { value: 'school', label: 'مدرسة', icon: '🏫', desc: 'ابتدائي، متوسط، ثانوي' },
  { value: 'university', label: 'جامعة', icon: '🎓', desc: 'بكالوريوس، ماجستير، دكتوراه' },
  { value: 'institute', label: 'معهد', icon: '📚', desc: 'تعليم تقني ومهني' },
  { value: 'kindergarten', label: 'حضانة', icon: '🌱', desc: 'روضة وتمهيدي' },
  { value: 'training_center', label: 'مركز تدريب', icon: '💡', desc: 'دورات وتدريب مهني' },
];

const PLANS = [
  { value: 'starter', label: 'المبتدئ', price: '299', students: '100', color: '#6B7280' },
  { value: 'professional', label: 'الاحترافي', price: '599', students: '500', color: '#C9A227', featured: true },
  { value: 'enterprise', label: 'المؤسسي', price: '1,299', students: '2,000', color: '#8B5CF6' },
];

export default function RegisterPage() {
  const router = useRouter();
  const [step, setStep] = useState(1); // 1: نوع المؤسسة، 2: البيانات، 3: الباقة، 4: تأكيد الإيميل
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [otp, setOtp] = useState('');
  const [verifying, setVerifying] = useState(false);
  const [form, setForm] = useState({
    institution_type: '',
    institution_name: '',
    city: '',
    contact_name: '',
    contact_phone: '',
    contact_email: '',
    students_count: '',
    plan: 'professional',
    password: '',
    confirm_password: '',
  });

  const handleChange = (e: any) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setError('');
  };

  const handleSubmit = async () => {
    if (form.password !== form.confirm_password) {
      setError('كلمتا المرور غير متطابقتين');
      return;
    }
    setLoading(true);
    setError('');
    try {
      const res = await fetch('/api/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) { setError(data.error || 'فشل التسجيل'); return; }
      setStep(4);
    } catch { setError('خطأ في الاتصال'); }
    finally { setLoading(false); }
  };

  const handleVerify = async () => {
    setVerifying(true);
    setError('');
    try {
      const res = await fetch('/api/auth/verify-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'verify', email: form.contact_email, otp }),
      });
      const data = await res.json();
      if (!res.ok) { setError(data.error || 'رمز غير صحيح'); return; }
      router.push('/login?registered=true');
    } catch { setError('خطأ في الاتصال'); }
    finally { setVerifying(false); }
  };

  const styles = {
    page: { minHeight: '100vh', background: '#0D1B2A', fontFamily: 'IBM Plex Sans Arabic, Arial, sans-serif', direction: 'rtl' as const, padding: '20px' },
    container: { maxWidth: '800px', margin: '0 auto' },
    header: { textAlign: 'center' as const, marginBottom: '40px', paddingTop: '20px' },
    logo: { color: '#C9A227', fontSize: '32px', fontWeight: 800, marginBottom: '8px' },
    subtitle: { color: 'rgba(255,255,255,0.6)', fontSize: '16px' },
    card: { background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(201,162,39,0.2)', borderRadius: '16px', padding: '32px' },
    title: { color: '#C9A227', fontSize: '22px', fontWeight: 700, marginBottom: '24px' },
    grid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', gap: '12px', marginBottom: '24px' },
    typeCard: (selected: boolean) => ({
      background: selected ? 'rgba(201,162,39,0.15)' : 'rgba(255,255,255,0.03)',
      border: `2px solid ${selected ? '#C9A227' : 'rgba(255,255,255,0.1)'}`,
      borderRadius: '12px', padding: '20px 12px', textAlign: 'center' as const,
      cursor: 'pointer', transition: 'all 0.2s',
    }),
    typeIcon: { fontSize: '32px', marginBottom: '8px' },
    typeLabel: (selected: boolean) => ({ color: selected ? '#C9A227' : 'white', fontWeight: 700, fontSize: '15px' }),
    typeDesc: { color: 'rgba(255,255,255,0.4)', fontSize: '11px', marginTop: '4px' },
    formGrid: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' },
    label: { color: 'rgba(255,255,255,0.7)', fontSize: '13px', marginBottom: '6px', display: 'block' },
    input: { width: '100%', background: 'rgba(255,255,255,0.07)', border: '1px solid rgba(255,255,255,0.15)', borderRadius: '8px', padding: '12px 14px', color: 'white', fontSize: '14px', boxSizing: 'border-box' as const },
    btn: { background: '#C9A227', color: '#0D1B2A', border: 'none', borderRadius: '10px', padding: '14px 32px', fontSize: '16px', fontWeight: 700, cursor: 'pointer', width: '100%', marginTop: '20px' },
    btnBack: { background: 'transparent', color: 'rgba(255,255,255,0.5)', border: '1px solid rgba(255,255,255,0.15)', borderRadius: '10px', padding: '12px 24px', fontSize: '14px', cursor: 'pointer', marginTop: '12px', width: '100%' },
    error: { background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.3)', borderRadius: '8px', padding: '12px', color: '#FCA5A5', fontSize: '14px', marginBottom: '16px' },
    planGrid: { display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '12px' },
    planCard: (selected: boolean, color: string) => ({
      background: selected ? `${color}15` : 'rgba(255,255,255,0.03)',
      border: `2px solid ${selected ? color : 'rgba(255,255,255,0.1)'}`,
      borderRadius: '12px', padding: '20px', textAlign: 'center' as const, cursor: 'pointer',
    }),
    steps: { display: 'flex', justifyContent: 'center', gap: '8px', marginBottom: '32px' },
    step: (active: boolean, done: boolean) => ({
      width: '36px', height: '36px', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center',
      background: done ? '#C9A227' : active ? 'rgba(201,162,39,0.3)' : 'rgba(255,255,255,0.1)',
      color: done ? '#0D1B2A' : active ? '#C9A227' : 'rgba(255,255,255,0.4)',
      fontWeight: 700, fontSize: '14px', border: `2px solid ${active || done ? '#C9A227' : 'transparent'}`,
    }),
  };

  return (
    <div style={styles.page}>
      <div style={styles.container}>
        <div style={styles.header}>
          <div style={styles.logo}>متين</div>
          <div style={styles.subtitle}>منصة إدارة التعليم الذكي</div>
        </div>

        {/* مؤشر الخطوات */}
        <div style={styles.steps}>
          {['نوع المؤسسة', 'البيانات', 'الباقة', 'التأكيد'].map((s, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <div style={styles.step(step === i + 1, step > i + 1)}>
                {step > i + 1 ? '✓' : i + 1}
              </div>
              <span style={{ color: step === i + 1 ? '#C9A227' : 'rgba(255,255,255,0.3)', fontSize: '13px', display: i < 3 ? 'inline' : 'inline' }}>
                {s}
              </span>
              {i < 3 && <div style={{ width: '30px', height: '1px', background: step > i + 1 ? '#C9A227' : 'rgba(255,255,255,0.1)' }} />}
            </div>
          ))}
        </div>

        <div style={styles.card}>
          {/* الخطوة 1: نوع المؤسسة */}
          {step === 1 && (
            <>
              <div style={styles.title}>ما نوع مؤسستك؟</div>
              <div style={styles.grid}>
                {INSTITUTION_TYPES.map(t => (
                  <div key={t.value} style={styles.typeCard(form.institution_type === t.value)}
                    onClick={() => setForm({ ...form, institution_type: t.value })}>
                    <div style={styles.typeIcon}>{t.icon}</div>
                    <div style={styles.typeLabel(form.institution_type === t.value)}>{t.label}</div>
                    <div style={styles.typeDesc}>{t.desc}</div>
                  </div>
                ))}
              </div>
              <button style={{ ...styles.btn, opacity: form.institution_type ? 1 : 0.5 }}
                onClick={() => form.institution_type && setStep(2)}
                disabled={!form.institution_type}>
                التالي ←
              </button>
            </>
          )}

          {/* الخطوة 2: بيانات المؤسسة */}
          {step === 2 && (
            <>
              <div style={styles.title}>بيانات المؤسسة</div>
              {error && <div style={styles.error}>{error}</div>}
              <div style={styles.formGrid}>
                <div style={{ gridColumn: 'span 2' }}>
                  <label style={styles.label}>اسم المؤسسة *</label>
                  <input style={styles.input} name="institution_name" value={form.institution_name}
                    onChange={handleChange} placeholder="مثال: مدرسة النور الأهلية" />
                </div>
                <div>
                  <label style={styles.label}>المدينة</label>
                  <input style={styles.input} name="city" value={form.city}
                    onChange={handleChange} placeholder="الرياض" />
                </div>
                <div>
                  <label style={styles.label}>عدد الطلاب المتوقع</label>
                  <input style={styles.input} name="students_count" value={form.students_count}
                    onChange={handleChange} placeholder="مثال: 200" type="number" />
                </div>
                <div>
                  <label style={styles.label}>اسم المسؤول *</label>
                  <input style={styles.input} name="contact_name" value={form.contact_name}
                    onChange={handleChange} placeholder="الاسم الكامل" />
                </div>
                <div>
                  <label style={styles.label}>رقم الجوال *</label>
                  <input style={styles.input} name="contact_phone" value={form.contact_phone}
                    onChange={handleChange} placeholder="05xxxxxxxx" />
                </div>
                <div>
                  <label style={styles.label}>البريد الإلكتروني *</label>
                  <input style={styles.input} name="contact_email" value={form.contact_email}
                    onChange={handleChange} placeholder="email@example.com" type="email" />
                </div>
                <div>
                  <label style={styles.label}>كلمة المرور *</label>
                  <input style={styles.input} name="password" value={form.password}
                    onChange={handleChange} type="password" placeholder="8 أحرف على الأقل" />
                </div>
                <div>
                  <label style={styles.label}>تأكيد كلمة المرور *</label>
                  <input style={styles.input} name="confirm_password" value={form.confirm_password}
                    onChange={handleChange} type="password" placeholder="أعد كتابة كلمة المرور" />
                </div>
              </div>
              <button style={styles.btn} onClick={() => {
                if (!form.institution_name || !form.contact_name || !form.contact_phone || !form.contact_email || !form.password) {
                  setError('يرجى ملء جميع الحقول المطلوبة');
                  return;
                }
                if (form.password !== form.confirm_password) {
                  setError('كلمتا المرور غير متطابقتين');
                  return;
                }
                setError('');
                setStep(3);
              }}>التالي ←</button>
              <button style={styles.btnBack} onClick={() => setStep(1)}>← رجوع</button>
            </>
          )}

          {/* الخطوة 3: اختيار الباقة */}
          {step === 3 && (
            <>
              <div style={styles.title}>اختر الباقة المناسبة</div>
              <p style={{ color: 'rgba(255,255,255,0.5)', fontSize: '14px', marginBottom: '20px' }}>
                جميع الباقات تشمل 14 يوم تجريبي مجاناً
              </p>
              <div style={styles.planGrid}>
                {PLANS.map(p => (
                  <div key={p.value} style={styles.planCard(form.plan === p.value, p.color)}
                    onClick={() => setForm({ ...form, plan: p.value })}>
                    {p.featured && (
                      <div style={{ background: '#C9A227', color: '#0D1B2A', fontSize: '11px', fontWeight: 700, padding: '3px 10px', borderRadius: '20px', marginBottom: '10px', display: 'inline-block' }}>
                        الأكثر طلباً
                      </div>
                    )}
                    <div style={{ color: p.color, fontSize: '18px', fontWeight: 800 }}>{p.label}</div>
                    <div style={{ color: 'white', fontSize: '28px', fontWeight: 800, margin: '10px 0' }}>
                      {p.price} <span style={{ fontSize: '14px', color: 'rgba(255,255,255,0.5)' }}>ريال/شهر</span>
                    </div>
                    <div style={{ color: 'rgba(255,255,255,0.5)', fontSize: '13px' }}>
                      حتى {p.students} طالب
                    </div>
                  </div>
                ))}
              </div>
              {error && <div style={{ ...styles.error, marginTop: '16px' }}>{error}</div>}
              <button style={{ ...styles.btn, opacity: loading ? 0.7 : 1 }}
                onClick={handleSubmit} disabled={loading}>
                {loading ? 'جاري التسجيل...' : 'إنشاء الحساب ✓'}
              </button>
              <button style={styles.btnBack} onClick={() => setStep(2)}>← رجوع</button>
            </>
          )}

          {/* الخطوة 4: تأكيد الإيميل */}
          {step === 4 && (
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '64px', marginBottom: '16px' }}>📧</div>
              <div style={{ color: '#C9A227', fontSize: '24px', fontWeight: 800, marginBottom: '8px' }}>
                تأكيد البريد الإلكتروني
              </div>
              <p style={{ color: 'rgba(255,255,255,0.6)', marginBottom: '8px' }}>
                أرسلنا رمز تأكيد مكون من 4 أرقام إلى
              </p>
              <p style={{ color: '#C9A227', fontWeight: 700, fontSize: '16px', marginBottom: '28px' }}>
                {form.contact_email}
              </p>
              {error && <div style={styles.error}>{error}</div>}
              <input
                style={{ ...styles.input, textAlign: 'center', fontSize: '32px', letterSpacing: '12px', fontWeight: 800, maxWidth: '200px', margin: '0 auto 20px' }}
                value={otp} onChange={e => setOtp(e.target.value.replace(/\D/g, '').slice(0, 4))}
                placeholder="0000" maxLength={4}
              />
              <button style={{ ...styles.btn, opacity: verifying || otp.length < 4 ? 0.7 : 1 }}
                onClick={handleVerify} disabled={verifying || otp.length < 4}>
                {verifying ? 'جاري التحقق...' : 'تأكيد الحساب ✓'}
              </button>
              <p style={{ color: 'rgba(255,255,255,0.4)', fontSize: '13px', marginTop: '16px' }}>
                لم يصلك الرمز؟{' '}
                <span style={{ color: '#C9A227', cursor: 'pointer' }}
                  onClick={async () => {
                    await fetch('/api/auth/verify-email', {
                      method: 'POST', headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({ action: 'resend', email: form.contact_email })
                    });
                    alert('تم إرسال رمز جديد');
                  }}>
                  إعادة الإرسال
                </span>
              </p>
            </div>
          )}
        </div>

        <p style={{ textAlign: 'center', color: 'rgba(255,255,255,0.4)', fontSize: '14px', marginTop: '20px' }}>
          لديك حساب؟{' '}
          <a href="/login" style={{ color: '#C9A227', textDecoration: 'none' }}>تسجيل الدخول</a>
        </p>
      </div>
    </div>
  );
}
