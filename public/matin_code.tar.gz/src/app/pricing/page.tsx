import Link from "next/link";

export default function Pricing() {
  const plans = [
    { name: "أساسي", price: "مجاني", features: ["100 طالب", "5 معلمين", "دعم بالإيميل"] },
    { name: "متقدم", price: "299", features: ["500 طالب", "20 معلم", "دعم فوري", "تقارير متقدمة"] },
    { name: "مؤسسي", price: "599", features: ["طلاب غير محدود", "معلمين غير محدود", "دعم 24/7", "تخصيص كامل"] },
  ];

  return (
    <div className="min-h-screen bg-black text-white" dir="rtl">
      <header className="bg-black/90 border-b border-amber-500/20 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="text-3xl font-bold text-amber-500">متين</Link>
          <nav className="hidden md:flex gap-6">
            <Link href="/" className="hover:text-amber-500">الرئيسية</Link>
            <Link href="/community" className="hover:text-amber-500">المجتمع</Link>
            <Link href="/store" className="hover:text-amber-500">المتجر</Link>
            <Link href="/pricing" className="text-amber-500">الأسعار</Link>
            <Link href="/contact" className="hover:text-amber-500">تواصل معنا</Link>
          </nav>
        </div>
      </header>

      <div className="container mx-auto px-4 py-16">
        <h1 className="text-4xl font-bold text-center mb-4">خطط <span className="text-amber-500">الأسعار</span></h1>
        <p className="text-center text-gray-400 mb-12">اختر الخطة المناسبة لمدرستك</p>
        
        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {plans.map((plan, i) => (
            <div key={i} className={`bg-gray-900 rounded-2xl p-8 border ${i === 1 ? "border-amber-500" : "border-gray-800"}`}>
              <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
              <p className="text-4xl font-bold text-amber-500 mb-6">{plan.price === "مجاني" ? plan.price : `${plan.price} ريال/شهر`}</p>
              <ul className="space-y-3 mb-8">
                {plan.features.map((f, j) => (
                  <li key={j} className="flex items-center gap-2"><span className="text-amber-500">✓</span> {f}</li>
                ))}
              </ul>
              <button className={`w-full py-3 rounded-lg font-bold ${i === 1 ? "bg-amber-500 text-black" : "border border-amber-500 text-amber-500"}`}>
                ابدأ الآن
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
