import { pool } from '@/lib/auth';

// جلب تكامل معين
export async function getIntegration(name: string, owner_id?: number | null) {
  try {
    let query = 'SELECT * FROM integrations WHERE name = $1 AND is_active = true';
    const params: any[] = [name];
    if (owner_id) { query += ' AND (owner_id = $2 OR owner_id IS NULL)'; params.push(owner_id); }
    const result = await pool.query(query, params);
    return result.rows[0] || null;
  } catch { return null; }
}

// إرسال SMS عبر Taqnyat
export async function sendSMS(phone: string, message: string, owner_id?: number | null) {
  const integration = await getIntegration('taqnyat', owner_id);
  if (!integration?.api_key) return { success: false, error: 'SMS غير مفعّل' };
  try {
    const sender = integration.extra_config?.sender || 'Matin';
    const res = await fetch('https://api.taqnyat.sa/v1/messages', {
      method: 'POST',
      headers: { 'Authorization': 'Bearer ' + integration.api_key, 'Content-Type': 'application/json' },
      body: JSON.stringify({ recipients: [phone.replace('+', '')], body: message, sender })
    });
    const data = await res.json();
    return { success: res.ok, data };
  } catch (e: any) { return { success: false, error: e.message }; }
}

// إرسال واتساب
export async function sendWhatsApp(phone: string, message: string, owner_id?: number | null) {
  const integration = await getIntegration('whatsapp', owner_id);
  if (!integration?.api_key) return { success: false, error: 'واتساب غير مفعّل' };
  try {
    const phone_id = integration.extra_config?.phone_id;
    const res = await fetch(`https://graph.facebook.com/v18.0/${phone_id}/messages`, {
      method: 'POST',
      headers: { 'Authorization': 'Bearer ' + integration.api_key, 'Content-Type': 'application/json' },
      body: JSON.stringify({ messaging_product: 'whatsapp', to: phone.replace('+', ''), type: 'text', text: { body: message } })
    });
    const data = await res.json();
    return { success: res.ok, data };
  } catch (e: any) { return { success: false, error: e.message }; }
}

// إرسال إيميل عبر Resend
export async function sendEmail(to: string, subject: string, html: string, owner_id?: number | null) {
  const integration = await getIntegration('resend', owner_id);
  const apiKey = integration?.api_key || 're_8YPijCu9_5KBU9zvhf9btdto73sdDpfvs';
  const from = integration?.extra_config?.from || 'no-reply@matin.ink';
  try {
    const res = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { 'Authorization': 'Bearer ' + apiKey, 'Content-Type': 'application/json' },
      body: JSON.stringify({ from: `متين <${from}>`, to, subject, html })
    });
    const data = await res.json();
    return { success: res.ok, data };
  } catch (e: any) { return { success: false, error: e.message }; }
}

// إرسال OTP عبر أفضل قناة متاحة
export async function sendOTP(phone: string, email: string, name: string, code: string, owner_id?: number | null) {
  const message = `مرحباً ${name}، رمز التحقق الخاص بك في متين: ${code} (صالح 10 دقائق)`;
  const html = `<div dir="rtl" style="font-family:Arial;max-width:500px;margin:0 auto;padding:30px;background:#0D1B2A;color:white;border-radius:12px"><h2 style="color:#C9A227">مرحباً ${name} 👋</h2><p>رمز تسجيل الدخول:</p><div style="background:#1B263B;border:2px solid #C9A227;border-radius:12px;padding:20px;text-align:center;margin:20px 0"><span style="font-size:42px;font-weight:900;letter-spacing:12px;color:#C9A227">${code}</span></div><p style="color:rgba(255,255,255,0.6);font-size:13px">صالح 10 دقائق فقط.</p></div>`;

  // جرب SMS أولاً، بعدين واتساب، بعدين إيميل
  if (phone) {
    const sms = await sendSMS(phone, message, owner_id);
    if (sms.success) return { success: true, channel: 'sms' };
    const wa = await sendWhatsApp(phone, message, owner_id);
    if (wa.success) return { success: true, channel: 'whatsapp' };
  }
  const emailResult = await sendEmail(email, 'رمز تسجيل الدخول - متين', html, owner_id);
  return { success: emailResult.success, channel: 'email' };
}

// جلب API Key للخرائط
export async function getGoogleMapsKey(owner_id?: number | null) {
  const integration = await getIntegration('google_maps', owner_id);
  return integration?.api_key || process.env.GOOGLE_MAPS_KEY || '';
}

// جلب بيانات الدفع
export async function getPaymentCredentials(provider: string, owner_id?: number | null) {
  const integration = await getIntegration(provider, owner_id);
  if (!integration) return null;
  return { api_key: integration.api_key, api_secret: integration.api_secret, extra: integration.extra_config };
}
